# Full-scope task package

## Authoritative schema: THREE top-level keys

    model_report     quantized models, serialized size, score separation
    drift_report     movement of the query distribution across the stream
    variants         flat / gated / sandwich

Defined in task/SPEC.md section 14, named in task/PROMPT.txt, produced by
task/solution/solve_full.py. 1,450 leaf values.

The flat six-key layout survives only in task/crosscheck/, an independent
verification artifact, not the task. See its README.

## Layout

    task/PROMPT.txt          the prompt -- outcome-focused, 270 words
    task/SPEC.md             authoritative: all parameters, algorithms, schema
    task/data/               the three input files (read-only)
    task/expected_results.json
    task/solution/solve_full.py
    task/crosscheck/         independent narrow-scope implementation
    research/                the original study (context only)

## Reproduce

    cd task && python solution/solve_full.py data /tmp/results.json

Bitwise identical across repeated runs, and across machines: every threshold
comparison in the pipeline is between integers produced by integer arithmetic,
so no BLAS, libm or float-summation difference can move a decision.

## Design notes

**Free parameters.** task/SPEC.md section 1 pins all of them in one table: the
SLO (0.01), the bit budget (8 per key) and the reference budget (12), the
calibration window (24 blocks) and gated fallback window (4), the gate multiple
(1.5), the pad divisor (8), the tail level grid, the Clopper-Pearson level
(0.05) and drift cap (4.0), the hash-function ceiling (16), the input
quantization step (1/16), the three filter salts, and the control RNG seed
(11). An implementation that reproduces the entire filter pipeline but guesses
at these fails several hundred fields.

**The fragile part is the control arm.** Its RNG is consumed in a fixed order:
one pooled permutation per evaluation block in ascending block order, then a
single `rng.random(96)` gate draw. That gate draw is consumed in all three
variants, including the two that never act on it. Reordering the draws leaves
every treatment number untouched and changes every control number, so a
submission that matches `strategy_metrics` exactly and misses
`control_metrics` entirely has almost certainly reordered them.

**Ground truth.** None is used or available. `queries.csv` holds `query_id`,
`block` and eight features; no membership label, no drift indicator, no cluster
id. Every query is a negative by construction, which is what makes the
per-block false-positive rate directly observable. The false-negative audit is
the one place keys are queried, and its expected value is zero -- a structure
that reports anything else has broken the one-sided-error guarantee that makes
a Bloom filter a Bloom filter.

**Why the numbers are small.** The study's own finding is that the published
design's advantage is narrow: roughly a 9% memory saving at the best sweep
configuration, negative at the largest model. Tolerances are relative, so the
interesting fields are also the tight ones.
