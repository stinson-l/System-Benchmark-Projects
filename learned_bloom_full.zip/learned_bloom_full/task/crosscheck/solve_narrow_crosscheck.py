"""
Independent narrow-scope cross-check -- NOT the task.

Written against the specification text alone, importing nothing from the
research library: hashlib, json, sys, numpy, pandas, scipy. It recomputes 26
quantities that also appear in the full-scope result object, under a FLAT
six-key layout that is not and never was the task schema.

    python solve_narrow_crosscheck.py <data_dir> <out_path>

Two implementations that share no code and agree to 0.0e+00 is the evidence
that SPEC.md describes a computation, not just the file that produced the
expected values.
"""

from __future__ import annotations

import hashlib
import json
import sys
from math import exp, floor, log
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

TARGET = 0.01
WINDOW = 24
BITS_PER_KEY = 8
BENCH_BITS = 12
MIN_FILTER_BITS = 2048
LEVELS = (0.0002, 0.0005, 0.001, 0.002, 0.005, 0.01, 0.02, 0.05, 0.10)
CP_ALPHA = 0.05
DRIFT_CAP = 4.0
K_MAX = 16
SEED = 11
LN2 = log(2.0)


# ---------------------------------------------------------------- scoring
def score(feats, layer):
    xq = np.clip(np.floor(feats * 16.0 + 0.5), -127, 127).astype(np.int64)
    w1 = np.array(layer["w1"], dtype=np.int64)
    acc = xq @ w1.T + np.array(layer["b1"], dtype=np.int64)
    acc = np.maximum(acc, 0)
    s1 = int(layer["s1"])
    hq = np.clip((acc * int(layer["m1"]) + (1 << (s1 - 1))) >> s1, 0, 127)
    return (hq @ np.array(layer["w2"], dtype=np.int64) + int(layer["b2"]))


def bits_of(layer):
    h = len(layer["w2"])
    d = len(layer["w1"][0])
    return 8 * (h * d + h) + 32 * (h + 3)


# ---------------------------------------------------------------- hashing
def words(salt, idents):
    a = np.empty(len(idents), dtype=np.uint64)
    b = np.empty(len(idents), dtype=np.uint64)
    for i, s in enumerate(idents):
        d = hashlib.blake2b(f"{salt}:{s}".encode(), digest_size=16).digest()
        a[i] = int.from_bytes(d[:8], "little")
        b[i] = int.from_bytes(d[8:], "little") | 1
    return a, b


def kopt(m, n):
    if n <= 0:
        return 1
    return int(min(max(int(floor(m / n * LN2 + 0.5)), 1), K_MAX))


def slots(a, b, m, k):
    j = np.arange(k, dtype=np.uint64)
    return ((a[:, None] + j[None, :] * b[:, None]) % np.uint64(m)).astype(np.int64)


def make_filter(m, a, b, n_for_k):
    m = max(int(m), 1)
    k = kopt(m, n_for_k)
    bits = np.zeros(m, dtype=bool)
    if len(a):
        bits[slots(a, b, m, k).ravel()] = True
    return bits, k


def probe(bits, k, a, b):
    if len(a) == 0:
        return np.zeros(0, dtype=bool)
    return bits[slots(a, b, len(bits), k)].all(axis=1)


def bloom_fpr(m, n, k):
    return 0.0 if n <= 0 else (1.0 - exp(-k * n / m)) ** k


# ------------------------------------------------------------- thresholds
def taus_for(win):
    sd = np.sort(win)[::-1]
    n = len(sd)
    out = []
    for lv in LEVELS:
        j = int(min(max(int(floor(lv * n)), 0), n - 1))
        out.append(int(sd[j]) + 1)
    return out


def tail(family, win, tau):
    c = int((win >= tau).sum())
    n = len(win)
    if family == "quant":
        return c / n
    upper = 1.0 if c >= n else float(stats.beta.ppf(1.0 - CP_ALPHA, c + 1, n - c))
    half = n // 2
    p_old = float((win[:half] >= tau).mean())
    p_new = float((win[half:] >= tau).mean())
    if p_old <= 0.0:
        rho = DRIFT_CAP if p_new > 0.0 else 1.0
    else:
        rho = min(max(p_new / p_old, 1.0), DRIFT_CAP)
    return min(1.0, rho * upper)


def pick_tau(family, win, keysc, m_bits):
    best, bestj = None, float("inf")
    for tau in taus_for(win):
        p = tail(family, win, tau)
        nb = int((keysc < tau).sum())
        j = p + (1.0 - p) * bloom_fpr(m_bits, nb, kopt(m_bits, nb))
        if j < bestj:
            best, bestj = tau, j
    return int(best)


def sandwich(total, n_keys, alpha, beta):
    if beta <= 0.0 or beta >= 1.0 or alpha <= 0.0:
        return total, 0
    inner = alpha * beta / (1.0 - beta)
    b2 = 0.0 if inner >= 1.0 else -beta * log(inner) / (LN2 ** 2)
    b2 = min(max(b2, 0.0), total / n_keys)
    mb = int(round(b2 * n_keys))
    return total - mb, mb


# ------------------------------------------------------------------- main
def main(data_dir, out_path):
    keys = pd.read_csv(Path(data_dir) / "keys.csv")
    queries = pd.read_csv(Path(data_dir) / "queries.csv")
    model = json.load(open(Path(data_dir) / "model.json"))

    fcols = [c for c in keys.columns if c.startswith("F")]
    kx = keys[fcols].to_numpy(np.float64)
    qx = queries[fcols].to_numpy(np.float64)
    blk = queries["block"].to_numpy()
    n_keys, n_q = len(keys), len(queries)
    n_blocks = int(blk.max()) + 1
    ev_blocks = list(range(WINDOW, n_blocks))
    per_block = n_q // n_blocks
    total_bits = BITS_PER_KEY * n_keys

    S = {h: score(kx, model["layers"][str(h)]) for h in (16, 64, 256)}
    Q = {h: score(qx, model["layers"][str(h)]) for h in (16, 64, 256)}
    MB = {h: bits_of(model["layers"][str(h)]) for h in (16, 64, 256)}
    R = {h: max(total_bits - MB[h], MIN_FILTER_BITS) for h in (16, 64, 256)}

    ka, kb = words(1, keys["key_id"].to_numpy())
    qa, qb = words(1, queries["query_id"].to_numpy())
    ka2, kb2 = words(2, keys["key_id"].to_numpy())
    qa2, qb2 = words(2, queries["query_id"].to_numpy())
    ka3, kb3 = words(3, keys["key_id"].to_numpy())
    qa3, qb3 = words(3, queries["query_id"].to_numpy())

    idx = {b: np.flatnonzero(blk == b) for b in range(n_blocks)}

    def run(arch, family, h, control_rng=None, oracle=False, tracker=None):
        """Per-block FPR for one flat/sandwich configuration, scheme = fn."""
        fprs, loads, taus = [], [], []
        for step, i in enumerate(ev_blocks):
            wi = np.concatenate([idx[b] for b in range(i - WINDOW, i)])
            ei = idx[i]
            w, ks, e = Q[h][wi], S[h], Q[h][ei]
            if control_rng is not None:
                perm = control_rng[step]
                pooled = np.concatenate([w, ks, e])[perm]
                w = pooled[:len(wi)]
                ks = pooled[len(wi):len(wi) + n_keys]
                e = pooled[len(wi) + n_keys:]
            tau = pick_tau("quant" if oracle else family,
                           e if oracle else w, ks, R[h])
            mask = ks < tau
            if arch == "sandwich":
                a = tail(family, w, tau)
                mi, mb = sandwich(R[h], n_keys, a, float(mask.mean()))
            else:
                mi, mb = 0, R[h]
            bits, k = make_filter(max(mb, 1), ka[mask], kb[mask],
                                  max(int(mask.sum()), 1))
            hit = (e >= tau) | probe(bits, k, qa[ei], qb[ei])
            if mi > 0:
                ib, ik = make_filter(mi, ka2, kb2, n_keys)
                hit &= probe(ib, ik, qa2[ei], qb2[ei])
            fprs.append(float(hit.mean()))
            loads.append(float(mask.mean()))
            taus.append(float(tau))
        return np.array(fprs), np.array(loads), np.array(taus)

    def plain(bpk):
        m = bpk * n_keys
        bits, k = make_filter(m, ka3, kb3, n_keys)
        return np.array([float(probe(bits, k, qa3[idx[i]], qb3[idx[i]]).mean())
                         for i in ev_blocks])

    rng = np.random.default_rng(SEED)
    pool = WINDOW * per_block + n_keys + per_block
    perms = [rng.permutation(pool) for _ in ev_blocks]
    _ = rng.random(len(ev_blocks))          # gate draw, consumed, unused here

    f_q16, l_q16, t_q16 = run("flat", "quant", 16)
    f_q256, _, _ = run("flat", "quant", 256)
    f_b16, _, _ = run("flat", "bound", 16)
    _, _, t_b256 = run("flat", "bound", 256)
    s_q16, _, _ = run("sandwich", "quant", 16)
    o_64, _, _ = run("flat", "quant", 64, oracle=True)
    c_q16, _, _ = run("flat", "quant", 16, control_rng=perms)
    c_q64, _, _ = run("flat", "quant", 64, control_rng=perms)
    cs_q16, _, _ = run("sandwich", "quant", 16, control_rng=perms)

    def auc(pos, neg):
        r = stats.rankdata(np.concatenate([pos, neg]))
        n1, n2 = len(pos), len(neg)
        return float((r[:n1].sum() - n1 * (n1 + 1) / 2) / (n1 * n2))

    train = blk < WINDOW
    final = blk >= n_blocks - WINDOW
    eqb = log(float(s_q16.mean())) / log(2.0 ** -LN2)

    out = {
        "corpus": {
            "n_keys": n_keys, "n_queries": n_q, "n_blocks": n_blocks,
            "n_eval_blocks": len(ev_blocks)},
        "model": {
            "model_bits_16": MB[16], "model_bits_64": MB[64],
            "model_bits_256": MB[256],
            "auc_train_16": auc(S[16].astype(float), Q[16][train].astype(float)),
            "auc_final_256": auc(S[256].astype(float),
                                 Q[256][final].astype(float))},
        "threshold": {
            "mean_tau_quant_16": float(t_q16.mean()),
            "mean_tau_bound_256": float(t_b256.mean()),
            "backup_load_pct_quant_fn_16": float(l_q16.mean() * 100.0)},
        "flat": {
            "quant_fn_16_mean_fpr_pct": float(f_q16.mean() * 100),
            "quant_fn_16_p95_fpr_pct": float(np.percentile(f_q16, 95) * 100),
            "quant_fn_16_pct_within_target": float((f_q16 <= TARGET).mean()),
            "quant_fn_256_mean_fpr_pct": float(f_q256.mean() * 100),
            "bound_fn_16_mean_fpr_pct": float(f_b16.mean() * 100),
            "classic_mean_fpr_pct": float(plain(BITS_PER_KEY).mean() * 100),
            "bloom12_mean_fpr_pct": float(plain(BENCH_BITS).mean() * 100),
            "oracle_mean_fpr_pct": float(o_64.mean() * 100)},
        "sandwich": {
            "quant_fn_16_mean_fpr_pct": float(s_q16.mean() * 100),
            "quant_fn_16_pct_within_target": float((s_q16 <= TARGET).mean()),
            "equivalent_bits_per_key": eqb},
        "control": {
            "flat_quant_fn_16_mean_fpr_pct": float(c_q16.mean() * 100),
            "flat_quant_fn_64_mean_fpr_pct": float(c_q64.mean() * 100),
            "sandwich_quant_fn_16_mean_fpr_pct": float(cs_q16.mean() * 100)},
    }
    Path(out_path).write_text(json.dumps(out, indent=1, sort_keys=True))
    print(f"wrote {out_path}")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("usage: solve_narrow_crosscheck.py <data_dir> <out>")
    main(sys.argv[1], sys.argv[2])
