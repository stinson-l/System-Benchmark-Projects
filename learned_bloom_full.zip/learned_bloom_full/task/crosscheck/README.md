# Independent cross-check — NOT the task

A SEPARATE, NARROW-SCOPE implementation retained only as evidence that the
specification describes the intended computation.

  solve_narrow_crosscheck.py       standalone: imports only hashlib, json, sys,
                                   numpy, pandas, scipy. Computes 26 quantities
                                   under a FLAT six-key layout.
  narrow_crosscheck_expected.json  its output.

The six-key flat layout here is NOT the task schema and never was. The task
schema has exactly THREE top-level keys -- model_report, drift_report,
variants -- defined in ../SPEC.md section 14, stated in ../PROMPT.txt, and
produced by ../solution/solve_full.py.

Why keep it: solve_full.py imports the research library, so on its own it only
shows the library is self-consistent. This file was written independently
against the specification text. Of the 26 quantities it computes, 24 also
appear in the full-scope result object, and it agrees with solve_full.py to
0.0e+00 on all 24. The remaining two are window-mean thresholds for single
configurations, which the full object reports only averaged over all 24
configurations. Two independent implementations converging exactly is the
Solvability evidence.

It also exercises the fragile parts on purpose. It reproduces the control arm
while computing only three control configurations, which is possible only
because the RNG draws are per block rather than per configuration; and it
consumes the gate draw it never uses, because the specification says to.
