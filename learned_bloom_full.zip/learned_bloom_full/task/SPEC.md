# SPEC.md — algorithm specification

Authoritative for every algorithmic choice, every fixed parameter, and the
required output structure. Nothing here is to be tuned, inferred, or
substituted.

## 1. Parameters

    service-level objective (SLO)   0.01     target false-positive rate
    total bit budget                8        bits per key, model included
    reference filter budget         12       bits per key (bloom12 only)
    minimum filter bits             2048
    calibration window              24 blocks
    gated fallback window           4 blocks
    gate multiple                   1.5      of the SLO
    pad divisor                     8        of the window interquartile range
    tail level grid                 0.0002, 0.0005, 0.001, 0.002, 0.005,
                                    0.01, 0.02, 0.05, 0.10
    Clopper-Pearson alpha           0.05     one-sided, bound family only
    drift ratio cap                 4.0      bound family only
    maximum hash functions k        16
    input quantization step         1/16     (model.json: x_inv_scale)
    hidden sizes                    16, 64, 256
    filter salts                    1 backup, 2 initial, 3 plain
    cascade model                   hidden 64, prefilter hidden 16
    oracle model                    hidden 64
    drift-report model              hidden 64
    drift-report epochs             6
    drift-report deciles            10
    control-arm RNG                 numpy.random.default_rng(11)

The plain-filter constant `2 ** -ln(2)` (0.61853...) is the false-positive rate
of an optimally configured Bloom filter per bit per key. It appears once, in
section 12.

## 2. Inputs

`keys.csv` holds `key_id` and `F000..F007`: 4,000 keys, no missing values.

`queries.csv` holds `query_id`, `block`, and `F000..F007`: 48,000 queries in
120 blocks of 400, in ascending `block` order. **Every query is a true
negative.** No query identifier appears in `keys.csv`.

`model.json` holds `x_inv_scale` and `layers`, keyed by hidden size as a
string. Each layer holds `w1` (h x 8, int8), `b1` (h, int32), `m1` (int32),
`s1` (int), `w2` (h, int8), `b2` (int32).

## 3. Scores

Scores are computed in integer arithmetic end to end. No floating-point value
is compared against a threshold anywhere in this specification.

    x_q   = clip(floor(x * 16 + 0.5), -127, 127)
    acc1  = W1 @ x_q + b1                                   (exact integer)
    h_q   = clip((max(acc1, 0) * m1 + 2^(s1 - 1)) >> s1, 0, 127)
    score = W2 @ h_q + b2

`>>` is an arithmetic right shift on a signed integer wide enough not to
overflow; 64 bits suffices. The score is an int32-range integer and is the only
quantity thresholds are ever compared against.

A layer's serialized size is

    model_bits = 8 * (h * 8 + h) + 32 * (h + 3)

which is 1760, 6752 and 26720 bits for h = 16, 64 and 256.

For a model of hidden size h, the bits left for filters are

    filter_bits(h) = max(8 * n_keys - model_bits(h), 2048)

and the reported cost of any structure using that model is
`(model_bits(h) + filter_bits(h)) / n_keys`.

## 4. Filters

A filter over `m` bits with `k` hash functions stores an identifier by setting
the bits at

    h_j = (a + j * b) mod m,        j = 0 .. k-1

where `a` and `b` come from one BLAKE2b digest of the salted identifier:

    d = blake2b(f"{salt}:{identifier}".encode("utf-8"), digest_size=16).digest()
    a = int.from_bytes(d[0:8],  "little")
    b = int.from_bytes(d[8:16], "little") | 1

`b` is forced odd. A query is a filter hit when all `k` of its bits are set.

Unless a rule below says otherwise, `k` is

    k = clip(floor(m / n * ln 2 + 0.5), 1, 16)

where `n` is the *reference count* named by the rule that builds the filter,
which is not always the number of identifiers actually inserted. An empty
filter uses `k = 1`.

The analytic false-positive rate used inside the threshold objective is

    bloom_fpr(m, n, k) = (1 - exp(-k * n / m))^k,     0 when n <= 0

## 5. Threshold selection

Candidate thresholds are read off the calibration sample in the order the level
grid is listed. For a sample `w` sorted in descending order and a level `lv`,

    j   = clip(floor(lv * len(w)), 0, len(w) - 1)
    tau = w_sorted_desc[j] + 1

so at most `j` of the sample lies at or above `tau`.

Each candidate is scored by the estimated end-to-end false-positive rate

    J(tau) = p(tau) + (1 - p(tau)) * bloom_fpr(m, n_below, k(m, n_below))

where `n_below` is the number of keys whose score is strictly below `tau`, `m`
is `filter_bits(h)` — the *undivided* budget, even in the sandwich variant —
and `k` follows section 4. Candidates are scanned in grid order and a strictly
smaller `J` is required to displace the incumbent, so ties resolve to the
largest `tau`.

The two families differ only in `p(tau)`. Let `c` be the number of calibration
scores at or above `tau` and `n` their count.

**quant** — the published rule:

    p = c / n

**bound** — the same tail, corrected twice:

    upper = 1.0                                   if c >= n
            scipy.stats.beta.ppf(0.95, c+1, n-c)  otherwise
    rho   = clip(p_new / p_old, 1.0, 4.0)
    p     = min(1.0, rho * upper)

`p_old` and `p_new` are the fractions at or above `tau` in the first and second
halves of the calibration sample, split at `len(w) // 2`, the sample being in
ascending block order. When `p_old` is 0, `rho` is 4.0 if `p_new` is positive
and 1.0 otherwise.

## 6. Walk-forward evaluation

For each block `i` from 24 to 119 inclusive — 96 evaluation blocks — the
calibration window is the queries of blocks `i-24 .. i-1` in ascending order,
and block `i`'s 400 queries are answered. Everything about the structure is
rebuilt from that window; nothing about block `i` may enter its construction,
except in `oracle` (section 9).

The realized false-positive rate of block `i` is the fraction of its 400
queries the structure answers positively.

**Trigger.** A configuration is *triggered* at block `i` when its own realized
false-positive rate at block `i-1` exceeded `1.5 * 0.01`. At the first
evaluation block no configuration is triggered. The trigger is evaluated and
recorded for every configuration in every variant, whether or not that variant
acts on it.

## 7. Variants

    flat        tau from the 24-block window; the whole filter budget is the
                backup filter
    gated       as flat, except that a triggered configuration takes tau from
                the last 4 blocks of the window instead of all 24
    sandwich    tau from the 24-block window; the budget is split between an
                initial filter over all keys and the backup filter

Under **sandwich**, with `alpha` the family's tail estimate `p(tau)` from
section 5 evaluated on the 24-block window, and `beta` the fraction of keys
placed in the backup filter (section 8):

    b_total = filter_bits(h) / n_keys
    b2      = 0                                        if alpha*beta/(1-beta) >= 1
              -beta * ln(alpha*beta/(1-beta)) / ln^2 2 otherwise
    b2      = clip(b2, 0, b_total)
    m_back  = round(b2 * n_keys)
    m_init  = filter_bits(h) - m_back

and when `beta` is 0 or 1, or `alpha` is 0, the whole budget goes to the
initial filter. `round` is Python's `round` (banker's rounding). The initial
filter stores every key under salt 2 with reference count `n_keys`; it is built
only when `m_init > 0`. A backup filter of zero bits is built over a single bit
instead, which every query hits — the degenerate case reached by the `all`
scheme, whose `beta` is 1.

Under `flat` and `gated`, `m_init = 0` and `m_back = filter_bits(h)`.

## 8. Key-set schemes

Four rules decide which keys the backup filter stores. `margin` is
`round((q75 - q25) / 8)` over the 24-block window's scores, with `q25` and `q75`
the linearly interpolated 25th and 75th percentiles — computed from the full
24-block window in every variant, including a triggered `gated` configuration.

    fn    keys with score < tau                    reference count |stored|
    all   every key                                reference count n_keys
    pad   keys with score < tau + margin           reference count |stored|
    mix   pad when triggered, fn otherwise         reference count |stored|

The reference count is floored at 1. The backup filter uses salt 1.

The 24 sweep configurations are the two families x four schemes x three hidden
sizes, named `family_scheme_hidden`, e.g. `quant_fn_16`.

## 9. The four further structures

**cascade** — hidden 64, `bound` threshold, `fn` scheme, no sandwich split,
plus a prefilter that costs no bits: `tau_pre` is the minimum score of the key
set under the hidden-16 model, and a query with a hidden-16 score below
`tau_pre` is rejected outright. Since no key can be below the minimum over
keys, the prefilter cannot introduce a false negative. Reported cost is that of
hidden 64.

**classic** — a plain filter over all keys, `m = 8 * n_keys`, salt 3, reference
count `n_keys`. No model. Reported cost 8.0.

**bloom12** — the same at `m = 12 * n_keys`. Reported cost 12.0.

**oracle** — hidden 64, `fn` scheme, no sandwich split, and `tau` selected by
the `quant` rule on **the 400 queries of the block being served**. It is not
implementable; it bounds how much of the gap threshold freshness could close.
Reported cost is that of hidden 64.

`cascade`, `classic`, `bloom12` and `oracle` are identical in all three
variants, and `classic`, `bloom12` and `oracle` are computed once per block
rather than per configuration.

## 10. Answering a query

    hit = (score >= tau) OR backup_filter(query)
    hit = hit AND initial_filter(query)            sandwich, when m_init > 0
    hit = hit AND (score_16 >= tau_pre)            cascade only

`classic` and `bloom12` answer with their filter alone.

**One-sided error.** Every structure here must answer positively for every key.
Audit it: at evaluation steps 0, 24, 48 and 72 — counting the first evaluation
block as step 0 — count the keys with score below `tau` that the backup filter
does not contain. The sum over every configuration and every audited step is
reported as `false_negatives_audited` and is 0 for a correct implementation.

## 11. Control arm

The control asks what survives if the model's *ranking* is destroyed while its
score histogram is kept. Using `numpy.random.default_rng(11)`, consumed in
exactly this order:

  * one `rng.permutation(14000)` per evaluation block, in ascending block
    order — 96 draws;
  * then a single `rng.random(96)`, the control gate statistic, scaled by
    `3 * 0.01`.

At block `i`, the window scores, the key scores and the evaluation-block scores
of a given hidden size are concatenated in that order — 9600 + 4000 + 400 =
14000 values — permuted by that block's draw, and split back into pieces of the
same three lengths. The same permutation is applied to all three hidden sizes
and shared by every configuration.

In the control arm the trigger of section 6 is replaced by
`gate_draw[step] > 1.5 * 0.01`, identically for every configuration. The gate
draw is consumed in every variant, including the two that never act on a
trigger for threshold selection.

Every one of the 24 sweep configurations and `cascade` is rerun against the
permuted scores. `classic`, `bloom12` and `oracle` have no control arm:
`classic` and `bloom12` use no model, and `oracle` is already an upper bound.

## 12. Metrics

On a configuration's 96 per-block false-positive rates `r` and its 96 per-block
stored fractions `s`:

    mean_fpr_pct        mean(r) * 100
    p95_fpr_pct         95th percentile of r, linear interpolation, * 100
    max_fpr_pct         max(r) * 100
    pct_within_target   fraction of blocks with r <= 0.01
    excess_ratio        mean(r) / 0.01
    bits_per_key        the reported cost from section 3 or section 9
    backup_load_pct     mean(s) * 100

`equivalent_bits_per_key` for a rate `f` is `ln(clip(f, 1e-12, 0.999999)) /
ln(2 ** -ln 2)` — the plain-filter budget that would match it.

## 13. Significance

Within a variant, each of the two families contributes 12 configurations. Each
is paired with the identically named control configuration. Four metrics are
tested, in this order:

    mean_fpr_pct        lower is better
    p95_fpr_pct         lower is better
    max_fpr_pct         lower is better
    pct_within_target   higher is better

Values of a lower-is-better metric are negated before the test, so the
alternative hypothesis is always "treatment exceeds control". Report:

    t_test_p         scipy.stats.ttest_rel(treatment, control,
                     alternative="greater").pvalue over the 12 pairs
    control_rank     mean within-pair rank of the control arm
    treatment_rank   mean within-pair rank of the treatment arm
    nemenyi_p        two-method Nemenyi post-hoc p-value

Within a pair the better value ranks 2, the worse 1, and a tie ranks both 1.5,
so the two mean ranks always sum to 3.0. With k = 2 methods and N = 12 pairs
the studentized range reduces to a normal tail:

    q        = |treatment_rank - control_rank| * sqrt(N)
    nemenyi_p = min(2 * norm.sf(q / sqrt(2)), 1.0)

## 14. Output structure

`/app/results.json` is a single JSON object with exactly three top-level keys.

**model_report**

    n_keys, n_queries, n_blocks, n_eval_blocks    integers
    hidden_sizes                                  [16, 64, 256]
    model_bits                                    "16","64","256" -> integer
    score_stats                                   "16","64","256" -> twelve floats

The twelve are `model_bits_per_key`, `filter_bits_per_key`, `key_score_mean`,
`key_score_median`, `key_score_min`, `query_score_mean`, `query_score_median`,
`query_score_max`, `auc_train_era`, `auc_final_era`, `ks_train_era`,
`ks_final_era`.

The train era is blocks 0..23, the final era blocks 96..119. `auc` is the
tie-aware Mann-Whitney statistic of the key scores against that era's query
scores, computed from average ranks over the pooled sample. `ks` is the
two-sample Kolmogorov-Smirnov statistic of the same two samples.

**drift_report**

Six epochs of 20 consecutive blocks each; the epoch of block `b` is
`min(b // 20, 5)`. All four quantities use the hidden-64 scores.

    epoch_share_matrix              6x6, rows = epochs, each row sums to 1
    conditional_epoch_share_matrix  the same with the diagonal zeroed and rows
                                    renormalized
    epoch_ks_matrix                 6x6, pairwise two-sample KS statistics,
                                    zero on the diagonal
    decile_share_pct                "D0".."D9" -> "E0".."E5" -> percent

`epoch_share_matrix[e][s]` is the fraction of epoch `e`'s queries falling in
sextile `s`. Bin edges are the interior quantiles of the **train-era** query
scores at levels `i / n_bins`, linearly interpolated, and a score is assigned by
`searchsorted(edges, score, side="right")`. `decile_share_pct` is the same
construction with ten bins, transposed, in percent. A row of the conditional
matrix that sums to zero becomes uniform at `1 / 5`.

**variants**

Exactly the sub-keys `flat`, `gated`, `sandwich`. Each contains exactly:

    diagnostics        n_eval_blocks, mean_tau, trigger_rate,
                       mean_backup_load_pct, best_config, best_mean_fpr_pct,
                       equivalent_bits_per_key, saving_vs_classic_pct,
                       false_negatives_audited
    strategy_metrics   28 entries: the 24 sweep configurations plus cascade,
                       classic, bloom12, oracle
    control_metrics    25 entries: the 24 sweep configurations plus cascade
    significance       quant, bound -> the four metrics of section 13 ->
                       control_rank, treatment_rank, t_test_p, nemenyi_p

`mean_tau`, `trigger_rate` and `mean_backup_load_pct` average over the 24 sweep
configurations and their 96 blocks, and exclude the four further structures.
`best_config` is the sweep configuration with the smallest `mean_fpr_pct`, ties
broken by the lexicographically smallest name; `saving_vs_classic_pct` is
`(equivalent_bits_per_key - 8) / equivalent_bits_per_key * 100` at that
configuration's rate.

Every entry in `strategy_metrics` and `control_metrics` contains exactly the
seven metric keys of section 12.

## 15. Conventions

Percentiles interpolate linearly. `round` is Python's built-in banker's
rounding; `floor` truncates toward negative infinity. Standard deviations do
not appear. The three-argument `clip(x, lo, hi)` is inclusive at both ends.

## 16. No ground truth

Neither CSV contains a membership label, a regime column, or a drift indicator,
and none is required. Every query in `queries.csv` is a negative by
construction, which is what makes the per-block false-positive rate directly
observable; the false-negative audit of section 10 is the only place the key
set is queried, and its expected value is zero.

Scores are integers produced by integer arithmetic, so no reported quantity
depends on floating-point summation order, BLAS threading, or libm version.
Reruns are bitwise identical.
