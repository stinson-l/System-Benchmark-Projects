"""
Full-scope reference solution.

Reproduces the complete study on the frozen inputs: the quantized-model report,
the drift report, three filter architectures, 28 structures per architecture,
25 control arms per architecture, and the paired significance panels.

    python solve_full.py <data_dir> <out_path>

Determinism
-----------
Every stochastic component is pinned:

  * scores        integer-only inference. int8 weights, int32 accumulators,
                  shift-based requantization. No float ever reaches a
                  comparison, so no BLAS or libm difference can move a
                  threshold decision.
  * hashing       BLAKE2b-128 over "salt:identifier", split into two little-
                  endian 64-bit words, Kirsch-Mitzenmacher double hashing.
  * control arm   numpy.random.default_rng(11), consumed in a fixed order --
                  one pooled permutation per evaluation block in ascending
                  block order, then a single rng.random(96) draw supplying the
                  control gate statistic.

The gate draw is consumed in every variant, including the two that do not act
on a gate. Skipping it in those variants leaves the treatment arm untouched and
changes every control number, which makes the control arm the fragile part of
the specification and the first thing to check against a mismatch.

This oracle imports the research library. The standalone
``crosscheck/solve_narrow_crosscheck.py`` re-derives 24 of these quantities
from the specification text alone and agrees with this file to 0.0e+00, which is the evidence that the specification describes the intended
computation rather than merely describing this code.
"""

from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")

RESEARCH = Path(__file__).resolve().parents[2] / "research" / "learned_bloom"
if RESEARCH.exists():
    sys.path.insert(0, str(RESEARCH))
else:
    sys.path.insert(0, "/home/claude/learned_bloom")

from src.data import load_corpus            # noqa: E402
from src.evaluate import Engine             # noqa: E402
from src.report import build_results        # noqa: E402


def main(argv: list[str]) -> int:
    if len(argv) != 3:
        print(__doc__.strip().splitlines()[4], file=sys.stderr)
        return 2
    data_dir, out_path = Path(argv[1]), Path(argv[2])

    keys, queries = load_corpus(data_dir)
    with open(data_dir / "model.json") as fh:
        model = json.load(fh)

    results = build_results(Engine(keys, queries, model))

    text = json.dumps(results, indent=1, sort_keys=True, allow_nan=False)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(text)
    print(f"wrote {out_path} ({len(text)} bytes)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
