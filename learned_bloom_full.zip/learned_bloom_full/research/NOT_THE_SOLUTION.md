# Context, not the solution

`learned_bloom/` is the research study the task was derived from. It shows
where the reference values came from. It is NOT shipped to the solver and must
not be read as the reference solution path.

Three things here are explicitly out of scope:

  - `src/data.py:make_corpus` and `make_data.py` -- generated the frozen CSVs
    and `model.json` in `../task/data/` once, with seed=7 for the corpus and
    seed=0 for the classifiers. Never re-run them; those files are the inputs.
  - `src/quantized.py:train_and_quantize` -- fits and quantizes the classifiers.
    The task consumes `model.json`; it never trains anything.
  - `run_robustness.py` -- the six-seed sweep regenerates corpora and retrains
    models. The task is a single deterministic pass over the frozen inputs.

The corpus generator also carries latent structure -- which key cluster a key
came from, whether a query was drawn from the key-like component -- that the
frozen CSVs do not contain. It is used for plots in the notebook and for
nothing else. See task/SPEC.md section 16.
