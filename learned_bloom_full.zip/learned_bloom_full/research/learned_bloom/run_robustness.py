"""
Robustness sweep.

    python run_robustness.py [n_seeds] [out_json]

Regenerates the corpus and retrains the quantized models from scratch for each
seed, so nothing about a seed's result is inherited from the frozen inputs.
A single backtest is a single draw; the claims in the README are the ones that
survive here.

Out of scope for the derived task -- see ../NOT_THE_SOLUTION.md.
"""

from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

from src.data import TRAIN_BLOCKS, feature_matrix, make_corpus
from src.evaluate import Engine, TARGET_FPR, VARIANTS
from src.metrics import summarize_many
from src.quantized import build_model_file
from src.report import equivalent_bits

TRACKED = "quant_fn_16"


def one_seed(seed: int) -> dict:
    corpus = make_corpus(seed=seed)
    kx = feature_matrix(corpus.keys)
    train = corpus.queries["block"].to_numpy() < TRAIN_BLOCKS
    with tempfile.TemporaryDirectory() as td:
        path = Path(td) / "model.json"
        model = build_model_file(kx, feature_matrix(corpus.queries)[train],
                                 path, seed=0)
    engine = Engine(corpus.keys, corpus.queries, model)

    row = {"seed": seed}
    for v in VARIANTS:
        s = summarize_many(engine.run(v), TARGET_FPR)
        c = summarize_many(engine.run(v, control=True), TARGET_FPR)
        row[f"{v}_fpr"] = s[TRACKED]["mean_fpr_pct"]
        row[f"{v}_ctl"] = c[TRACKED]["mean_fpr_pct"]
        row[f"{v}_slo"] = s[TRACKED]["pct_within_target"]
        row[f"{v}_bits"] = equivalent_bits(s[TRACKED]["mean_fpr_pct"] / 100.0)
        if v == "flat":
            row["classic_fpr"] = s["classic"]["mean_fpr_pct"]
            row["oracle_fpr"] = s["oracle"]["mean_fpr_pct"]
            row["bloom12_fpr"] = s["bloom12"]["mean_fpr_pct"]
    return row


def main() -> None:
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 6
    out = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("output/robustness.json")
    rows = []
    for seed in range(1, n + 1):
        rows.append(one_seed(seed))
        print(f"seed {seed} done", flush=True)
    df = pd.DataFrame(rows).set_index("seed")

    summary = {}
    for v in VARIANTS:
        wins = int((df[f"{v}_fpr"] < df[f"{v}_ctl"]).sum())
        beats_classic = int((df[f"{v}_fpr"] < df["classic_fpr"]).sum())
        summary[v] = {
            "mean_fpr_pct": float(df[f"{v}_fpr"].mean()),
            "mean_control_pct": float(df[f"{v}_ctl"].mean()),
            "mean_slo": float(df[f"{v}_slo"].mean()),
            "mean_equiv_bits": float(df[f"{v}_bits"].mean()),
            "wins_vs_control": wins,
            "wins_vs_classic": beats_classic,
            "n_seeds": int(len(df)),
        }
    summary["classic"] = {"mean_fpr_pct": float(df["classic_fpr"].mean())}
    summary["oracle"] = {"mean_fpr_pct": float(df["oracle_fpr"].mean())}
    summary["bloom12"] = {"mean_fpr_pct": float(df["bloom12_fpr"].mean())}

    print(df.round(4).to_string())
    print(json.dumps(summary, indent=1))
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({"per_seed": df.reset_index().to_dict("records"),
                               "summary": summary}, indent=1))


if __name__ == "__main__":
    main()
