"""Freeze the corpus and the quantized models. Run once; seed 7 / 0."""
from pathlib import Path
import numpy as np
from src.data import make_corpus, write_corpus, feature_matrix, TRAIN_BLOCKS
from src.quantized import build_model_file

OUT = Path(__file__).resolve().parents[2] / "task" / "data"

corpus = make_corpus(seed=7)
write_corpus(corpus, OUT)

kx = feature_matrix(corpus.keys)
train_neg = corpus.queries["block"].to_numpy() < TRAIN_BLOCKS
qx = feature_matrix(corpus.queries)[train_neg]
build_model_file(kx, qx, OUT / "model.json", seed=0)
print("keys", corpus.keys.shape, "queries", corpus.queries.shape,
      "train negatives", train_neg.sum())
