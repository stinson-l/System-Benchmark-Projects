"""
Bloom filters with a pinned hash family.

Kirsch-Mitzenmacher double hashing over one BLAKE2b digest: two 64-bit words
per identifier, ``h_j = (a + j*b) mod m``. Fixing the hash family in the
specification is not pedantry -- the whole study compares false-positive rates
between structures, and an unpinned hash makes those comparisons irreproducible
at the third decimal place, which is exactly where the interesting differences
live.

The digest depends only on ``(salt, identifier)``, never on the set being
stored, so ``HashCache`` computes each identifier's word pair once and every
rebuild after that is pure numpy.
"""

from __future__ import annotations

import hashlib
from math import log

import numpy as np

MASK64 = (1 << 64) - 1
K_MAX = 16
SALT_BACKUP = 1
SALT_INITIAL = 2
SALT_CLASSIC = 3


def word_pair(salt: int, ident: str) -> tuple[int, int]:
    digest = hashlib.blake2b(f"{salt}:{ident}".encode("utf-8"),
                             digest_size=16).digest()
    a = int.from_bytes(digest[:8], "little")
    b = int.from_bytes(digest[8:], "little") | 1      # odd, so it generates
    return a, b


def word_pairs(salt: int, idents) -> tuple[np.ndarray, np.ndarray]:
    pairs = [word_pair(salt, s) for s in idents]
    a = np.fromiter((p[0] for p in pairs), dtype=np.uint64, count=len(pairs))
    b = np.fromiter((p[1] for p in pairs), dtype=np.uint64, count=len(pairs))
    return a, b


class HashCache:
    """Word pairs per (salt, identifier list), computed once."""

    def __init__(self) -> None:
        self._store: dict[int, tuple[np.ndarray, np.ndarray]] = {}

    def get(self, salt: int, idents) -> tuple[np.ndarray, np.ndarray]:
        if salt not in self._store:
            self._store[salt] = word_pairs(salt, idents)
        return self._store[salt]


def optimal_k(m: int, n: int) -> int:
    """round(m/n * ln 2), clipped to [1, 16]; k = 1 when the set is empty."""
    if n <= 0:
        return 1
    k = int(np.floor(m / n * log(2.0) + 0.5))
    return int(min(max(k, 1), K_MAX))


def positions(a: np.ndarray, b: np.ndarray, m: int, k: int) -> np.ndarray:
    """(len(a), k) array of bit positions."""
    j = np.arange(k, dtype=np.uint64)
    idx = (a[:, None] + j[None, :] * b[:, None]) % np.uint64(m)
    return idx.astype(np.int64)


class BloomFilter:
    __slots__ = ("m", "k", "bits")

    def __init__(self, m: int, k: int) -> None:
        self.m = int(max(m, 1))
        self.k = int(k)
        self.bits = np.zeros(self.m, dtype=bool)

    def add_hashed(self, a: np.ndarray, b: np.ndarray) -> None:
        if len(a) == 0:
            return
        self.bits[positions(a, b, self.m, self.k).ravel()] = True

    def query_hashed(self, a: np.ndarray, b: np.ndarray) -> np.ndarray:
        if len(a) == 0:
            return np.zeros(0, dtype=bool)
        return self.bits[positions(a, b, self.m, self.k)].all(axis=1)

    @property
    def load(self) -> float:
        return float(self.bits.mean())


def build(m: int, a: np.ndarray, b: np.ndarray, k: int | None = None,
          n_for_k: int | None = None) -> BloomFilter:
    n = len(a) if n_for_k is None else n_for_k
    f = BloomFilter(m, optimal_k(m, n) if k is None else k)
    f.add_hashed(a, b)
    return f


def theoretical_fpr(m: int, n: int, k: int) -> float:
    if n <= 0:
        return 0.0
    return float((1.0 - np.exp(-k * n / m)) ** k)
