"""
Metrics over a per-block false-positive series, and the paired comparison
against the control arm.

Seven numbers describe a configuration. Three are tail statistics, because a
structure that averages 2% while spending a quarter of its blocks at 6% is not
the structure its headline number advertises. One is the honest memory cost
(model included). One records how much of the key set the model failed to
catch, which is what the backup filter has to pay for.

Significance follows the same shape used across the learned-index literature:
each configuration is paired with its identically-parameterized control, a
one-sided paired t-test is run over the 12 pairs of a family, and the mean
within-pair ranks are referred to a two-method Nemenyi post-hoc test. For k=2
the studentized range collapses to a normal tail, which is why no table lookup
appears anywhere below.
"""

from __future__ import annotations

import numpy as np
from scipy import stats

METRIC_KEYS = ["mean_fpr_pct", "p95_fpr_pct", "max_fpr_pct",
               "pct_within_target", "excess_ratio", "bits_per_key",
               "backup_load_pct"]

# metrics used in the significance panels, and whether larger is better
SIG_METRICS = {"mean_fpr_pct": False, "p95_fpr_pct": False,
               "max_fpr_pct": False, "pct_within_target": True}


def summarize(series, target: float) -> dict[str, float]:
    r = np.asarray(series.fpr, dtype=np.float64)
    stored = np.asarray(series.stored, dtype=np.float64)
    return {
        "mean_fpr_pct": float(r.mean() * 100.0),
        "p95_fpr_pct": float(np.percentile(r, 95.0) * 100.0),
        "max_fpr_pct": float(r.max() * 100.0),
        "pct_within_target": float((r <= target).mean()),
        "excess_ratio": float(r.mean() / target),
        "bits_per_key": float(series.bits),
        "backup_load_pct": float(stored.mean() * 100.0),
    }


def summarize_many(arm: dict, target: float) -> dict[str, dict[str, float]]:
    return {k: summarize(v, target) for k, v in arm.items()}


def _oriented(values: np.ndarray, higher_is_better: bool) -> np.ndarray:
    return values if higher_is_better else -values


def paired_panel(treatment: dict, control: dict, names: list[str]
                 ) -> dict[str, dict[str, float]]:
    """One significance panel over the configurations in ``names``."""
    panel = {}
    for metric, hib in SIG_METRICS.items():
        t = _oriented(np.array([treatment[n][metric] for n in names]), hib)
        c = _oriented(np.array([control[n][metric] for n in names]), hib)

        res = stats.ttest_rel(t, c, alternative="greater")
        p = float(res.pvalue)

        # within-pair ranks, 1 = worse
        t_rank = np.where(t > c, 2.0, np.where(t < c, 1.0, 1.5))
        c_rank = 3.0 - t_rank
        rt, rc = float(t_rank.mean()), float(c_rank.mean())

        n = len(names)
        q = abs(rt - rc) * np.sqrt(n)
        nemenyi = float(2.0 * stats.norm.sf(q / np.sqrt(2.0)))

        panel[metric] = {"control_rank": rc, "treatment_rank": rt,
                         "t_test_p": p, "nemenyi_p": min(nemenyi, 1.0)}
    return panel


def comparison_table(treatment: dict, control: dict, families: dict
                     ) -> dict[str, dict]:
    return {fam: paired_panel(treatment, control, names)
            for fam, names in families.items()}
