"""
Synthetic membership-testing workload.

The workload stands in for the canonical learned-Bloom-filter deployment: a
service holds a set ``S`` of blocked keys and must answer "is this key in S?"
for a stream of queries, almost all of which are negatives. A classifier is
trained on the key set and on an early sample of negatives; a backup Bloom
filter catches the keys the classifier scores below threshold, so the structure
is one-sided-error free by construction.

Two properties of the generator matter for everything downstream:

1. **The negative stream drifts.** The share of negatives drawn from the
   key-like component grows monotonically across blocks. Nothing about the key
   set changes -- only the query mix. This is the regime in which a threshold
   calibrated on a trailing window is stale by the time it is used.

2. **The drift is invisible to the classifier's training set.** Blocks 0..23
   are the training era, so the model and its calibration both see the workload
   at its easiest.

``make_corpus`` produced the frozen CSVs in ``task/data/`` once, with seed=7.
It is not part of the evaluated pipeline.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

N_FEATURES = 8
N_KEYS = 4000
N_BLOCKS = 120
QUERIES_PER_BLOCK = 400
TRAIN_BLOCKS = 24          # blocks 0..23 form the training / calibration era
KEY_CLUSTERS = 3


@dataclass
class Corpus:
    keys: pd.DataFrame        # key_id, F000..F007
    queries: pd.DataFrame     # query_id, block, F000..F007
    key_latent: np.ndarray    # cluster index per key (research only)
    keylike: np.ndarray       # per-query indicator of the key-like component


def _feature_cols(d: int = N_FEATURES) -> list[str]:
    return [f"F{i:03d}" for i in range(d)]


def _key_centers(rng: np.random.Generator, d: int, k: int) -> np.ndarray:
    """Cluster centres on a sphere of radius 2.2, well separated."""
    raw = rng.normal(size=(k, d))
    raw /= np.linalg.norm(raw, axis=1, keepdims=True)
    return raw * 2.2


def keylike_share(block: int, n_blocks: int = N_BLOCKS) -> float:
    """Fraction of block ``block``'s negatives drawn from the key-like mixture.

    Convex in ``block``: flat through the training era, steep at the end. The
    exponent 1.6 is what makes a 24-block trailing window a biased estimate of
    the next block rather than a merely noisy one.
    """
    t = block / (n_blocks - 1)
    return 0.04 + 0.34 * t ** 1.6


def make_corpus(seed: int = 7,
                n_keys: int = N_KEYS,
                n_blocks: int = N_BLOCKS,
                per_block: int = QUERIES_PER_BLOCK,
                d: int = N_FEATURES) -> Corpus:
    rng = np.random.default_rng(seed)
    centers = _key_centers(rng, d, KEY_CLUSTERS)

    # --- key set -------------------------------------------------------
    latent = rng.integers(0, KEY_CLUSTERS, size=n_keys)
    keys = centers[latent] + rng.normal(scale=0.62, size=(n_keys, d))
    key_df = pd.DataFrame(keys, columns=_feature_cols(d))
    key_df.insert(0, "key_id", [f"K{i:05d}" for i in range(n_keys)])

    # --- query stream --------------------------------------------------
    rows, blocks, keylike_flags = [], [], []
    for b in range(n_blocks):
        w = keylike_share(b, n_blocks)
        n_like = rng.binomial(per_block, w)
        n_bg = per_block - n_like

        like_cluster = rng.integers(0, KEY_CLUSTERS, size=n_like)
        like = centers[like_cluster] + rng.normal(scale=1.05, size=(n_like, d))

        # background negatives sit off the key manifold and drift slowly
        shift = 0.35 * (b / (n_blocks - 1)) * centers.mean(axis=0)
        bg = rng.normal(scale=1.45, size=(n_bg, d)) + shift

        block_rows = np.vstack([like, bg])
        order = rng.permutation(per_block)
        rows.append(block_rows[order])
        blocks.append(np.full(per_block, b))
        keylike_flags.append(
            np.concatenate([np.ones(n_like), np.zeros(n_bg)])[order])

    q = np.vstack(rows)
    q_df = pd.DataFrame(q, columns=_feature_cols(d))
    q_df.insert(0, "block", np.concatenate(blocks))
    q_df.insert(0, "query_id", [f"Q{i:06d}" for i in range(len(q_df))])

    return Corpus(key_df, q_df, latent, np.concatenate(keylike_flags))


def write_corpus(corpus: Corpus, out_dir: str | Path) -> None:
    """Freeze the corpus to CSV with 4 decimal places (see SPEC section 2)."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    corpus.keys.to_csv(out / "keys.csv", index=False, float_format="%.4f")
    corpus.queries.to_csv(out / "queries.csv", index=False, float_format="%.4f")


def load_corpus(data_dir: str | Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    d = Path(data_dir)
    keys = pd.read_csv(d / "keys.csv")
    queries = pd.read_csv(d / "queries.csv")
    return keys, queries


def feature_matrix(df: pd.DataFrame) -> np.ndarray:
    return df[[c for c in df.columns if c.startswith("F")]].to_numpy(np.float64)
