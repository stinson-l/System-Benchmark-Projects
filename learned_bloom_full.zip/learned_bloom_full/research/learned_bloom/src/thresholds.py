"""
Threshold selection and budget splitting.

The learned filter's only real tunable is the score threshold tau, and tau is
chosen from a *sample of past negatives*. That is the load-bearing assumption
of the design and the one this study attacks.

Selection is budget-aware rather than target-aware: with the bit budget fixed,
raising tau sends fewer negatives through on the score test but pushes more
keys into the backup filter, which then has fewer bits per stored key. The
estimated end-to-end false-positive rate

    J(tau) = p(tau) + (1 - p(tau)) * bloom_fpr(m, |{keys below tau}|)

is minimized over a fixed grid of tail levels. The two families differ only in
how ``p(tau)`` is estimated from the trailing window:

``quant``   the published rule -- the raw empirical tail, ``c / n``. Unbiased
            under a stationary query stream. Under drift it is an estimate of
            yesterday's tail used as though it were tomorrow's, and at the
            small levels the objective favours it rests on a handful of
            observations.

``bound``   the same tail, corrected twice: a one-sided Clopper-Pearson upper
            limit for the counting error, multiplied by a drift factor measured
            as the growth of the tail from the older to the newer half of the
            window.

Neither rule may look at the evaluation block. ``oracle`` (in evaluate.py) does,
and exists to separate "the threshold was stale" from "the model was weak".
"""

from __future__ import annotations

from math import log

import numpy as np
from scipy import stats

from .filters import optimal_k, theoretical_fpr

CP_ALPHA = 0.05
DRIFT_RATIO_CAP = 4.0
LEVELS = (0.0002, 0.0005, 0.001, 0.002, 0.005, 0.01, 0.02, 0.05, 0.10)
LN2_SQ = log(2.0) ** 2


def _tau_at_count(sorted_desc: np.ndarray, j: int) -> int:
    """Smallest integer tau leaving at most ``j`` of the sample at or above it."""
    n = len(sorted_desc)
    if n == 0:
        return 0
    j = int(min(max(j, 0), n - 1))
    return int(sorted_desc[j]) + 1


def candidate_taus(window_scores: np.ndarray, levels=LEVELS) -> list[int]:
    sd = np.sort(window_scores)[::-1]
    n = len(sd)
    return [_tau_at_count(sd, int(np.floor(lv * n))) for lv in levels]


def clopper_pearson_upper(c: int, n: int, alpha: float = CP_ALPHA) -> float:
    """One-sided upper limit for a binomial rate observed as ``c`` of ``n``."""
    if n <= 0 or c >= n:
        return 1.0
    return float(stats.beta.ppf(1.0 - alpha, c + 1, n - c))


def drift_ratio(window_scores: np.ndarray, tau: int) -> float:
    """Growth of the tail above ``tau``, older half to newer half of the window.

    The window is assumed to be in ascending block order.
    """
    h = len(window_scores) // 2
    if h == 0:
        return 1.0
    p_old = float((window_scores[:h] >= tau).mean())
    p_new = float((window_scores[h:] >= tau).mean())
    if p_old <= 0.0:
        return DRIFT_RATIO_CAP if p_new > 0.0 else 1.0
    return float(min(max(p_new / p_old, 1.0), DRIFT_RATIO_CAP))


def tail_estimate(family: str, window_scores: np.ndarray, tau: int) -> float:
    c = int((window_scores >= tau).sum())
    n = len(window_scores)
    if family == "quant":
        return c / n if n else 1.0
    if family == "bound":
        upper = clopper_pearson_upper(c, n)
        return float(min(1.0, drift_ratio(window_scores, tau) * upper))
    raise ValueError(family)


def select_tau(family: str, window_scores: np.ndarray, key_scores: np.ndarray,
               m_bits: int, levels=LEVELS) -> int:
    """Minimize the estimated end-to-end false-positive rate over the grid.

    Candidates are scanned in the order given by ``levels`` -- largest tau
    first -- and a strictly smaller objective is required to displace the
    incumbent, so ties resolve to the largest tau.
    """
    best_tau, best_j = None, np.inf
    for tau in candidate_taus(window_scores, levels):
        p = tail_estimate(family, window_scores, tau)
        n_below = int((key_scores < tau).sum())
        j = p + (1.0 - p) * theoretical_fpr(m_bits, n_below,
                                            optimal_k(m_bits, n_below))
        if j < best_j:
            best_tau, best_j = tau, j
    return int(best_tau)


def sandwich_split(total_bits: int, n_keys: int, alpha: float,
                   beta: float) -> tuple[int, int]:
    """Mitzenmacher's optimal (initial, backup) bit split.

    With ``b_1`` and ``b_2`` bits per key for the initial and backup filters,
    the sandwiched false-positive rate is approximately

        exp(-b_1 ln^2 2) * (alpha + exp(-(b_2/beta) ln^2 2))

    whose stationary point is ``b_2 = -beta * ln(alpha*beta/(1-beta)) / ln^2 2``.
    ``alpha`` is the model's estimated false-positive rate at tau, ``beta`` the
    fraction of keys that fall through to the backup filter.
    """
    b_total = total_bits / max(n_keys, 1)
    if beta <= 0.0 or beta >= 1.0 or alpha <= 0.0:
        return total_bits, 0
    inner = alpha * beta / (1.0 - beta)
    b2 = 0.0 if inner >= 1.0 else -beta * log(inner) / LN2_SQ
    b2 = float(min(max(b2, 0.0), b_total))
    m_back = int(round(b2 * n_keys))
    return total_bits - m_back, m_back
