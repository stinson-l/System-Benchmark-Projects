"""
Integer-only inference for the membership classifier.

The learned Bloom filter charges the classifier's serialized size against the
same bit budget as the filter, so the model has to be quantized before any
accounting is meaningful. Everything below is int8 weights with int32
accumulators and a shift-based requantization -- the arithmetic a real
deployment would run, and, incidentally, the reason every score in this study
is an exact integer rather than a float that drifts with the BLAS.

Score pipeline
--------------
    x_q      = clip(floor(x * 16 + 0.5), -127, 127)              int8
    acc1     = W1_q @ x_q + b1_q                                 int32
    h_q      = clip((relu(acc1) * m1 + 2^(s1-1)) >> s1, 0, 127)  int8
    score    = W2_q @ h_q + b2                                   int32

``score`` is monotone in the real-valued logit, so thresholding it is
equivalent to thresholding a probability -- and it is bitwise reproducible on
any machine, which a float logit is not.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

X_INV_SCALE = 16          # input quantization step is 1/16
S1 = 20                   # requantization shift for the hidden layer
HIDDEN_SIZES = (16, 64, 256)


# --------------------------------------------------------------------------
# inference (this is the part the task re-implements)
# --------------------------------------------------------------------------

def quantize_inputs(x: np.ndarray) -> np.ndarray:
    """Round-half-up to the 1/16 grid, then clip to the int8 range."""
    q = np.floor(x * X_INV_SCALE + 0.5)
    return np.clip(q, -127, 127).astype(np.int32)


def score_int(x: np.ndarray, layer: dict) -> np.ndarray:
    """Integer score for a batch of feature rows. Returns int32."""
    xq = quantize_inputs(np.asarray(x, dtype=np.float64))
    w1 = np.asarray(layer["w1"], dtype=np.int64)       # (h, d)
    b1 = np.asarray(layer["b1"], dtype=np.int64)       # (h,)
    w2 = np.asarray(layer["w2"], dtype=np.int64)       # (h,)
    b2 = np.int64(layer["b2"])
    m1 = np.int64(layer["m1"])
    s1 = np.int64(layer["s1"])

    acc1 = xq.astype(np.int64) @ w1.T + b1             # (n, h) int32-range
    acc1 = np.maximum(acc1, 0)
    hq = (acc1 * m1 + (np.int64(1) << (s1 - 1))) >> s1
    hq = np.clip(hq, 0, 127)
    out = hq @ w2 + b2
    return out.astype(np.int32)


def model_bits(layer: dict) -> int:
    """Serialized size: 8 bits per int8 weight, 32 per int32 bias/multiplier."""
    h = len(layer["w2"])
    d = len(layer["w1"][0])
    return 8 * (h * d + h) + 32 * (h + 3)


def load_model(path: str | Path) -> dict:
    with open(path) as fh:
        return json.load(fh)


# --------------------------------------------------------------------------
# training + quantization (research only; produced task/data/model.json once)
# --------------------------------------------------------------------------

def train_and_quantize(x_pos: np.ndarray, x_neg: np.ndarray,
                       hidden: int, seed: int = 0) -> dict:
    from sklearn.neural_network import MLPClassifier

    X = np.vstack([x_pos, x_neg])
    y = np.concatenate([np.ones(len(x_pos)), np.zeros(len(x_neg))])
    clf = MLPClassifier(hidden_layer_sizes=(hidden,), activation="relu",
                        alpha=1e-3, max_iter=600, random_state=seed,
                        learning_rate_init=3e-3, tol=1e-6)
    clf.fit(X, y)

    W1, b1 = clf.coefs_[0].T, clf.intercepts_[0]       # (h, d), (h,)
    W2, b2 = clf.coefs_[1].ravel(), float(clf.intercepts_[1][0])

    # int8 weights, symmetric per-tensor scales
    s_w1 = np.abs(W1).max() / 127.0
    W1q = np.clip(np.round(W1 / s_w1), -127, 127).astype(np.int32)
    s_x = 1.0 / X_INV_SCALE
    b1q = np.round(b1 / (s_w1 * s_x)).astype(np.int64)

    # pick the hidden requantization multiplier so the observed activation
    # maximum lands at 127
    xq = quantize_inputs(X)
    acc1 = xq.astype(np.int64) @ W1q.T.astype(np.int64) + b1q
    peak = max(int(np.maximum(acc1, 0).max()), 1)
    m1 = int(round(127.0 / peak * (1 << S1)))
    m1 = max(m1, 1)

    s_h = peak / 127.0 * (s_w1 * s_x)                  # real value per h unit
    s_w2 = np.abs(W2).max() / 127.0
    W2q = np.clip(np.round(W2 / s_w2), -127, 127).astype(np.int32)
    b2q = int(round(b2 / (s_w2 * s_h)))

    return {"w1": W1q.tolist(), "b1": b1q.tolist(), "m1": m1, "s1": S1,
            "w2": W2q.tolist(), "b2": b2q}


def build_model_file(x_pos: np.ndarray, x_neg: np.ndarray,
                     out_path: str | Path,
                     hidden_sizes=HIDDEN_SIZES, seed: int = 0) -> dict:
    model = {"x_inv_scale": X_INV_SCALE,
             "layers": {str(h): train_and_quantize(x_pos, x_neg, h, seed)
                        for h in hidden_sizes}}
    Path(out_path).write_text(json.dumps(model, separators=(",", ":")))
    return model
