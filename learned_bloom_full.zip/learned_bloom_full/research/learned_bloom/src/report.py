"""
Assembles the full result object: model report, drift report, and one panel per
architecture variant.

This is the module the reference solution imports. Everything it computes is a
deterministic function of the two frozen CSVs and the frozen model file --
there is no fitting, no sampling, and no ground truth anywhere in it. The one
stochastic component, the control arm, draws from a pinned generator in a
pinned order (see ``evaluate.Engine.run``).
"""

from __future__ import annotations

from math import log

import numpy as np
from scipy import stats

from . import evaluate as ev
from . import metrics as mt
from . import quantized as qz

N_EPOCHS = 6
N_DECILES = 10
BLOOM_BASE = 2.0 ** -log(2.0)     # plain-filter FPR per bit per key
REPORT_HIDDEN = 64                # model used for the drift report


def auc(pos: np.ndarray, neg: np.ndarray) -> float:
    """Tie-aware Mann-Whitney AUC."""
    allv = np.concatenate([pos, neg])
    r = stats.rankdata(allv)
    n1, n2 = len(pos), len(neg)
    return float((r[:n1].sum() - n1 * (n1 + 1) / 2.0) / (n1 * n2))


def equivalent_bits(fpr: float) -> float:
    """Bits per key a plain Bloom filter would need to match ``fpr``."""
    fpr = min(max(fpr, 1e-12), 0.999999)
    return float(log(fpr) / log(BLOOM_BASE))


def model_report(engine: ev.Engine) -> dict:
    blk = engine.block
    train = blk < ev.WINDOW
    final = blk >= (engine.n_blocks - ev.WINDOW)
    out = {
        "n_keys": int(engine.n_keys),
        "n_queries": int(len(blk)),
        "n_blocks": int(engine.n_blocks),
        "n_eval_blocks": int(len(engine.eval_blocks)),
        "hidden_sizes": list(ev.HIDDENS),
        "model_bits": {},
        "score_stats": {},
    }
    for h in ev.HIDDENS:
        ks = engine.key_scores[h].astype(np.float64)
        qs = engine.query_scores[h].astype(np.float64)
        out["model_bits"][str(h)] = int(engine.model_bits[h])
        out["score_stats"][str(h)] = {
            "model_bits_per_key": float(engine.model_bits[h] / engine.n_keys),
            "filter_bits_per_key": float(engine.filter_bits(h) / engine.n_keys),
            "key_score_mean": float(ks.mean()),
            "key_score_median": float(np.median(ks)),
            "key_score_min": float(ks.min()),
            "query_score_mean": float(qs.mean()),
            "query_score_median": float(np.median(qs)),
            "query_score_max": float(qs.max()),
            "auc_train_era": auc(ks, qs[train]),
            "auc_final_era": auc(ks, qs[final]),
            "ks_train_era": float(stats.ks_2samp(ks, qs[train]).statistic),
            "ks_final_era": float(stats.ks_2samp(ks, qs[final]).statistic),
        }
    return out


def drift_report(engine: ev.Engine) -> dict:
    h = REPORT_HIDDEN
    qs = engine.query_scores[h].astype(np.float64)
    blk = engine.block
    per_epoch = engine.n_blocks // N_EPOCHS
    epoch = np.minimum(blk // per_epoch, N_EPOCHS - 1)
    train = qs[blk < ev.WINDOW]

    def bin_share(n_bins: int) -> np.ndarray:
        edges = np.quantile(train, np.arange(1, n_bins) / n_bins)
        idx = np.searchsorted(edges, qs, side="right")
        m = np.zeros((N_EPOCHS, n_bins))
        for e in range(N_EPOCHS):
            sel = idx[epoch == e]
            m[e] = np.bincount(sel, minlength=n_bins) / len(sel)
        return m

    share = bin_share(N_EPOCHS)
    cond = share.copy()
    np.fill_diagonal(cond, 0.0)
    rows = cond.sum(axis=1, keepdims=True)
    cond = np.where(rows > 0, cond / np.where(rows == 0, 1.0, rows),
                    1.0 / (N_EPOCHS - 1))

    ksm = np.zeros((N_EPOCHS, N_EPOCHS))
    for i in range(N_EPOCHS):
        for j in range(N_EPOCHS):
            if i != j:
                ksm[i, j] = float(stats.ks_2samp(qs[epoch == i],
                                                 qs[epoch == j]).statistic)

    dec = bin_share(N_DECILES)
    decile_share = {f"D{d}": {f"E{e}": float(dec[e, d] * 100.0)
                              for e in range(N_EPOCHS)}
                    for d in range(N_DECILES)}

    return {
        "epoch_share_matrix": share.tolist(),
        "conditional_epoch_share_matrix": cond.tolist(),
        "epoch_ks_matrix": ksm.tolist(),
        "decile_share_pct": decile_share,
    }


def variant_panel(engine: ev.Engine, variant: str) -> dict:
    arm = engine.run(variant, control=False)
    ctl = engine.run(variant, control=True)
    target = engine.target

    strategy = mt.summarize_many(arm, target)
    control = {k: v for k, v in mt.summarize_many(ctl, target).items()
               if k in ev.config_names() + ["cascade"]}

    names = ev.config_names()
    taus = np.array([arm[n].tau for n in names], dtype=np.float64)
    trig = np.array([arm[n].triggered for n in names], dtype=bool)
    loads = np.array([arm[n].stored for n in names], dtype=np.float64)

    best = min(names, key=lambda n: (strategy[n]["mean_fpr_pct"], n))
    best_fpr = strategy[best]["mean_fpr_pct"] / 100.0
    eq = equivalent_bits(best_fpr)

    families = {"quant": [n for n in names if n.startswith("quant_")],
                "bound": [n for n in names if n.startswith("bound_")]}

    return {
        "diagnostics": {
            "n_eval_blocks": int(len(engine.eval_blocks)),
            "mean_tau": float(taus.mean()),
            "trigger_rate": float(trig.mean()),
            "mean_backup_load_pct": float(loads.mean() * 100.0),
            "best_config": best,
            "best_mean_fpr_pct": float(strategy[best]["mean_fpr_pct"]),
            "equivalent_bits_per_key": float(eq),
            "saving_vs_classic_pct": float((eq - engine.bits_per_key) / eq * 100.0),
            "false_negatives_audited": int(sum(sum(s.fn_checks)
                                               for s in arm.values())),
        },
        "strategy_metrics": strategy,
        "control_metrics": control,
        "significance": mt.comparison_table(strategy, control, families),
    }


def build_results(engine: ev.Engine) -> dict:
    return {
        "model_report": model_report(engine),
        "drift_report": drift_report(engine),
        "variants": {v: variant_panel(engine, v) for v in ev.VARIANTS},
    }
