"""
Walk-forward evaluation of learned Bloom filters under query drift.

At block ``i`` the structure may use blocks ``i-24 .. i-1`` and nothing else.
It is rebuilt from scratch every block -- threshold, key partition, filters --
and then answers the 400 queries of block ``i``, every one of which is a true
negative. The realized false-positive rate of block ``i`` is the observation;
96 of them form the series every metric is computed on.

Three architectures (variants)
    flat        model + backup filter over the false-negative set (Kraska)
    gated       flat, but on detected drift the threshold is recomputed from
                the last 4 blocks instead of the last 24
    sandwich    initial filter + model + backup, budget split by Mitzenmacher

Two threshold families (quant, bound) x four key-set schemes (fn, all, pad,
mix) x three model sizes (16, 64, 256) = 24 configurations per variant, named
``family_scheme_hidden``. Four further structures are evaluated alongside them:
``cascade`` (a zero-bit second-model prefilter), ``classic`` and ``bloom12``
(plain filters, no model), and ``oracle`` (threshold fitted on the evaluation
block itself).

The control arm answers the question the memory-saving tables never ask: how
much of the result survives if the classifier's *ranking* is destroyed while
its score histogram is kept? Per block, the pooled scores of the window, the
key set and the evaluation block are permuted together, so key and non-key
scores become exchangeable draws from the same marginal.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from . import filters as flt
from . import quantized as qz
from . import thresholds as th

WINDOW = 24                 # calibration blocks
SHORT_WINDOW = 4            # gated variant's fallback window
TARGET_FPR = 0.01
BITS_PER_KEY = 8            # total budget, model included
BENCH_BITS_PER_KEY = 12     # bloom12 reference structure
MIN_FILTER_BITS = 2048
GATE_MULTIPLE = 1.5
PAD_DIVISOR = 8
CONTROL_SEED = 11
HIDDENS = (16, 64, 256)
FAMILIES = ("quant", "bound")
SCHEMES = ("fn", "all", "pad", "mix")
VARIANTS = ("flat", "gated", "sandwich")
CASCADE_HIDDEN = 64
CASCADE_PREFILTER_HIDDEN = 16
ORACLE_HIDDEN = 64


def config_names() -> list[str]:
    return [f"{f}_{s}_{h}" for f in FAMILIES for s in SCHEMES for h in HIDDENS]


@dataclass
class Series:
    """Per-block record for one configuration."""
    fpr: list[float] = field(default_factory=list)
    stored: list[float] = field(default_factory=list)
    tau: list[float] = field(default_factory=list)
    triggered: list[bool] = field(default_factory=list)
    bits: float = 0.0
    fn_checks: list[int] = field(default_factory=list)


class Engine:
    def __init__(self, keys, queries, model,
                 target: float = TARGET_FPR,
                 bits_per_key: int = BITS_PER_KEY):
        self.target = float(target)
        self.bits_per_key = int(bits_per_key)

        self.key_ids = keys["key_id"].to_numpy()
        self.n_keys = len(self.key_ids)
        kx = keys[[c for c in keys.columns if c.startswith("F")]].to_numpy(np.float64)
        qx = queries[[c for c in queries.columns if c.startswith("F")]].to_numpy(np.float64)

        self.layers = {h: model["layers"][str(h)] for h in HIDDENS}
        self.key_scores = {h: qz.score_int(kx, self.layers[h]) for h in HIDDENS}
        self.query_scores = {h: qz.score_int(qx, self.layers[h]) for h in HIDDENS}
        self.model_bits = {h: qz.model_bits(self.layers[h]) for h in HIDDENS}

        self.query_ids = queries["query_id"].to_numpy()
        self.block = queries["block"].to_numpy()
        self.n_blocks = int(self.block.max()) + 1
        self.slices = {b: np.flatnonzero(self.block == b) for b in range(self.n_blocks)}
        self.eval_blocks = list(range(WINDOW, self.n_blocks))

        self.cache = flt.HashCache()
        self.key_a, self.key_b = self.cache.get(flt.SALT_BACKUP, self.key_ids)
        self.key_a2, self.key_b2 = self.cache.get(flt.SALT_INITIAL, self.key_ids)
        self.key_a3, self.key_b3 = self.cache.get(flt.SALT_CLASSIC, self.key_ids)
        self.q_a = {s: None for s in (flt.SALT_BACKUP, flt.SALT_INITIAL, flt.SALT_CLASSIC)}
        for s in list(self.q_a):
            self.q_a[s] = flt.word_pairs(s, self.query_ids)

        self.total_bits = self.bits_per_key * self.n_keys

    # -- budget ---------------------------------------------------------
    def filter_bits(self, h: int) -> int:
        return max(self.total_bits - self.model_bits[h], MIN_FILTER_BITS)

    def total_cost(self, h: int) -> float:
        return (self.model_bits[h] + self.filter_bits(h)) / self.n_keys

    # -- one arm --------------------------------------------------------
    def run(self, variant: str, control: bool = False) -> dict[str, Series]:
        assert variant in VARIANTS
        rng = np.random.default_rng(CONTROL_SEED) if control else None
        pool_n = WINDOW * len(self.slices[0]) + self.n_keys + len(self.slices[0])
        gate_draw = None
        perms = None
        if control:
            perms = [rng.permutation(pool_n) for _ in self.eval_blocks]
            gate_draw = rng.random(len(self.eval_blocks)) * (3.0 * self.target)

        out: dict[str, Series] = {}
        names = config_names() + ["cascade", "classic", "bloom12", "oracle"]
        for nm in names:
            out[nm] = Series()

        prev_fpr: dict[str, float] = {}

        for step, i in enumerate(self.eval_blocks):
            win_idx = np.concatenate([self.slices[b] for b in range(i - WINDOW, i)])
            short_idx = np.concatenate(
                [self.slices[b] for b in range(i - SHORT_WINDOW, i)])
            ev_idx = self.slices[i]

            win_s, key_s, ev_s = {}, {}, {}
            for h in HIDDENS:
                w = self.query_scores[h][win_idx]
                k = self.key_scores[h]
                e = self.query_scores[h][ev_idx]
                if control:
                    nw, nk = len(w), len(k)
                    pooled = np.concatenate([w, k, e])[perms[step]]
                    w, k, e = pooled[:nw], pooled[nw:nw + nk], pooled[nw + nk:]
                win_s[h], key_s[h], ev_s[h] = w, k, e
            short_pos = np.searchsorted(win_idx, short_idx)
            short_s = {h: win_s[h][short_pos] for h in HIDDENS}

            block_cache: dict[tuple, flt.BloomFilter] = {}

            def backup(mask: np.ndarray, m: int, n_for_k: int) -> flt.BloomFilter:
                key = (mask.tobytes(), m, n_for_k)
                f = block_cache.get(key)
                if f is None:
                    f = flt.build(m, self.key_a[mask], self.key_b[mask],
                                  n_for_k=n_for_k)
                    block_cache[key] = f
                return f

            # -------- the 24 sweep configurations ----------------------
            for family in FAMILIES:
                for h in HIDDENS:
                    R = self.filter_bits(h)
                    for scheme in SCHEMES:
                        name = f"{family}_{scheme}_{h}"
                        trig = self._trigger(name, prev_fpr, gate_draw, step, control)
                        src = short_s[h] if (variant == "gated" and trig) else win_s[h]
                        tau = th.select_tau(family, src, key_s[h], R)

                        mask, k_ref = self._key_set(scheme, key_s[h], win_s[h],
                                                    tau, trig)
                        if variant == "sandwich":
                            alpha = th.tail_estimate(family, win_s[h], tau)
                            beta = float(mask.mean())
                            m_init, m_back = th.sandwich_split(R, self.n_keys,
                                                               alpha, beta)
                        else:
                            m_init, m_back = 0, R

                        bf = backup(mask, max(m_back, 1), k_ref)
                        hit = (ev_s[h] >= tau) | bf.query_hashed(
                            self.q_a[flt.SALT_BACKUP][0][ev_idx],
                            self.q_a[flt.SALT_BACKUP][1][ev_idx])
                        if variant == "sandwich" and m_init > 0:
                            ikey = ("init", m_init)
                            init = block_cache.get(ikey)
                            if init is None:
                                init = flt.build(m_init, self.key_a2,
                                                 self.key_b2,
                                                 n_for_k=self.n_keys)
                                block_cache[ikey] = init
                            hit &= init.query_hashed(
                                self.q_a[flt.SALT_INITIAL][0][ev_idx],
                                self.q_a[flt.SALT_INITIAL][1][ev_idx])

                        fpr = float(hit.mean())
                        s = out[name]
                        s.fpr.append(fpr)
                        s.stored.append(float(mask.mean()))
                        s.tau.append(float(tau))
                        s.triggered.append(bool(trig))
                        s.bits = self.total_cost(h)
                        prev_fpr[name] = fpr
                        if step % 24 == 0:
                            s.fn_checks.append(self._false_negatives(
                                variant, key_s[h], tau, bf, m_init))

            # -------- cascade ------------------------------------------
            h = CASCADE_HIDDEN
            R = self.filter_bits(h)
            tau = th.select_tau("bound", win_s[h], key_s[h], R)
            mask = key_s[h] < tau
            bf = backup(mask, R, int(mask.sum()))
            pre_h = CASCADE_PREFILTER_HIDDEN
            tau_pre = int(key_s[pre_h].min())          # zero-bit prefilter
            hit = (ev_s[h] >= tau) | bf.query_hashed(
                self.q_a[flt.SALT_BACKUP][0][ev_idx],
                self.q_a[flt.SALT_BACKUP][1][ev_idx])
            hit &= ev_s[pre_h] >= tau_pre
            s = out["cascade"]
            s.fpr.append(float(hit.mean()))
            s.stored.append(float(mask.mean()))
            s.tau.append(float(tau))
            s.triggered.append(False)
            s.bits = self.total_cost(h)
            if step % 24 == 0:
                s.fn_checks.append(self._false_negatives("flat", key_s[h], tau,
                                                         bf, 0))

            # -------- plain filters ------------------------------------
            for name, bpk in (("classic", self.bits_per_key),
                              ("bloom12", BENCH_BITS_PER_KEY)):
                m = bpk * self.n_keys
                f = flt.build(m, self.key_a3, self.key_b3, n_for_k=self.n_keys)
                hit = f.query_hashed(self.q_a[flt.SALT_CLASSIC][0][ev_idx],
                                     self.q_a[flt.SALT_CLASSIC][1][ev_idx])
                s = out[name]
                s.fpr.append(float(hit.mean()))
                s.stored.append(1.0)
                s.tau.append(0.0)
                s.triggered.append(False)
                s.bits = float(bpk)
                if step % 24 == 0:
                    s.fn_checks.append(0)

            # -------- oracle -------------------------------------------
            h = ORACLE_HIDDEN
            R = self.filter_bits(h)
            tau = th.select_tau("quant", ev_s[h], key_s[h], R)
            mask = key_s[h] < tau
            bf = backup(mask, R, int(mask.sum()))
            hit = (ev_s[h] >= tau) | bf.query_hashed(
                self.q_a[flt.SALT_BACKUP][0][ev_idx],
                self.q_a[flt.SALT_BACKUP][1][ev_idx])
            s = out["oracle"]
            s.fpr.append(float(hit.mean()))
            s.stored.append(float(mask.mean()))
            s.tau.append(float(tau))
            s.triggered.append(False)
            s.bits = self.total_cost(h)
            if step % 24 == 0:
                s.fn_checks.append(self._false_negatives("flat", key_s[h], tau,
                                                         bf, 0))
        return out

    # -- helpers --------------------------------------------------------
    def _trigger(self, name, prev_fpr, gate_draw, step, control) -> bool:
        if control:
            return bool(gate_draw[step] > GATE_MULTIPLE * self.target)
        p = prev_fpr.get(name)
        return bool(p is not None and p > GATE_MULTIPLE * self.target)

    def _key_set(self, scheme: str, key_s, win_s, tau: int, trig: bool):
        if scheme == "all":
            mask = np.ones(self.n_keys, dtype=bool)
            return mask, self.n_keys
        if scheme == "pad" or (scheme == "mix" and trig):
            q25, q75 = np.percentile(win_s, [25, 75])
            margin = int(round((q75 - q25) / PAD_DIVISOR))
            mask = key_s < tau + margin
        else:                                  # fn, and mix when untriggered
            mask = key_s < tau
        return mask, max(int(mask.sum()), 1)

    def _false_negatives(self, variant, key_s, tau, bf, m_init) -> int:
        """A key must never be rejected. Audited, not assumed."""
        below = key_s < tau
        if not below.any():
            return 0
        got = bf.query_hashed(self.key_a[below], self.key_b[below])
        return int((~got).sum())
