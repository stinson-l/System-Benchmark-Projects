# Learned Bloom Filters Under Query Drift

A working replication — and a critique — of the learned Bloom filter of Kraska,
Beutel, Chi, Dean & Polyzotis, *The Case for Learned Index Structures* (§4),
with the sandwiched variant of Mitzenmacher, *A Model for Learned Bloom Filters
and Optimizing by Sandwiching*, as one of the interventions.

The design is: train a binary classifier to recognize members of a set `S`,
accept any query it scores above a threshold `tau`, and back it with a Bloom
filter holding exactly the members the classifier scores below `tau`. Because
every member is either accepted by the score test or present in the backup
filter, the structure keeps the one-sided-error guarantee of a Bloom filter
while — the claim — using substantially less memory for the same false-positive
rate.

This repository implements that pipeline end to end and stress-tests the two
places the memory claim actually rests: **the accounting** (whether the
classifier's own serialized size is charged against the same budget) and **the
calibration** (whether `tau`, chosen from a sample of past negatives, still
means what it meant when the workload moves).

---

## Headline findings

**1. Charge the model against the budget and the saving nearly disappears.**

Three classifiers of the same architecture and different width, all int8
quantized, over a 4,000-key set at a total budget of 8 bits per key:

| hidden | model bits/key | filter bits/key | AUC, train era | AUC, final era | mean FPR | backup load |
|---|---|---|---|---|---|---|
| 16 | 0.44 | 7.56 | 0.981 | 0.949 | **1.435%** | 63.8% |
| 64 | 1.69 | 6.31 | 0.986 | 0.959 | 1.701% | 56.8% |
| 256 | 6.68 | 1.32 | 0.995 | 0.960 | 8.404% | 8.7% |

A plain Bloom filter at the same 8 bits per key achieves **2.130%**. So the
learned filter does win — with the *smallest* model — and the win is 1.435%
against 2.130%, which is a saving of 0.83 bits per key, or **9.4%**.

The ranking by classifier quality is the reverse of the ranking by filter
quality. The hidden-256 model is the best classifier on every measure (AUC
0.995 in the training era, only 8.7% of keys falling through to the backup) and
is nearly **four times worse than no model at all**, because it consumes 6.68
of the 8 bits per key and leaves the backup filter with 1.32. Reported memory
savings that count the filter and not the model are measuring the wrong object.

**2. The drift is real and large, and fixing it is not where the money is.**

At a threshold calibrated to a 2% false-positive rate on the training era, the
realized rate over the last quarter of the stream is 5.8%, 6.6% and 11.6% for
the three models — the query distribution moves, the threshold does not, and
the deviation grows with model capacity. The two-sample KS distance between the
first and last epochs of the query score distribution is 0.206, against 0.026
between the first and second.

That diagnosis suggests two fixes, and this study implemented both. Neither
works:

| threshold rule / architecture | mean FPR | blocks meeting the 1% SLO |
|---|---|---|
| `quant` — published empirical quantile | 1.435% | 0.333 |
| `bound` — Clopper-Pearson + drift extrapolation | 1.464% | 0.312 |
| `gated` — recalibrate on 4 blocks when drift is detected | 1.477% | 0.281 |
| `oracle` — threshold fitted on the block being served | **1.388%** | 0.406 |

The oracle is the ceiling: a threshold with perfect foresight of the block it
serves is only **3.3% better** than the stale published one. There is almost
nothing there to recover, and both corrections spend accuracy to chase it. The
reason is structural rather than statistical — with the budget fixed, the
threshold that minimizes end-to-end false positives sits far out in the tail
where the filter is doing most of the work, and a threshold in that region is
much less sensitive to distribution shift than the nominal-FPR threshold the
published rule is usually described with.

**3. The fix implied by the accounting does work.**

Sandwiching — spending part of the budget on an initial filter over the whole
key set, at the split Mitzenmacher derives — cuts mean false positives by 32%
and nearly doubles the fraction of blocks meeting the SLO:

| structure | mean FPR | p95 FPR | blocks within SLO | equivalent bits/key | saving |
|---|---|---|---|---|---|
| plain Bloom, 8 bits/key | 2.130% | 3.31% | 0.083 | 8.01 | — |
| learned, flat (as published) | 1.435% | 2.50% | 0.333 | 8.83 | 9.4% |
| learned, gated | 1.477% | 2.50% | 0.281 | 8.77 | 8.8% |
| learned, sandwiched | **0.982%** | 2.00% | 0.635 | 9.62 | **16.9%** |
| score-permuted control | 2.776% | 4.25% | 0.031 | 7.62 | negative |
| plain Bloom, 12 bits/key | 0.299% | 0.75% | 1.000 | 12.10 | (50% more memory) |

The sandwiched filter beats the flat filter *with an oracle threshold*. The
ordering is the finding: architecture beats calibration, and both are smaller
than the cost of the model.

**4. The classifier has to pay for itself, and only just does.**

The control arm permutes the pooled scores of the calibration window, the key
set and the evaluation block together, so key and non-key scores become
exchangeable draws from the same marginal. The score histogram survives; the
ranking does not. Mean false positives go from 1.435% to **2.776%** — *worse
than carrying no model at all*, because the model's bits are still charged
while its ranking is gone.

So the ranking is worth something. It is worth about 0.8 bits per key at the
best configuration, against a structure that costs 0.44 bits per key to carry.
Paired over the 12 configurations of a family, one-sided:

| variant | family | t-test p | mean treatment rank | Nemenyi p |
|---|---|---|---|---|
| flat | quant | 0.043 | 1.75 | 0.221 |
| flat | bound | 0.043 | 1.75 | 0.221 |
| gated | quant | 0.043 | 1.75 | 0.221 |
| sandwich | quant | **0.031** | 1.875 | 0.066 |
| sandwich | bound | 0.034 | 1.875 | 0.066 |

**5. A zero-bit prefilter is the cheapest win available, and it decays too.**

`cascade` adds a second classifier applied at the minimum score over the key
set — a test no key can fail, so it costs no bits beyond the model already
being carried and cannot break one-sided error. It rejects **47.5%** of queries
outright and takes its base configuration from 1.753% to **1.406%**, the best
flat structure in the study, ahead of every one of the 24 sweep configurations.

Two cautions. The 47.5% rejection buys only a 20% reduction, because the
queries a min-over-keys threshold catches are the easy ones and the false
positives come from the survivors. And the rejection rate falls monotonically
across the stream, 57.0% in the first epoch to 36.5% in the last: the same
drift that stales the main threshold erodes the prefilter, and it erodes it
without any calibration step to notice.

---

## Robustness

Six independently simulated corpora, each with its own classifiers retrained
from scratch, tracking `quant_fn_16`:

| variant | mean FPR | control | beats control | beats plain filter | mean equiv. bits/key |
|---|---|---|---|---|---|
| flat | 1.440% | 2.773% | 6/6 | 6/6 | 8.83 |
| gated | 1.440% | 2.796% | 6/6 | 6/6 | 8.83 |
| sandwich | **1.132%** | 2.634% | 6/6 | 6/6 | 9.34 |
| oracle | 1.396% | — | — | — | 8.90 |
| plain, 8 bits/key | 2.130% | — | — | — | 8.01 |

Sandwiching beats the flat architecture on 6 of 6 seeds. The gated variant
beats it on 2 of 6 and ties on the mean — read that as no effect, not as a
small one. The oracle threshold beats the published one on 4 of 6 and by 3% on
average, which is the same non-result seen on the frozen corpus.

---

## What the workload is

`src/data.py` simulates a membership service: a key set drawn from three
Gaussian clusters, and a stream of 120 blocks of 400 queries, every one of them
a true negative. The share of negatives drawn from a key-like component grows
convexly across the stream, from 4% to 38%. Nothing about the key set changes —
only the query mix. Blocks 0-23 are the training era, so the classifier and its
calibration both see the workload at its easiest, which is the assumption most
favourable to the published design.

Two further choices are deliberately favourable to it. The calibration window
is *confirmed* negatives, as though every false positive were labelled on
arrival; a real deployment has to infer that. And the classifier is never
retrained, only recalibrated — retraining would help, and would cost training
compute the memory tables also do not carry.

## Structure

    src/data.py         corpus simulator and CSV loaders
    src/quantized.py    int8 training, quantization, integer-only inference
    src/filters.py      Bloom filters, BLAKE2b double hashing, optimal k
    src/thresholds.py   threshold families, budget-aware objective, sandwich split
    src/evaluate.py     walk-forward engine, three variants, control arm
    src/metrics.py      the seven metrics, paired t-test, Nemenyi
    src/report.py       assembles the full result object
    make_data.py        froze ../../task/data/ once (seed 7 / seed 0)
    run_experiment.py   the tables above, plus results.json and figures
    run_robustness.py   the six-seed sweep

    python run_experiment.py
    python run_robustness.py 6

## A note on determinism

Every threshold comparison in this pipeline is between integers. The classifier
runs in int8 weights with int32 accumulators and a shift-based requantization,
so a score is an exact integer on any machine; the hash family is BLAKE2b with
a pinned salt format and Kirsch-Mitzenmacher double hashing. That is not
incidental tidiness. False-positive rates here differ between structures in the
third decimal place, and a pipeline whose thresholds are float comparisons
against float logits will not reproduce those differences across BLAS versions,
let alone across machines.
