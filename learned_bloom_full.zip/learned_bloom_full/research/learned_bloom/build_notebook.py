"""
Builds and executes notebooks/learned_bloom.ipynb.

    python build_notebook.py

The notebook is the readable walk-through of the study; the README is its
summary and run_experiment.py its batch form. Executed here so the committed
copy carries its outputs.
"""

from __future__ import annotations

from pathlib import Path

import nbformat as nbf
from nbclient import NotebookClient

HERE = Path(__file__).resolve().parent
OUT = HERE / "notebooks" / "learned_bloom.ipynb"

MD = nbf.v4.new_markdown_cell
CODE = nbf.v4.new_code_cell

cells = [
    MD("""# Learned Bloom Filters Under Query Drift

A replication and critique of the learned Bloom filter (Kraska et al., *The
Case for Learned Index Structures*, §4) with Mitzenmacher's sandwiched variant
as one intervention.

The structure accepts a query outright when a classifier scores it above `tau`,
and otherwise consults a Bloom filter holding exactly the keys the classifier
scores below `tau`. Every key is caught by one arm or the other, so one-sided
error survives. The claim is that the same false-positive rate costs less
memory.

Two things are tested here: whether that holds once the classifier's own bits
are charged against the budget, and whether `tau` — calibrated on past
negatives — still means what it meant once the workload moves."""),

    CODE("""import json, sys, warnings
from pathlib import Path
sys.path.insert(0, str(Path.cwd().parent))
warnings.filterwarnings("ignore")

import numpy as np, pandas as pd
import matplotlib.pyplot as plt

from src.data import load_corpus, feature_matrix
from src import quantized as qz
from src.evaluate import Engine, HIDDENS, TARGET_FPR, VARIANTS, WINDOW
from src.metrics import summarize_many
from src.report import build_results, equivalent_bits

DATA = Path.cwd().parents[2] / "task" / "data"
keys, queries = load_corpus(DATA)
model = json.load(open(DATA / "model.json"))
blk = queries["block"].to_numpy()
print(f"{len(keys)} keys, {len(queries)} queries, {blk.max()+1} blocks, "
      f"SLO {TARGET_FPR:.0%}, budget 8 bits/key")"""),

    MD("""## 1. The workload

Every query is a true negative, so the per-block false-positive rate is
directly observable — no labels, no ground truth, nothing to align. What moves
is the *mix*: the share of negatives drawn from a key-like component grows
across the stream. The key set never changes."""),

    CODE("""scores = {h: qz.score_int(feature_matrix(queries), model["layers"][str(h)])
          for h in HIDDENS}
key_scores = {h: qz.score_int(feature_matrix(keys), model["layers"][str(h)])
              for h in HIDDENS}

epoch = np.minimum(blk // 20, 5)
fig, ax = plt.subplots(1, 2, figsize=(11, 3.6))
for e in range(6):
    ax[0].hist(scores[64][epoch == e], bins=60, histtype="step", density=True,
               label=f"epoch {e}")
ax[0].axvline(np.median(key_scores[64]), color="k", ls="--", lw=1)
ax[0].set_title("hidden-64 query scores by epoch (dashed = median key score)")
ax[0].legend(fontsize=7)

ax[1].plot(range(blk.max()+1),
           [np.mean(scores[64][blk == b]) for b in range(blk.max()+1)])
ax[1].axvline(WINDOW, color="r", lw=1)
ax[1].set_title("mean query score per block (red = end of training era)")
ax[1].set_xlabel("block")
plt.tight_layout(); plt.show()"""),

    MD("""## 2. Charging the model against the budget

The classifiers are int8-quantized: 8 bits per weight, 32 per bias and
requantization constant. Inference is integer-only, so a score is an exact
integer and no threshold decision depends on floating-point summation order.

The wider the model, the better it separates keys from negatives — and the less
budget is left for the filter that has to catch what it misses."""),

    CODE("""rows = []
for h in HIDDENS:
    mb = qz.model_bits(model["layers"][str(h)])
    rows.append({"hidden": h, "params": len(model["layers"][str(h)]["w2"]),
                 "model bits/key": mb / len(keys),
                 "filter bits/key": (8*len(keys) - mb) / len(keys)})
pd.DataFrame(rows).set_index("hidden").round(3)"""),

    MD("""## 3. A fixed threshold goes stale

Calibrate `tau` to a 2% false-positive rate on the training era, then leave it
alone and watch the realized rate. The deviation grows with model capacity —
the sharper the decision boundary, the more a distribution shift moves across
it."""),

    CODE("""train = blk < WINDOW
rows = []
for h in HIDDENS:
    sd = np.sort(scores[h][train])[::-1]
    tau = int(sd[int(0.02 * train.sum())]) + 1
    rows.append({"hidden": h, "tau": tau,
                 **{f"epoch {e}": float(np.mean(scores[h][epoch == e] >= tau))
                    for e in range(6)}})
pd.DataFrame(rows).set_index("hidden").round(4)"""),

    MD("""## 4. Walk-forward evaluation

At block `i` the structure is rebuilt from blocks `i-24 .. i-1` and nothing
else, then answers block `i`. Three architectures — flat (as published), gated
(recalibrate on 4 blocks when drift is detected), sandwich (Mitzenmacher's
initial/backup split) — across two threshold families, four key-set schemes and
three model sizes."""),

    CODE("""engine = Engine(keys, queries, model)
arms = {v: engine.run(v) for v in VARIANTS}
ctls = {v: engine.run(v, control=True) for v in VARIANTS}
mets = {v: summarize_many(a, TARGET_FPR) for v, a in arms.items()}
cmets = {v: summarize_many(c, TARGET_FPR) for v, c in ctls.items()}

ref = mets["flat"]
head = pd.DataFrame({
    "flat": {c: mets["flat"][c]["mean_fpr_pct"] for c in
             ("quant_fn_16", "quant_fn_64", "quant_fn_256", "bound_fn_16")},
    "gated": {c: mets["gated"][c]["mean_fpr_pct"] for c in
              ("quant_fn_16", "quant_fn_64", "quant_fn_256", "bound_fn_16")},
    "sandwich": {c: mets["sandwich"][c]["mean_fpr_pct"] for c in
                 ("quant_fn_16", "quant_fn_64", "quant_fn_256", "bound_fn_16")},
})
for nm in ("cascade", "classic", "bloom12", "oracle"):
    head.loc[nm] = [ref[nm]["mean_fpr_pct"]] * 3
head["equiv bits/key"] = [equivalent_bits(v / 100) for v in head["flat"]]
head.round(3)"""),

    MD("""The hidden-256 model — the best classifier by AUC — is four times worse
than carrying no model at all. The plain filter at the same 8 bits per key
reaches 2.130%; the best learned configuration reaches 1.435%, a saving of
about 0.83 bits per key.

Sandwiching is the intervention that pays. Note where it lands relative to
`oracle`, a flat filter whose threshold is fitted on the very block it serves:
reallocating bits beats knowing the future."""),

    CODE("""blocks = engine.eval_blocks
fig, ax = plt.subplots(1, 2, figsize=(12, 3.8))
for lbl, s in (("flat quant_fn_16", arms["flat"]["quant_fn_16"]),
               ("sandwich quant_fn_16", arms["sandwich"]["quant_fn_16"]),
               ("control", ctls["flat"]["quant_fn_16"]),
               ("plain, 8 b/k", arms["flat"]["classic"])):
    ax[0].plot(blocks, 100*np.array(s.fpr), lw=1.2, label=lbl)
ax[0].axhline(100*TARGET_FPR, color="k", lw=.8)
ax[0].set_ylabel("realized FPR (%)"); ax[0].set_xlabel("block")
ax[0].legend(fontsize=7); ax[0].set_title("per-block false positives")

for h in HIDDENS:
    ax[1].plot(blocks, 100*np.array(arms["flat"][f"quant_fn_{h}"].fpr),
               lw=1.2, label=f"hidden={h}")
ax[1].axhline(100*TARGET_FPR, color="k", lw=.8); ax[1].set_yscale("log")
ax[1].legend(fontsize=7); ax[1].set_xlabel("block")
ax[1].set_title("model size, charged against the budget")
plt.tight_layout(); plt.show()"""),

    MD("""## 5. Does the ranking carry the result?

The control permutes the pooled scores of the calibration window, the key set
and the evaluation block together. The score histogram survives; the
correspondence between a score and whether the item is a key does not. The
model's bits are still charged."""),

    CODE("""cmp = pd.DataFrame({
    v: {"treatment": mets[v]["quant_fn_16"]["mean_fpr_pct"],
        "control": cmets[v]["quant_fn_16"]["mean_fpr_pct"],
        "treatment SLO": mets[v]["quant_fn_16"]["pct_within_target"],
        "control SLO": cmets[v]["quant_fn_16"]["pct_within_target"]}
    for v in VARIANTS}).round(3)
cmp.loc["plain 8 b/k"] = [ref["classic"]["mean_fpr_pct"]] * 3
cmp"""),

    MD("""The control lands *worse than no model at all* — it pays the model's
bits and gets nothing for them. So the ranking is worth something. What it is
worth is roughly 0.8 bits per key, which is the entire result."""),

    CODE("""results = build_results(engine)
sig = {(v, f): results["variants"][v]["significance"][f]["mean_fpr_pct"]
       for v in VARIANTS for f in ("quant", "bound")}
pd.DataFrame(sig).T.round(4)"""),

    MD("""## 6. Robustness, and what to conclude

`run_robustness.py` regenerates the corpus and retrains every classifier for
six seeds. Sandwiching beats the flat architecture on 6 of 6; the gated variant
on 2 of 6, which is no effect. The oracle threshold beats the published one by
about 3%.

The design does save memory, and less than advertised. The two levers are not
equal: **how the bits are divided matters more than how fresh the threshold
is, and both matter less than what the model itself costs to carry.** A
memory-saving table that does not include the classifier's serialized size in
the numerator is not measuring the structure it claims to."""),

    CODE("""p = HERE_ROB = Path.cwd().parent / "output" / "robustness.json"
if p.exists():
    rb = json.load(open(p))["summary"]
    display(pd.DataFrame(rb).T.round(4))
else:
    print("run: python run_robustness.py 6")"""),
]

nb = nbf.v4.new_notebook(cells=cells)
nb.metadata["kernelspec"] = {"display_name": "Python 3", "language": "python",
                             "name": "python3"}
OUT.parent.mkdir(parents=True, exist_ok=True)
NotebookClient(nb, timeout=1800, resources={"metadata": {"path": str(OUT.parent)}}).execute()
nbf.write(nb, OUT)
print(f"wrote {OUT}")
