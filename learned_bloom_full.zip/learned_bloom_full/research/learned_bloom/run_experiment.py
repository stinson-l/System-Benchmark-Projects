"""
Main experiment.

    python run_experiment.py [data_dir] [out_dir]

Reads the frozen corpus and quantized models, runs the three architectures with
their control arms, prints the tables the README quotes, and writes
``results.json`` plus the figures the notebook embeds.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

from src.data import load_corpus
from src.evaluate import Engine, HIDDENS, TARGET_FPR, VARIANTS
from src.metrics import summarize_many
from src.report import build_results, equivalent_bits

HERE = Path(__file__).resolve().parent
DEFAULT_DATA = HERE.parents[1] / "task" / "data"


def headline(results: dict) -> pd.DataFrame:
    rows = []
    for v in VARIANTS:
        p = results["variants"][v]
        d = p["diagnostics"]
        s = p["strategy_metrics"]
        c = p["control_metrics"]
        best = d["best_config"]
        rows.append({
            "variant": v,
            "best config": best,
            "mean FPR %": s[best]["mean_fpr_pct"],
            "control %": c[best]["mean_fpr_pct"],
            "p95 %": s[best]["p95_fpr_pct"],
            "blocks within SLO": s[best]["pct_within_target"],
            "equiv bits/key": d["equivalent_bits_per_key"],
            "saving %": d["saving_vs_classic_pct"],
            "t-test p (quant, mean FPR)":
                p["significance"]["quant"]["mean_fpr_pct"]["t_test_p"],
        })
    ref = results["variants"]["flat"]["strategy_metrics"]
    for nm in ("classic", "bloom12", "oracle", "cascade"):
        rows.append({"variant": nm, "best config": "-",
                     "mean FPR %": ref[nm]["mean_fpr_pct"],
                     "control %": np.nan,
                     "p95 %": ref[nm]["p95_fpr_pct"],
                     "blocks within SLO": ref[nm]["pct_within_target"],
                     "equiv bits/key":
                         equivalent_bits(ref[nm]["mean_fpr_pct"] / 100.0),
                     "saving %": np.nan,
                     "t-test p (quant, mean FPR)": np.nan})
    return pd.DataFrame(rows).set_index("variant")


def model_size_table(results: dict) -> pd.DataFrame:
    mr = results["model_report"]["score_stats"]
    flat = results["variants"]["flat"]["strategy_metrics"]
    sand = results["variants"]["sandwich"]["strategy_metrics"]
    rows = []
    for h in HIDDENS:
        s = mr[str(h)]
        rows.append({
            "hidden": h,
            "model bits/key": s["model_bits_per_key"],
            "filter bits/key": s["filter_bits_per_key"],
            "AUC train era": s["auc_train_era"],
            "AUC final era": s["auc_final_era"],
            "flat quant_fn %": flat[f"quant_fn_{h}"]["mean_fpr_pct"],
            "sandwich quant_fn %": sand[f"quant_fn_{h}"]["mean_fpr_pct"],
            "backup load %": flat[f"quant_fn_{h}"]["backup_load_pct"],
        })
    return pd.DataFrame(rows).set_index("hidden")


def figures(engine: Engine, results: dict, out_dir: Path) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    arm_flat = engine.run("flat")
    arm_sand = engine.run("sandwich")
    ctl = engine.run("flat", control=True)
    blocks = engine.eval_blocks

    fig, ax = plt.subplots(1, 2, figsize=(12, 4))
    for name, series, style in (("flat quant_fn_16", arm_flat["quant_fn_16"], "-"),
                                ("sandwich quant_fn_16", arm_sand["quant_fn_16"], "-"),
                                ("control", ctl["quant_fn_16"], ":"),
                                ("classic 8 b/k", arm_flat["classic"], "--")):
        ax[0].plot(blocks, 100 * np.array(series.fpr), style, lw=1.3, label=name)
    ax[0].axhline(100 * TARGET_FPR, color="k", lw=0.8, alpha=0.6)
    ax[0].set_xlabel("block"); ax[0].set_ylabel("realized FPR (%)")
    ax[0].set_title("Per-block false-positive rate"); ax[0].legend(fontsize=8)

    for h in HIDDENS:
        ax[1].plot(blocks, 100 * np.array(arm_flat[f"quant_fn_{h}"].fpr),
                   lw=1.2, label=f"hidden={h}")
    ax[1].axhline(100 * TARGET_FPR, color="k", lw=0.8, alpha=0.6)
    ax[1].set_yscale("log"); ax[1].set_xlabel("block")
    ax[1].set_title("Model size, charged against the budget")
    ax[1].legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(out_dir / "fig_blocks.png", dpi=130)

    fig2, ax2 = plt.subplots(figsize=(6, 4))
    ks = np.array(results["drift_report"]["epoch_ks_matrix"])
    im = ax2.imshow(ks, cmap="magma")
    ax2.set_title("Two-sample KS between epochs (hidden=64 scores)")
    ax2.set_xlabel("epoch"); ax2.set_ylabel("epoch")
    fig2.colorbar(im)
    fig2.tight_layout()
    fig2.savefig(out_dir / "fig_drift.png", dpi=130)


def main() -> None:
    data_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_DATA
    out_dir = Path(sys.argv[2]) if len(sys.argv) > 2 else HERE / "output"
    out_dir.mkdir(parents=True, exist_ok=True)

    keys, queries = load_corpus(data_dir)
    model = json.load(open(Path(data_dir) / "model.json"))
    engine = Engine(keys, queries, model)
    results = build_results(engine)

    pd.set_option("display.width", 160)
    print("\n== headline ==")
    print(headline(results).round(4).to_string())
    print("\n== model size vs filter budget ==")
    print(model_size_table(results).round(4).to_string())
    print("\n== scheme sweep, flat variant, mean FPR %% ==")
    sm = results["variants"]["flat"]["strategy_metrics"]
    sweep = pd.DataFrame(
        {h: {f"{f}_{s}": sm[f"{f}_{s}_{h}"]["mean_fpr_pct"]
             for f in ("quant", "bound") for s in ("fn", "all", "pad", "mix")}
         for h in HIDDENS})
    print(sweep.round(3).to_string())

    (out_dir / "results.json").write_text(json.dumps(results, indent=1,
                                                     sort_keys=True))
    figures(engine, results, out_dir)
    print(f"\nwrote {out_dir/'results.json'}")


if __name__ == "__main__":
    main()
