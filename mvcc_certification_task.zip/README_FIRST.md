# Concurrency-control certification task package

A Terminal-Bench-style task package on conflict certification, lock
granularity and contention drift, built to the same structure as the
cardinality-estimation package it was modelled on.

## Layout

```
task/
  PROMPT.txt              what the solver is given
  SPEC.md                 authoritative: parameters, definitions, output schema
  SCHEMA_superseded.md    pointer to SPEC.md section 14
  data/
    oplog.csv             21,600 operations, 36 blocks of 600
    txn.csv               1,800 transactions, 50 per block
    rel_catalog.csv       4 relations, 512 / 256 / 128 / 384 items
    truth.csv             1,800 transaction truths, incl. per-kind edge counts
    params.json           fixed parameters
    sched.db              the same four tables as SQLite
  Sol/
    expected_results.json the gold file: 1,441 leaves, 58,777 bytes
    solution/
      solve_full.py       reference driver
      sql/*.sql           where the work actually happens (7 stages)
    crosscheck/
      solve_narrow_crosscheck.py   independent NumPy re-derivation, no SQL
    tests/
      test_outputs.py     20-layer verifier
```

The uploaded package that this one mirrors was the trimmed variant, without a
`research/` directory, so none is included here.

## The domain

A certifier decides, at each commit point, whether committing would violate
the isolation level the system claims. It decides from a summary of what other
transactions touched. Tracking every item is exact and expensive; tracking
coarser units is cheap and manufactures conflicts that do not exist. And the
summary was built on history the workload has since moved away from.

Four axes vary at once: the granularity of the contention map (`group` vs
`hot`, at three budgets), the certification rule (`fcw`, `danger`, `sgt`,
`mix`), the visibility convention under which reads resolve (`si`, `rc`,
`stale`), and the age of the history the map was built from.

The literature the design follows is named in the preamble of SPEC.md — Gray et al.
on granularity and degrees of consistency, Berenson et al. and Adya on what
the isolation levels actually mean, Bernstein/Hadzilacos/Goodman on
serialization graph testing, Fekete et al. and Cahill/Röhm/Fekete on the
dangerous structure and its runtime test, Ports and Grittner on what happens
when that test runs over summarised rather than exact predicate locks. Nothing
in the task requires having read them.

## Why SQL is intrinsic rather than decorative

The reference solution contains no certification, no grouping and no cost
accounting of its own. `solve_full.py` loads the frozen CSVs into SQLite,
walks the 30 evaluation blocks in commit order, and executes the seven scripts
in `sql/`. Equi-depth assignment, hot-set selection, the three edge kinds, the
four schemes, the incremental transitive closure and its cycle test, the joint
contingency table behind `cascade`, the systematic sample, the control
permutation, bit-length arithmetic, false-conflict attribution and the drift
binning are all relational. Certification is a genuine fixed-point walk in
SQL: 156 streams advance one commit step at a time, with the closure extended
by three INSERTs per committed transaction.

The exceptions are named in SPEC.md section 13 and are library calls, not
reimplementations: `scipy.stats.ttest_rel`, a normal tail, and `ks_2samp`.

The crosscheck re-derives 38 quantities in NumPy from the specification text
alone, sharing no code and issuing no SQL, using a dense boolean reachability
matrix and an outer-product update where the reference uses a relation and
three joins. The two agree to **0.0e+00** relative — bit-identical on all 38 —
which is the evidence that the specification determines the answer, rather
than the solver having to guess what the reference happened to do.

## Determinism

No pseudo-random generator is consumed anywhere. The control arm is a
deal-into-piles permutation, so there is no seed to agree on and no draw order
to get wrong. Group boundaries come from integer division, tie-breaks are
integer or string comparisons, and bit widths come from repeated halving
rather than a logarithm. Reruns are byte-identical.

## Running it

```
python task/Sol/solution/solve_full.py task/data /tmp/results.json   # ~72 s
python task/Sol/crosscheck/solve_narrow_crosscheck.py task/data /tmp/narrow.json
cd task/Sol && python -m pytest tests/test_outputs.py -q
```

The suite reports 18 passed and 2 skipped against the gold file alone; the two
skips are the rerun and perturbation layers, which need a solver staged at
`/app/solve.py`. With one there, all 20 pass in about 2m20s.

Layer V19 does not take `truth.csv` on faith: it recomputes every transaction's
`true_ww`, `true_wr` and `true_rw` in SQL from the operation log and the
transaction table, at item granularity under `si`, and requires agreement row
for row.

## What the study finds

The headline result is a dissociation, and it runs the opposite way to the one
in the cardinality package. Against a control that permutes each relation's
access-count vector — preserving the count multiset exactly, and the number of
keys formed, and the bits spent, while destroying which item carries which
count — the real maps are **decisively better at deciding** and **decisively
worse at explaining**.

- On `mean_a_error` the treatment wins every one of the 12 paired
  configurations in both families (mean rank 1.0, Nemenyi p = 5.3e-4), 2.905
  against 3.631, paired t p = 1.0e-09 for `group` and 4.5e-08 for `hot`.
- On `class_agreement_pct` the treatment **loses** every one of the 12,
  65.35% against 67.88%, with the one-sided t-test at p = 0.99999.

Knowing where the contention actually sits buys a great deal in avoiding
spurious aborts and costs something real in identifying what kind of conflict
occurred. A coarse map lumps items together and so reports the abundant
conflict class more often, which happens to be right more often.

Around that:

- **`blind` — relation-granularity locking, storing nothing — has the best
  conflict-class agreement of anything in the study**, 68.93%, ahead of every
  sweep configuration and well ahead of the unimplementable `oracle` at
  62.60%. It also has the worst a-error, 5.41, and never once meets the
  target. The two readouts of the same map rank the strategies in opposite
  orders, which is the Leis-style critique reproduced in a different domain.
- `oracle`, the same `group` map built on the block being served instead of on
  the window, reaches 1.28 and meets the target in 100% of blocks against 60%
  for the best implementable configuration. It is also *cheaper at runtime*
  than the map it is compared against — 155.9 bits per transaction against
  207.5 — because a map that is not stale forms fewer spurious edges and so
  examines fewer neighbours.
- `cascade` costs **4.2x** the bits of the `group_sgt_320` map it refines
  (862.7 against 207.4), improves a-error by 0.8% (2.514 against 2.534), and
  buys **exactly 0.00** class agreement: both report 63.80%. Charging the full
  contingency table it had to build in order to choose a cell is what makes
  the trade visible.
- **Staleness dominates resolution.** Quadrupling the budget from 80 to 320
  improves train-era a-error by a factor of 2.2 (3.14 to 1.42) and final-era
  a-error by only 1.2 (5.49 to 4.59). Holding the map fixed and moving from
  the train era to the final era costs a factor of 3.2 on the same 320 map.
  Spending bits on resolution is worth much less than spending them on
  freshness.
- The false-conflict share makes the mechanism explicit: at budget 320, 20% of
  the edges the certifier forms are artefacts of the map in the train era and
  66% in the final era. The certifier is not becoming confused; it is being
  fed conflicts that do not exist.
- The visibility convention changes which configuration wins. Under `si` and
  `stale` it is `group_fcw_320`; under `rc` it is `hot_sgt_320`, at 20% fewer
  bits. Reporting one convention would have reported a different best
  strategy.
- The contention profile really does move: the Kolmogorov-Smirnov statistic
  between epoch 0 and epoch 5 is 0.601, and epoch 5 places 69.9% of its
  operations in the top rank bin against 16.2% for epoch 0.

## The invariant worth knowing about

`fcw` consults write-write conflicts and nothing else, and those are a
property of the commit order alone, which no visibility convention touches.
So every `fcw` configuration and `blind` must report **bit-identical** a-error
metrics under `si`, `rc` and `stale`, while their `bits_per_txn` and
`class_agreement_pct` must differ. Layer V9 checks both halves. A solver that
collapses the conventions passes the first half and fails the second; one that
makes everything vary fails the first. It is the single cheapest structural
check in the suite and the one most likely to catch a plausible-looking wrong
implementation.
