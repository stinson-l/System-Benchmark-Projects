# Conflict certification and lock granularity under contention drift

A concurrency-control certifier decides, for each transaction reaching its
commit point, whether committing it would violate the isolation level the
system claims to provide. The decision rests on a summary of what other
transactions touched. Tracking every item individually is exact and expensive;
tracking coarser units is cheap and produces conflicts that do not exist. The
summary is built on recent history and applied to a workload that has since
moved.

This task quantifies the resulting trade-off along four axes at once: the
granularity of the contention summary, the certification rule applied to it,
the visibility convention under which reads resolve, and the age of the
history the summary was built from.

The design follows a line of work that is by now standard. Gray, Lorie,
Putzolu and Traiger (1975) set out the granularity hierarchy and the cost of
choosing a level; Gray, Lorie, Putzolu and Traiger (1976) the degrees of
consistency. Berenson, Bernstein, Gray, Melton, O'Neil and O'Neil (1995)
showed that the ANSI phenomena underdetermine the levels they were meant to
define, and Adya (1999) gave portable definitions (PL-1, PL-2, PL-3 and the
phenomena G0, G1a-G1c, G2) in terms of the dependency graph rather than
locking. Bernstein, Hadzilacos and Goodman (1987) is the reference for
serialization graph testing. Fekete, Liarokapis, O'Neil, O'Neil and Shasha
(TODS 2005) characterised the dangerous structure -- two consecutive
read-write anti-dependencies into a pivot -- whose absence makes snapshot
isolation serializable; Cahill, Röhm and Fekete (SIGMOD 2008, TODS 2009)
turned that characterisation into a runtime test, and Ports and Grittner
(VLDB 2012) reported what happens when the test is implemented over summarised
rather than exact predicate locks, which is precisely the regime studied here.

Nothing below requires familiarity with those papers. Everything needed is
specified.

**This document is authoritative.** Where it and any other file disagree,
this document governs.

---

## 1. Fixed parameters

All parameters are given in `params.json` and are not to be tuned.

| Parameter | Value | Meaning |
|---|---|---|
| `relations` | `["r1","r2","r3","r4"]` | the four relations |
| `n_items` | `{r1:512, r2:256, r3:128, r4:384}` | items per relation |
| `window_blocks` | 6 | blocks of history a map is built from |
| `group_budgets` | `[80, 160, 320]` | total conflict keys across relations |
| `sample_ops` | 320 | operations retained by the `sampled` structure |
| `target_a_error` | 2.0 | a block is *within target* at or below this |
| `gate_multiple` | 1.25 | trigger gate = target x this = 2.5 |
| `stale_lag` | 4 | sequence lag of the `stale` convention |
| `renyi_alpha` | 2.5 | order of the Rényi concentration index |
| `n_epochs` | 6 | epochs the schedule is divided into |
| `control_piles` | `{r1:7, r2:11, r3:13, r4:5}` | pile counts of the control deal |
| `audit_steps` | `[0, 8, 16, 24]` | certification steps re-examined per stream |

A budget of B is a budget of **B/4 conflict keys per relation**, so the three
budgets give 20, 40 and 80 keys per relation.

---

## 2. Inputs

`oplog.csv` — 21,600 rows, one per operation.

| Column | Meaning |
|---|---|
| `op_id` | identifier, zero-padded, ascending |
| `block` | 0..35 |
| `txn_id` | transaction, unique within its block |
| `op_index` | position within the transaction, 0..11 |
| `op_seq` | position within the block, ascending |
| `op_kind` | `R` or `W` |
| `rel` | relation touched |
| `item_id` | item touched, 0-based within the relation |

`txn.csv` — 1,800 rows, one per transaction: `block`, `txn_id`, `begin_seq`,
`commit_seq`, `n_ops`. Sequence numbers are on the block's own clock.

`rel_catalog.csv` — 4 rows: `rel`, `n_items`.

`truth.csv` — 1,800 rows, one per transaction. `true_ww`, `true_wr`, `true_rw`
count the dependency edges incident on that transaction when the schedule is
read at **item granularity** under the `si` convention, counting each ordered
pair once per edge kind. `true_abort` is 1 if the reference certifier of
section 15 aborts it.

`params.json` — the table in section 1.

`sched.db` — the four tables above as SQLite. It carries no information the
CSV files do not.

The schedule has 36 blocks of 50 transactions of 12 operations each. Every
transaction begins and commits within its own block; no dependency crosses a
block boundary. Blocks 0-5 are the initial window and are never evaluated, so
there are **30 evaluation blocks**, 6 through 35.

---

## 3. Cost accounting

Every structure is charged in bits. The unit cost of an integer is its
bit length: the number of times it can be halved before reaching zero, so
`bits(0) = 0`, `bits(1) = 1`, `bits(3600) = 12`. Report the derived widths.

- `item_bits[r] = bits(n_items[r] - 1)` — 9, 8, 7, 9 for r1..r4.
- `count_bits = bits(600 * 6) = bits(3600) = 12`, an access count over the
  six-block window.
- `block_bits = bits(600) = 10`, an access count within one served block.

A **group entry** stores the two item identifiers bounding the group and two
counts (the group's total and its distinct-item count):
`2 * item_bits[r] + 2 * count_bits`.

An **individual entry** stores one item identifier and one count:
`item_bits[r] + count_bits`.

A **catalogue header** stores one count per relation, so `4 * count_bits`.

The budget ceiling for budget B is therefore

```
budget_bits[B] = (B/4) * sum_r (2*item_bits[r] + 2*count_bits) + 4*count_bits
```

giving 3,288, 6,528 and 13,008 bits for B = 80, 160 and 320. Equi-depth
assignment never splits an item across two groups, so the keys actually formed
may fall short of the budget and the charge with them; the ceiling is a
ceiling, not the charge.

`bits_per_txn` for a configuration is

```
( map_bits  +  sum over certification steps of bits(neighbours_examined) )
/ 50
```

averaged over the 30 evaluation blocks, where `neighbours_examined` is the
number of **distinct** already-committed transactions of the block joined to
the one being certified by at least one edge in either direction. The second
term is the runtime charge: a certifier that consults more of the graph pays
more, whatever its map cost.

---

## 4. Certification, aborts, and the a-error

Transactions of a block are certified in ascending `(commit_seq, txn_id)`.
At each step the certifier sees only transactions already **committed** in
this pass; an aborted transaction leaves no trace and is never a neighbour of
anything certified after it. The decision is to commit or abort, taken by the
scheme of section 6 on the edges of section 5.

Let `act` be the number of aborts a configuration takes in a block and `nec`
the number required, `nec = max(1, sum of true_abort over the block)`. With
`a = max(act, 1)`, the block's **a-error** is

```
a_error = max(a, nec) / min(a, nec)
```

It is at least 1, and it is symmetric: aborting five transactions where two
were required is penalised exactly as aborting one where two were required.
Aborting too little is as wrong as aborting too much, because the first
sacrifices isolation and the second sacrifices throughput, and the task takes
no position on which is worse.

`nec` comes from the frozen truth table, never from the certifier.

---

## 5. Dependency edges

Edges are defined on the frozen schedule and depend on the map only through
which operations share a **conflict key**. Two operations conflict when the
map sends them to the same key; at item granularity that is the same item, and
at coarser granularity it may not be.

Write `com(t)` for `commit_seq` and `beg(t)` for `begin_seq`. Order writers by
`(com, txn_id)`. For each conflict key:

- **ww**, mask bit 1: for every pair of transactions writing the key, an edge
  from the earlier to the later in that order.
- **wr**, mask bit 2: for each transaction `v` reading the key, an edge from
  the **visible writer** — the greatest in `(com, txn_id)` among the writers
  of that key visible to `v` — to `v`. A transaction's repeated reads of one
  key count once, positioned at its earliest such read. If no writer is
  visible there is no wr edge.
- **rw**, bit 4: for each reader `v` of the key and every writer `w != v` of
  that key **not** visible to `v`, an edge from `v` to `w`.

Self-edges are discarded. Multiple bits between one ordered pair are combined
by bitwise or.

Only rw edges can point backwards in commit order, and that is exactly what
allows a cycle to exist at all.

Visibility is fixed by the convention of section 8.

---

## 6. Certification schemes

Four schemes. `P` denotes the already-committed predecessors of the
transaction `t` being certified and `S` its already-committed successors. A
transaction `u` is **concurrent** with `t` when `com(u) > beg(t)`.

- **`fcw`** — first-committer-wins. Abort `t` if any `u` in `P` is joined to
  it by a ww edge and is concurrent with it. This consults ww edges and
  nothing else.
- **`danger`** — the Fekete/Cahill pivot test. Abort `t` if it has both an
  incoming rw edge from a concurrent committed transaction and an outgoing rw
  edge to one. This is the runtime form of the dangerous structure: `t` is the
  pivot of two consecutive anti-dependencies.
- **`sgt`** — serialization graph testing. Abort `t` if committing it would
  close a cycle: if some `v` in `S` equals some `u` in `P`, or if `v` reaches
  `u` in the transitive closure of the committed graph.
- **`mix`** — `danger` when the trigger of section 7 is armed, `fcw`
  otherwise.

The closure is maintained incrementally. On committing `t`, let `P*` be `P`
together with everything reaching `P`, and `S*` be `S` together with
everything reachable from `S`. Add `x -> t` for `x` in `P*`, `t -> y` for `y`
in `S*`, and `x -> y` for every such pair with `x != y`.

---

## 7. The feedback trigger

For each arm and configuration, the trigger is **armed at block `i`** when
that configuration's own a-error at block `i - 1`, **read under the `si`
convention only**, exceeds `target_a_error * gate_multiple = 2.5`. It is
disarmed at the first evaluation block.

The trigger is armed by the `si` reading even when the configuration is being
evaluated under `rc` or `stale`. This is deliberate and is the one place where
the three variants are not independent: a production certifier has one
feedback path, not one per reporting convention, and the reported divergence
between variants under `mix` is a real consequence of that.

Report `trigger_rate`: the fraction of (configuration, evaluation block) pairs
across the sweep at which the trigger was armed.

---

## 8. Visibility conventions — the three variants

A write is visible to a read under exactly one of three rules. Let `u` be the
writer, `v` the reader, and `s` the sequence number of `v`'s earliest read of
the key.

- **`si`** — snapshot isolation: visible iff `com(u) < beg(v)`. The reader
  sees the state as of its own start.
- **`rc`** — read committed: visible iff `com(u) < s`. The reader sees
  whatever had committed by the moment it read.
- **`stale`** — a lagging snapshot: visible iff `com(u) < beg(v) - 4`. The
  reader's snapshot is four sequence positions behind its start.

The convention moves wr and rw edges and moves nothing else. Write-write
conflicts are a property of the commit order alone. Consequently every `fcw`
configuration — and `blind`, which is `fcw` at relation granularity — must
report **identical** a-error metrics under all three conventions. Its
`bits_per_txn` and `class_agreement_pct` will differ, because both read the
edge set the convention does move. This invariant is checked.

The full sweep is run once per convention.

---

## 9. Map families

A **contention map** sends each `(relation, item)` to a conflict key. Every
relation has a fallback key covering items the map never saw, so an unseen
item still conflicts with the rest of its relation.

Maps are built from the access counts of the **six blocks preceding** the
block being served, never from the block itself.

- **`group`** — equi-depth grouping. Within a relation, items present in the
  window are taken in ascending item order, and the item whose cumulative
  count before it is `c`, out of `n` total, is assigned group
  `floor(c * B / n)` where `B = budget/4`. No item is split, so fewer than `B`
  groups may result.
- **`hot`** — the `B - B/4` items with the highest window counts, ties broken
  by ascending item, are tracked individually; the remainder are grouped
  equi-depth into `B/4` groups by the same rule.

Both families are built at all three budgets, and each is certified under all
four schemes: **2 families x 4 schemes x 3 budgets = 24 configurations**,
named `<family>_<scheme>_<budget>`.

Report `mean_groups_used`: the mean number of keys formed, over the sweep's
maps and the evaluation blocks.

---

## 10. Four further structures

Each is evaluated under one scheme only and is reported alongside the sweep,
not within it.

- **`blind`** — relation granularity. Every item of a relation shares one
  key. Map cost 0 bits. Scheme `fcw`. This is the floor: what a system that
  stores nothing and locks whole relations achieves.
- **`sampled`** — 320 operations selected from the window by position:
  stride `floor(window_ops / 320)` from the first, in `op_id` order, taking
  the first 320. Every distinct `(relation, item)` among them is tracked
  individually; everything else falls to its relation's fallback. Charged
  `bits(3) + item_bits[r] + 1` per retained operation, **including
  duplicates** — a sample pays for what it drew, not for what it kept.
  Scheme `sgt`.
- **`oracle`** — `group` at the largest budget, built on the **block being
  served** rather than on the window, with counts charged at `block_bits`.
  Not implementable; it isolates staleness by removing it. Scheme `sgt`.
- **`cascade`** — `group` at the largest budget, then refined. For each of
  the six relation pairs, transaction footprints are taken at group
  granularity and every cell `(key_x, key_y)` is scored
  `|n * n_xy - n_x * n_y|`, where `n` is the number of transactions in the
  window, `n_xy` the number touching both keys and `n_x`, `n_y` the numbers
  touching each. The pair with the greatest total score is selected, and
  within it the single highest-scoring cell, ties broken by ascending
  `(key_x, key_y)`. Every window-present item of both of that cell's keys is
  promoted to individual tracking. Charged the base map, plus one individual
  entry per promoted item, plus `2 * bits(B/4 - 1) + count_bits` for **every**
  cell of the selected pair — the contingency table had to be built before the
  cell could be chosen. Scheme `sgt`.

`cascade` is included because the intuition it embodies — find the correlated
region and refine it — is standard, and the task is interested in what it
actually buys once its full cost is charged.

---

## 11. The control arm

The 24 sweep configurations are run a second time on a **control map**, built
identically except that each relation's window access-count vector is
permuted before the map is built.

The permutation is a deal into piles and involves no random number generator.
Within a relation, let the items present in the window be indexed
`j = 0, 1, ...` in ascending item order, and let `P` be that relation's pile
count from `control_piles`. Sort the indices by `(j mod P, j)`; the item at
rank `k` of the ascending item order receives the count that sat at index
`order[k]`.

The multiset of counts is unchanged. Only the association between item and
count is destroyed. Any advantage the treatment arm shows over the control is
therefore attributable to knowing **which** items are contended, not to
spending bits, not to the shape of the count distribution, and not to the
number of keys formed — all three are identical between the arms.

---

## 12. Metrics

Seven metrics per configuration per arm per convention, each averaged over the
30 evaluation blocks unless stated otherwise.

| Metric | Definition |
|---|---|
| `mean_a_error` | mean of the block a-errors |
| `p95_a_error` | 95th percentile, linear interpolation |
| `max_a_error` | maximum |
| `pct_within_target` | fraction of blocks with a-error <= 2.0 |
| `excess_ratio` | mean of `max(0, a_error - 2.0) / 2.0` |
| `bits_per_txn` | section 3 |
| `class_agreement_pct` | see below |

**Conflict-class agreement.** At each certification step the certifier counts
the ww, wr and rw edges incident on the transaction among already-committed
transactions, in both directions, and names the **dominant class**: `WW` if
its ww count is at least both others, else `WR` if its wr count is at least
its rw count, else `RW`. The truth table's `true_ww`, `true_wr`, `true_rw` are
reduced to a dominant class by the identical rule. `class_agreement_pct` is
the percentage of transactions whose classes match.

This is a second readout of the same map, deliberately not the one the
decision uses. A certifier can abort the right transactions while being wrong
about why, and the task reports both.

**Diagnostics**, per convention: `best_config` (lowest `mean_a_error` in the
treatment sweep, ties broken by ascending name), `best_mean_a_error`,
`best_bits_per_txn`, `cost_vs_blind_pct`
(`100 * (best_bits - blind_bits) / blind_bits`), `mean_class_agreement_pct`
over the sweep, `mean_groups_used`, `trigger_rate`, `n_eval_blocks`, and
`invalid_decisions_audited`.

**The audit.** At the four `audit_steps` of each evaluation block, for every
stream, re-examine the decision just taken and count it invalid if it
consulted any transaction not already committed in that pass, or if it aborted
under `fcw` or `danger` with no qualifying edge present. A correct
implementation reports 0.

---

## 13. Significance

Per convention and per family, the 12 treatment configurations of that family
are compared against their 12 controls, **paired by configuration** so that
scheme and budget are held fixed within each pair and the map is the only
thing that differs. Four metrics: `mean_a_error`, `p95_a_error`,
`bits_per_txn`, `class_agreement_pct`.

Each metric has a direction: lower is better for the a-errors and for
`bits_per_txn`, higher is better for `class_agreement_pct`. Signed values
below are the metric multiplied by `-1` in the first three cases and `+1` in
the last, so that greater is better throughout.

- `t_test_p` — one-sided paired t-test over the 12 signed pairs, with the
  alternative that the treatment is **greater**, i.e. better. A p-value near 1
  is not a null result: it is evidence in the opposite direction.
- `treatment_rank`, `control_rank` — mean ranks over the 12 pairs, ranking the
  two arms within each pair, **1 for the better and 2 for the worse**, ties at
  1.5. The two ranks sum to 3.
- `nemenyi_p` — the two-method Nemenyi p-value from the mean-rank difference:
  `q = |R_t - R_c| / sqrt(k(k+1)/(6N))` with `k = 2` methods and `N = 12`
  pairs, so `q = |R_t - R_c| * sqrt(12)`, and
  `p = erfc(|q| / sqrt(2))`, capped at 1.

The two tests answer different questions — one about the size of the gap, one
about how consistently one arm wins — and they are reported together because
they can disagree. A treatment that wins narrowly in eleven configurations and
loses badly in one takes rank 1 and a poor t-test p-value, and that is a real
distinction worth seeing.

---

## 14. Output structure

`/app/results.json`, one JSON object, exactly three top-level keys.

```
schedule_report
  n_ops, n_transactions, n_blocks, n_eval_blocks, n_window_blocks
  n_relations, n_txn_per_block, ops_per_txn
  count_bits, block_bits
  item_bits          { "r1": int, ... "r4": int }
  budgets            [80, 160, 320]
  budget_bits        { "80": int, "160": int, "320": int }
  required_aborts    int      sum of true_abort
  mean_true_edges    float    mean of true_ww + true_wr + true_rw
  schema_stats       { "80": {...}, "160": {...}, "320": {...} }

drift_report
  epoch_share_matrix              6 x 6   list of lists
  conditional_epoch_share_matrix  6 x 6
  epoch_ks_matrix                 6 x 6
  decile_share_pct                { "D0".."D9": { "E0".."E5": float } }

variants
  si | rc | stale
    strategy_metrics   { <28 names>: { <7 metrics> } }
    control_metrics    { <24 names>: { <7 metrics> } }
    significance       { "group" | "hot": { <4 metrics>:
                         { t_test_p, treatment_rank, control_rank,
                           nemenyi_p } } }
    diagnostics        { <10 fields of section 12> }
```

`strategy_metrics` holds the 24 sweep configurations plus `blind`, `sampled`,
`oracle` and `cascade`. `control_metrics` holds the 24 sweep configurations
only.

`schema_stats[B]` reports the **reference pass** of section 15: `groups_used`,
`map_bits_per_txn`, and for each of the train and final eras
`a_error_<era>_era`, `abort_rate_<era>_era`, `class_agreement_<era>_era`,
`false_conflict_share_<era>_era`, `renyi_<era>_era`.

---

## 15. The reference pass and the drift report

**The reference pass.** One `group` map per budget is built **once** on the
train era (blocks 0-5) and applied unchanged to the train era and to the final
era (blocks 30-35), certified under `sgt` and read under `si`. Everything
except the era is held fixed, so the difference between the eras is drift and
nothing else.

`abort_rate` is aborts over transactions. `false_conflict_share` is the
fraction of edges the certifier **formed** that do not exist: each formed
edge, at each step, is compared bit by bit and in its own direction against
the edge the same ordered pair carries under item granularity and `si`.
`renyi` is the Rényi entropy of order 2.5 of the era's access distribution
over `(relation, item)`, normalised by `log K` where `K` is the number of
distinct pairs the era touched.

The reference certifier that produces `true_abort` is `sgt` at item
granularity under `si`, run over the whole block in commit order.

**The drift report.** Each operation carries a statistic: the
access-frequency rank of its `(relation, item)` in the train era, ranked by
descending count then ascending relation then ascending item, starting at 1.
A pair the train era never touched takes rank `n_train + 1`, so newly
contended items are tied at the top of the scale rather than dropped.

The 36 blocks divide into 6 epochs of 6. Bin edges are the interior quantiles
of the **epoch-0** statistics, by linear interpolation between the bracketing
order statistics; a value falls in the bin given by the number of edges at or
below it. `epoch_share_matrix` uses 6 bins and `decile_share_pct` uses 10,
each row summing to 1 (or to 100). `conditional_epoch_share_matrix` zeroes
the diagonal and renormalises each row. `epoch_ks_matrix[i][j]` is the
two-sample Kolmogorov-Smirnov statistic between the raw statistics of epochs
`i` and `j`, zero on the diagonal.

---

## 16. Conventions

Ranks use mean ranks for ties. Percentiles use linear interpolation. Integer
division floors. Bit lengths are as section 3. Ties in `best_config` break by
ascending name. All averages over blocks are unweighted means over the 30
evaluation blocks. No random number generator is used anywhere in this
specification; every procedure described as a shuffle, a deal or a sample is
a deterministic function of the inputs.

---

## 17. What `truth.csv` licenses

`truth.csv` is the ground truth of the schedule. It may be used for exactly
two purposes: as `nec` in the a-error of section 4, and as the reference
classes of `class_agreement_pct` in section 12.

It must not inform any map, any certification decision, any promotion in
`cascade`, any sample, or the trigger. A certifier that consults it has
answered a different question. The audit of section 12 and the layered
verifier both check the decision path; the `oracle` structure exists precisely
so that the value of information the certifier cannot have is reported openly,
as a number, rather than leaking into configurations that claim to be
implementable.
