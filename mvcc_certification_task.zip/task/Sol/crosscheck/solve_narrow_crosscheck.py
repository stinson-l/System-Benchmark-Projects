"""
Narrow crosscheck: an independent re-derivation of 38 reported quantities.

    python solve_narrow_crosscheck.py <data_dir> <out_path>

This file shares no code with the reference solution and issues no SQL.  It
was written from SPEC.md, and it takes a different route to the same numbers.
The reference holds the transitive closure of each committed graph as a
relation and tests for a cycle by joining that relation against the incoming
and outgoing neighbours of the transaction being certified; here the closure
is a dense boolean matrix, the test is an indexed submatrix reduction, and the
closure is extended by a boolean outer product rather than by three INSERT
statements.  Dependency edges there are a grouped union of three self-joins
over an operation-key relation; here they are accumulated conflict key by
conflict key into three (T, T) masks.  Equi-depth assignment, the control
permutation and the bit-length cost model are likewise recomputed rather than
shared.

Its purpose is not coverage.  It is to establish that the specification is
sufficient -- that a second implementation, reading only the prose, lands on
the same numbers.  Quantities are chosen to isolate one mechanism each: the
cost accounting, the two map families, the three visibility conventions, the
four certification schemes, the trigger recursion, the conflict-class
comparison, the control permutation, the four reference structures, the
reference-era pass and the drift binning.  A mismatch therefore points
somewhere rather than merely reporting that something is wrong.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

BIG = 1 << 30
RELS = ("r1", "r2", "r3", "r4")
RIX = {r: i for i, r in enumerate(RELS)}
PAIRS = [(a, b) for i, a in enumerate(RELS) for b in RELS[i + 1:]]


def blen(v: int) -> int:
    return int(v).bit_length()


# --------------------------------------------------------------------- maps
class Cmap:
    """A contention map: key[relation index][item] -> conflict key.

    Keys 0..3 are the per-relation fallbacks, so an item the map never saw
    still has a key and still conflicts with the rest of its relation.
    """

    __slots__ = ("key", "bits", "used")

    def __init__(self, maxitems):
        self.key = np.tile(np.arange(4, dtype=np.int64)[:, None],
                           (1, maxitems))
        self.bits = 0
        self.used = 0


def equidepth(c: np.ndarray, B: int) -> np.ndarray:
    """Group index of each present item, in ascending item order."""
    n = int(c.sum())
    cb = np.concatenate(([0], np.cumsum(c)[:-1])).astype(np.int64)
    return (cb * B) // n


def build_map(cnt, B, fam, nitems, cb_bits, item_bits, maxitems):
    m = Cmap(maxitems)
    nxt = 4
    m.bits = 4 * cb_bits                       # one count per relation
    for r in RELS:
        i = RIX[r]
        present = np.nonzero(cnt[i, :nitems[r]])[0]
        if present.size == 0:
            continue
        c = cnt[i, present]
        ib = item_bits[r]
        if fam == "group":
            gid = equidepth(c, B)
            for g in np.unique(gid):
                m.key[i, present[gid == g]] = nxt
                nxt += 1
                m.used += 1
                m.bits += 2 * ib + 2 * cb_bits
        else:
            nhot = B - B // 4
            order = np.lexsort((present, -c))
            hot, res = order[:nhot], np.sort(order[nhot:])
            for h in hot:
                m.key[i, present[h]] = nxt
                nxt += 1
                m.used += 1
                m.bits += ib + cb_bits
            if res.size:
                gid = equidepth(c[res], B // 4)
                for g in np.unique(gid):
                    m.key[i, present[res][gid == g]] = nxt
                    nxt += 1
                    m.used += 1
                    m.bits += 2 * ib + 2 * cb_bits
    return m


def permute(cnt, piles, nitems):
    """Control arm.  Within each relation the window's access counts are
    dealt into P piles over the items present, in ascending item order, and
    read back pile by pile.  A permutation, not a resample: the multiset of
    counts is unchanged and only their attachment to items moves."""
    out = cnt.copy()
    for r in RELS:
        i = RIX[r]
        present = np.nonzero(cnt[i, :nitems[r]])[0]
        if present.size == 0:
            continue
        j = np.arange(present.size)
        order = np.lexsort((j, j % piles[r]))
        out[i, present] = cnt[i, present][order]
    return out


def build_sampled(wops, n_keep, nitems, item_bits, maxitems):
    m = Cmap(maxitems)
    stride = len(wops) // n_keep
    sel = wops.iloc[np.arange(0, len(wops), stride)[:n_keep]]
    m.bits = int(sum(blen(3) + item_bits[r] + 1 for r in sel["rel"]))
    nxt = 4
    for r, it in zip(sel["rel"], sel["item_id"]):
        i = RIX[r]
        if m.key[i, int(it)] < 4:
            m.key[i, int(it)] = nxt
            nxt += 1
            m.used += 1
    return m


def build_cascade(cnt, B, nitems, cb_bits, item_bits, maxitems, wops):
    """group/B, then promote to individual tracking every item of the single
    most dependent cell of the most dependent relation pair."""
    m = build_map(cnt, B, "group", nitems, cb_bits, item_bits, maxitems)
    keys = m.key[wops["rix"].to_numpy(), wops["item_id"].to_numpy()]
    fp = pd.DataFrame({"txn": wops["txn_id"].to_numpy(),
                       "rix": wops["rix"].to_numpy(),
                       "key": keys}).drop_duplicates()
    n = wops["txn_id"].nunique()
    best, bpair, bcell, ncell = -1, None, None, 0
    for (x, y) in PAIRS:
        fx, fy = fp[fp.rix == RIX[x]], fp[fp.rix == RIX[y]]
        nx = fx.groupby("key").txn.nunique()
        ny = fy.groupby("key").txn.nunique()
        j = fx.merge(fy, on="txn", suffixes=("_x", "_y"))
        nxy = j.groupby(["key_x", "key_y"]).txn.nunique()
        tot, cv, cell = 0, -1, None
        for (kx, ky), v in nxy.items():
            d = abs(n * int(v) - int(nx[kx]) * int(ny[ky]))
            tot += d
            if d > cv or (d == cv and (kx, ky) < cell):
                cv, cell = d, (kx, ky)
        if tot > best:
            best, bpair, bcell, ncell = tot, (x, y), cell, len(nxy)
    if bpair is None:
        return m
    nxt = int(m.key.max()) + 1
    for rel, kk in zip(bpair, bcell):
        i = RIX[rel]
        for it in np.nonzero((m.key[i, :nitems[rel]] == kk)
                             & (cnt[i, :nitems[rel]] > 0))[0]:
            m.key[i, it] = nxt
            nxt += 1
            m.used += 1
            m.bits += item_bits[rel] + cb_bits
    m.bits += ncell * (2 * blen(B - 1) + cb_bits)
    return m


# -------------------------------------------------------------------- edges
def edge_masks(bops, key, pos, beg, com, vis, lag):
    """Three (T, T) boolean matrices for one block, one map, one convention.

    Bit semantics are those of SPEC.md section 6: ww between two writers of a
    key in commit order, wr from the visible writer to the reader, rw from a
    reader to every writer of that key it could not see.  Only rw can point
    backwards in commit order, which is what lets a cycle exist at all.
    """
    T = len(beg)
    ww = np.zeros((T, T), bool)
    wr = np.zeros((T, T), bool)
    rw = np.zeros((T, T), bool)
    kk = key[bops["rix"].to_numpy(), bops["item_id"].to_numpy()]
    ti = np.array([pos[int(t)] for t in bops["txn_id"]])
    isw = bops["op_kind"].to_numpy() == "W"
    sq = bops["op_seq"].to_numpy()

    wset, rmin = {}, {}
    for k, t, w, s in zip(kk, ti, isw, sq):
        if w:
            wset.setdefault(k, set()).add(int(t))
        else:
            d = rmin.setdefault(k, {})
            if t not in d or s < d[int(t)]:
                d[int(t)] = int(s)

    def seen(u, v, s):
        if vis == "si":
            return com[u] < beg[v]
        if vis == "stale":
            return com[u] < beg[v] - lag
        return com[u] < s

    for k, ws in wset.items():
        wl = sorted(ws, key=lambda t: (com[t], t))
        for a in range(len(wl)):
            for b in range(a + 1, len(wl)):
                ww[wl[a], wl[b]] = True
        for v, s in rmin.get(k, {}).items():
            vis_w = [u for u in wl if u != v and seen(u, v, s)]
            if vis_w:
                wr[max(vis_w, key=lambda t: (com[t], t)), v] = True
            for w in wl:
                if w != v and not seen(w, v, s):
                    rw[v, w] = True
    return ww, wr, rw


# ------------------------------------------------------------------ certify
def certify(order, ww, wr, rw, scheme, beg, com, armed):
    """One certification pass.  Returns aborts, summed bit-length of the
    neighbour counts examined, and the per-transaction dominant class."""
    T = len(beg)
    anye = ww | wr | rw
    reach = np.zeros((T, T), bool)
    comm = np.zeros(T, bool)
    sch = ("danger" if armed else "fcw") if scheme == "mix" else scheme
    ab = nex = 0
    cls = np.empty(T, dtype="<U2")
    conc = np.array(com)[:, None] > np.array(beg)[None, :]
    for t in order:
        P = anye[:, t] & comm
        S = anye[t, :] & comm
        n1 = int((ww[:, t] & comm).sum() + (ww[t, :] & comm).sum())
        n2 = int((wr[:, t] & comm).sum() + (wr[t, :] & comm).sum())
        n4 = int((rw[:, t] & comm).sum() + (rw[t, :] & comm).sum())
        cls[t] = "WW" if n1 >= n2 and n1 >= n4 else ("WR" if n2 >= n4
                                                     else "RW")
        nex += blen(int((P | S).sum()))
        if sch == "fcw":
            bad = bool((ww[:, t] & comm & conc[:, t]).any())
        elif sch == "danger":
            bad = bool((rw[:, t] & comm & conc[:, t]).any()
                       and (rw[t, :] & comm & conc[:, t]).any())
        else:
            bad = bool((P & S).any() or reach[np.ix_(S, P)].any())
        if bad:
            ab += 1
            continue
        comm[t] = True
        Pc = P | reach[:, P].any(axis=1)
        Sc = S | reach[S, :].any(axis=0)
        reach[Pc, t] = True
        reach[t, Sc] = True
        reach |= np.outer(Pc, Sc)
        np.fill_diagonal(reach, False)
    return ab, nex, cls


def a_error(act: int, nec: int) -> float:
    lo, hi = max(act, 1), max(1, nec)
    return max(lo, hi) / min(lo, hi)


def dominant(a, b, c):
    return "WW" if a >= b and a >= c else ("WR" if b >= c else "RW")


# --------------------------------------------------------------------- main
def main(argv):
    data, out = Path(argv[1]), Path(argv[2])
    P = json.loads((data / "params.json").read_text())
    ops = pd.read_csv(data / "oplog.csv")
    txn = pd.read_csv(data / "txn.csv")
    cat = pd.read_csv(data / "rel_catalog.csv")
    truth = pd.read_csv(data / "truth.csv")
    ops["rix"] = ops["rel"].map(RIX)
    nitems = dict(zip(cat.rel, cat.n_items))
    maxit = max(nitems.values())
    ibits = {r: blen(nitems[r] - 1) for r in RELS}
    W = P["window_blocks"]
    nblk = int(ops.block.max()) + 1
    nq = int((txn.block == 0).sum())
    nopsb = int((ops.block == 0).sum())
    cb = blen(nopsb * W)
    ob = blen(nopsb)
    lag, gate = P["stale_lag"], P["target_a_error"] * P["gate_multiple"]
    epl = nblk // P["n_epochs"]
    BW = max(P["group_budgets"]) // 4

    nec = truth.groupby("block").true_abort.sum().to_dict()
    tdom = {(int(r.block), int(r.txn_id)):
            dominant(r.true_ww, r.true_wr, r.true_rw)
            for r in truth.itertuples()}

    def counts(frame):
        c = np.zeros((4, maxit), np.int64)
        np.add.at(c, (frame["rix"].to_numpy(), frame["item_id"].to_numpy()), 1)
        return c

    # one stream per mechanism under test
    want = [("blind", "fcw", "si"), ("sampled", "sgt", "si"),
            ("oracle", "sgt", "si"), ("cascade", "sgt", "si"),
            ("t_group_80", "fcw", "si"), ("t_group_320", "sgt", "si"),
            ("t_hot_320", "fcw", "si"), ("t_hot_320", "danger", "si"),
            ("t_group_160", "mix", "si"),
            ("c_group_320", "sgt", "si"), ("t_group_320", "sgt", "rc"),
            ("t_group_320", "sgt", "stale")]
    acc = {w: [] for w in want}
    used_acc = []
    armed: dict = {}

    for blk in range(W, nblk):
        wops = ops[(ops.block >= blk - W) & (ops.block < blk)]
        bops = ops[ops.block == blk]
        btx = txn[txn.block == blk].sort_values("txn_id")
        pos = {int(t): i for i, t in enumerate(btx.txn_id)}
        beg = btx.begin_seq.to_numpy()
        com = btx.commit_seq.to_numpy()
        order = [pos[int(t)] for t in
                 btx.sort_values(["commit_seq", "txn_id"]).txn_id]

        ct = counts(wops)
        cc = permute(ct, P["control_piles"], nitems)
        M = {}
        for tag, c in (("t", ct), ("c", cc)):
            for fam in ("group", "hot"):
                for bud in P["group_budgets"]:
                    M[f"{tag}_{fam}_{bud}"] = build_map(
                        c, bud // 4, fam, nitems, cb, ibits, maxit)
        M["blind"] = Cmap(maxit)
        M["sampled"] = build_sampled(wops, P["sample_ops"], nitems, ibits,
                                     maxit)
        M["oracle"] = build_map(counts(bops), BW, "group", nitems, ob, ibits,
                                maxit)
        M["cascade"] = build_cascade(ct, BW, nitems, cb, ibits, maxit, wops)

        used_acc.append(float(np.mean(
            [M[f"t_{f}_{b}"].used for f in ("group", "hot")
             for b in P["group_budgets"]])))

        n = max(1, int(nec.get(blk, 0)))
        for w in want:
            mk, sch, vis = w
            m = M[mk]
            cfg = mk if mk in ("blind", "sampled", "oracle", "cascade") else \
                "%s_%s_%s" % (mk.split("_")[1], sch, mk.split("_")[2])
            ww, wr, rw = edge_masks(bops, m.key, pos, beg, com, vis, lag)
            ab, nex, cls = certify(order, ww, wr, rw, sch, beg, com,
                                   armed.get((mk, cfg), False))
            ae = a_error(ab, n)
            agree = float(np.mean([cls[pos[int(t)]] == tdom[(blk, int(t))]
                                   for t in btx.txn_id])) * 100.0
            acc[w].append((ae, (m.bits + nex) / nq, agree))
            if vis == "si":
                armed[(mk, cfg)] = ae > gate

    def col(w, i):
        return float(np.mean([x[i] for x in acc[w]]))

    # ------------------------------------------------------- reference eras
    rm = build_map(counts(ops[ops.block < epl]), BW, "group", nitems, cb,
                   ibits, maxit)
    exact = np.arange(4, 4 + 4 * maxit, dtype=np.int64).reshape(4, maxit)
    era = {}
    for tag, blocks in (("train", range(epl)),
                        ("final", range(nblk - epl, nblk))):
        aes, fcs = [], []
        for blk in blocks:
            bops = ops[ops.block == blk]
            btx = txn[txn.block == blk].sort_values("txn_id")
            pos = {int(t): i for i, t in enumerate(btx.txn_id)}
            beg, com = btx.begin_seq.to_numpy(), btx.commit_seq.to_numpy()
            order = [pos[int(t)] for t in
                     btx.sort_values(["commit_seq", "txn_id"]).txn_id]
            got = edge_masks(bops, rm.key, pos, beg, com, "si", lag)
            real = edge_masks(bops, exact, pos, beg, com, "si", lag)
            ab, _, _ = certify(order, *got, "sgt", beg, com, False)
            aes.append(a_error(ab, max(1, int(nec.get(blk, 0)))))
            # replay the same prefix to attribute every formed edge
            T = len(beg)
            comm = np.zeros(T, bool)
            reach = np.zeros((T, T), bool)
            anye = got[0] | got[1] | got[2]
            tot = wrong = 0
            for t in order:
                Pv, Sv = anye[:, t] & comm, anye[t, :] & comm
                for g, x in zip(got, real):
                    inc = g[:, t] & comm
                    tot += int(inc.sum())
                    wrong += int((inc & ~x[:, t]).sum())
                    ouc = g[t, :] & comm
                    tot += int(ouc.sum())
                    wrong += int((ouc & ~x[t, :]).sum())
                if bool((Pv & Sv).any() or reach[np.ix_(Sv, Pv)].any()):
                    continue
                comm[t] = True
                Pc = Pv | reach[:, Pv].any(axis=1)
                Sc = Sv | reach[Sv, :].any(axis=0)
                reach[Pc, t] = True
                reach[t, Sc] = True
                reach |= np.outer(Pc, Sc)
                np.fill_diagonal(reach, False)
            fcs.append(wrong / max(1, tot))
        era[tag] = (float(np.mean(aes)), float(np.mean(fcs)))

    tro = ops[ops.block < epl]
    c = tro.groupby(["rel", "item_id"]).size().to_numpy().astype(float)
    p = c / c.sum()
    al = P["renyi_alpha"]
    renyi = float(np.log(np.power(p, al).sum()) / (1 - al) / np.log(len(p)))

    # ------------------------------------------------------------ the drift
    tc = tro.groupby(["rel", "item_id"]).size().reset_index(name="c")
    tc = tc.sort_values(["c", "rel", "item_id"], ascending=[False, True, True])
    rank = {(r.rel, r.item_id): i + 1
            for i, r in enumerate(tc.itertuples(index=False))}
    stat = np.array([rank.get((r, i), len(rank) + 1)
                     for r, i in zip(ops["rel"], ops["item_id"])], float)
    ep = ops["block"].to_numpy() // epl
    edg = np.percentile(stat[ep == 0], np.arange(1, 6) * 100.0 / 6)
    b = np.searchsorted(edg, stat, side="right")

    res = {
        "block_bits": ob,
        "budget_bits_320": int(BW * sum(2 * ibits[r] + 2 * cb for r in RELS)
                               + 4 * cb),
        "count_bits": cb,
        "epoch_share_0_0": float(np.mean(b[ep == 0] == 0)),
        "epoch_share_5_5": float(np.mean(b[ep == 5] == 5)),
        "item_bits_r1": ibits["r1"],
        "item_bits_r3": ibits["r3"],
        "mean_groups_used": float(np.mean(used_acc)),
        "mean_true_edges": float((truth.true_ww + truth.true_wr
                                  + truth.true_rw).mean()),
        "n_blocks": nblk,
        "n_ops": int(len(ops)),
        "n_transactions": int(len(txn)),
        "n_txn_per_block": nq,
        "rc_group_sgt_320_a_error": col(("t_group_320", "sgt", "rc"), 0),
        "ref320_a_error_final_era": era["final"][0],
        "ref320_a_error_train_era": era["train"][0],
        "ref320_false_conflict_share_final_era": era["final"][1],
        "ref320_false_conflict_share_train_era": era["train"][1],
        "ref320_groups_used": float(rm.used),
        "ref320_map_bits_per_txn": rm.bits / nq,
        "renyi_train_era": renyi,
        "required_aborts": int(truth.true_abort.sum()),
        "si_blind_a_error": col(("blind", "fcw", "si"), 0),
        "si_blind_bits_per_txn": col(("blind", "fcw", "si"), 1),
        "si_blind_class_agreement": col(("blind", "fcw", "si"), 2),
        "si_cascade_a_error": col(("cascade", "sgt", "si"), 0),
        "si_cascade_bits_per_txn": col(("cascade", "sgt", "si"), 1),
        "si_control_group_sgt_320_a_error": col(("c_group_320", "sgt", "si"),
                                                0),
        "si_group_fcw_80_a_error": col(("t_group_80", "fcw", "si"), 0),
        "si_group_mix_160_a_error": col(("t_group_160", "mix", "si"), 0),
        "si_group_sgt_320_a_error": col(("t_group_320", "sgt", "si"), 0),
        "si_group_sgt_320_class_agreement": col(("t_group_320", "sgt", "si"),
                                                2),
        "si_hot_danger_320_a_error": col(("t_hot_320", "danger", "si"), 0),
        "si_hot_fcw_320_a_error": col(("t_hot_320", "fcw", "si"), 0),
        "si_oracle_a_error": col(("oracle", "sgt", "si"), 0),
        "si_sampled_a_error": col(("sampled", "sgt", "si"), 0),
        "si_sampled_bits_per_txn": col(("sampled", "sgt", "si"), 1),
        "stale_group_sgt_320_a_error": col(("t_group_320", "sgt", "stale"), 0),
    }
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(res, indent=1, sort_keys=True) + "\n")
    print(f"wrote {out} ({len(res)} quantities)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
