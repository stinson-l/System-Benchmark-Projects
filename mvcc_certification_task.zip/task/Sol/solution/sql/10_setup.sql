-- Constant relations the rest of the pipeline joins against.  Nothing here
-- depends on the schedule; everything here is fixed by SPEC.md and
-- params.json.

CREATE TABLE widths(bw INTEGER PRIMARY KEY);
INSERT INTO widths VALUES (20),(40),(80);

CREATE TABLE visibility(vis TEXT PRIMARY KEY, ord INTEGER);
INSERT INTO visibility VALUES ('si',0),('rc',1),('stale',2);

CREATE TABLE schemes(scheme TEXT PRIMARY KEY);
INSERT INTO schemes VALUES ('fcw'),('danger'),('sgt'),('mix');

CREATE TABLE binsets(nbins INTEGER PRIMARY KEY);
INSERT INTO binsets VALUES (6),(10);

CREATE TABLE kseq(k INTEGER PRIMARY KEY);
WITH RECURSIVE q(k) AS (SELECT 0 UNION ALL SELECT k+1 FROM q WHERE k < 9)
INSERT INTO kseq SELECT k FROM q;

CREATE TABLE piles(rel TEXT PRIMARY KEY, piles INTEGER);
CREATE TABLE itembits(rel TEXT PRIMARY KEY, ibits INTEGER);
CREATE TABLE relidx(rel TEXT PRIMARY KEY, rix INTEGER);
CREATE TABLE trig(arm TEXT, cfg TEXT, fired INTEGER);

-- The 17 contention maps.  mapid 0 is the exact item-granularity map, which
-- no configuration uses; it exists so that the false-conflict accounting of
-- SPEC.md section 14 has something to compare a formed edge against.
CREATE TABLE maps(mapid INTEGER PRIMARY KEY, arm TEXT, fam TEXT,
                  bw INTEGER, name TEXT);

-- One row per certification stream: a map read under one visibility
-- convention and certified under one scheme.
CREATE TABLE stream(sid INTEGER PRIMARY KEY, mapid INTEGER, vis TEXT,
                    arm TEXT, cfg TEXT, scheme TEXT, needs_reach INTEGER,
                    track_formed INTEGER DEFAULT 0);

-- Which maps the edge stage builds a graph for.  The main walk activates all
-- seventeen; the reference pass of section 14 activates only the exact map
-- and the three era maps it compares against it.
CREATE TABLE activemap(mapid INTEGER PRIMARY KEY);

-- Edges a certifier actually formed, kept only for the reference pass, where
-- the false-conflict share needs them.
CREATE TABLE formed(sid INTEGER, txn INTEGER, node INTEGER, mask INTEGER,
                    dir TEXT);

-- Integer bit lengths by repeated halving, so that no reported code width
-- depends on a logarithm.
CREATE TABLE bitlen AS
WITH RECURSIVE nums(v) AS (
        SELECT 0 UNION ALL SELECT v+1 FROM nums WHERE v < 4200),
walk(v, x, b) AS (
        SELECT v, v, 0 FROM nums
        UNION ALL SELECT v, x/2, b+1 FROM walk WHERE x > 0)
SELECT v, MAX(b) AS b FROM walk GROUP BY v;
CREATE UNIQUE INDEX ix_bitlen ON bitlen(v);

-- Working state of the certification pass.  These are re-used across every
-- step rather than created and dropped, which keeps the per-step cost in the
-- joins rather than in the schema.
CREATE TABLE comm(sid INTEGER, txn INTEGER);
CREATE UNIQUE INDEX ix_comm ON comm(sid, txn);
CREATE TABLE reach(sid INTEGER, u INTEGER, v INTEGER);
CREATE UNIQUE INDEX ix_reach ON reach(sid, u, v);
CREATE INDEX ix_reach_v ON reach(sid, v);
CREATE TABLE pe(sid INTEGER, node INTEGER, mask INTEGER);
CREATE INDEX ix_pe ON pe(sid, node);
CREATE TABLE se(sid INTEGER, node INTEGER, mask INTEGER);
CREATE INDEX ix_se ON se(sid, node);
CREATE TABLE pcx(sid INTEGER, x INTEGER);
CREATE UNIQUE INDEX ix_pcx ON pcx(sid, x);
CREATE TABLE scx(sid INTEGER, y INTEGER);
CREATE UNIQUE INDEX ix_scx ON scx(sid, y);
CREATE TABLE dcs(sid INTEGER PRIMARY KEY, abort INTEGER, nex INTEGER,
                 ww INTEGER, wr INTEGER, rw INTEGER);
CREATE TABLE dec(txn INTEGER, sid INTEGER, abort INTEGER, nex INTEGER,
                 ww INTEGER, wr INTEGER, rw INTEGER);
CREATE INDEX ix_dec ON dec(sid);

CREATE INDEX ix_oplog_blk ON oplog(block);
CREATE INDEX ix_txn_blk ON txn(block);
CREATE INDEX ix_truth_blk ON truth(block, txn_id);
