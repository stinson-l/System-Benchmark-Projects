-- Contention maps for the block about to be served.
--
-- Everything a certifier knows about the data comes from here: which items
-- share a conflict key.  A map is built from the six blocks strictly
-- preceding :blk, except the oracle map, which is built from :blk itself.

DROP TABLE IF EXISTS tb;
DROP TABLE IF EXISTS win;
DROP TABLE IF EXISTS svd;
DROP TABLE IF EXISTS wv;
DROP TABLE IF EXISTS src;
DROP TABLE IF EXISTS gasg;
DROP TABLE IF EXISTS hasg;
DROP TABLE IF EXISTS mapkey;
DROP TABLE IF EXISTS mapent;
DROP TABLE IF EXISTS mapbits;
DROP TABLE IF EXISTS samp;
DROP TABLE IF EXISTS fp;
DROP TABLE IF EXISTS nmarg;
DROP TABLE IF EXISTS njoint;
DROP TABLE IF EXISTS promote;

-- ---------------------------------------------------------------- row sets
CREATE TEMP TABLE tb AS
SELECT txn_id, begin_seq, commit_seq FROM txn WHERE block = :blk;
CREATE UNIQUE INDEX ix_tb ON tb(txn_id);

CREATE TEMP TABLE win AS
SELECT o.op_id, o.txn_id, o.op_seq, o.op_kind, o.rel, o.item_id, r.rix
FROM   oplog o JOIN relidx r ON r.rel = o.rel
WHERE  o.block >= :blk - :w AND o.block < :blk;

CREATE TEMP TABLE svd AS
SELECT o.op_id, o.txn_id, o.op_seq, o.op_kind, o.rel, o.item_id, r.rix
FROM   oplog o JOIN relidx r ON r.rel = o.rel
WHERE  o.block = :blk;
CREATE INDEX ix_svd ON svd(rel, item_id);

-- ------------------------------------------------- window access counts
-- The control arm deals each relation's count vector into P piles: the
-- value of rank r receives the count that sat at index j, where r is the
-- rank of (j mod P, j).  The multiset of counts and the set of accessed
-- items both survive; only the association between the two is destroyed.
CREATE TEMP TABLE wv AS
WITH raw AS (
    SELECT rel, item_id, COUNT(*) cnt FROM win GROUP BY rel, item_id),
idx AS (
    SELECT rel, item_id, cnt,
           ROW_NUMBER() OVER (PARTITION BY rel ORDER BY item_id) - 1 AS j
    FROM raw),
perm AS (
    SELECT i.rel, i.j,
           ROW_NUMBER() OVER (PARTITION BY i.rel
                              ORDER BY (i.j % p.piles), i.j) - 1 AS r
    FROM idx i JOIN piles p ON p.rel = i.rel)
SELECT 't' AS arm, rel, item_id, cnt FROM idx
UNION ALL
SELECT 'c', v.rel, v.item_id, c.cnt
FROM   perm pm
JOIN   idx v ON v.rel = pm.rel AND v.j = pm.r
JOIN   idx c ON c.rel = pm.rel AND c.j = pm.j;

-- 't' window treatment, 'c' window control, 'o' the served block itself
CREATE TEMP TABLE src AS
SELECT arm AS srcid, rel, item_id, cnt FROM wv
UNION ALL
SELECT 'o', rel, item_id, COUNT(*) FROM svd GROUP BY rel, item_id;

-- ------------------------------------------------------- equi-depth groups
-- Item v joins group (cum_before(v) * bw) / n by integer division, so an
-- item never straddles two groups and no boundary depends on a float.
CREATE TEMP TABLE gasg AS
WITH tot AS (SELECT srcid, rel, SUM(cnt) n FROM src GROUP BY srcid, rel),
cum AS (
    SELECT s.srcid, s.rel, s.item_id, s.cnt,
           COALESCE(SUM(s.cnt) OVER (PARTITION BY s.srcid, s.rel
               ORDER BY s.item_id
               ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING), 0) AS cb
    FROM src s)
SELECT c.srcid, c.rel, w.bw, c.item_id, c.cnt, (c.cb * w.bw) / t.n AS gid
FROM   cum c JOIN tot t ON t.srcid = c.srcid AND t.rel = c.rel
CROSS JOIN widths w;

-- ------------------------------------------- hot list plus grouped residue
CREATE TEMP TABLE hasg AS
WITH rk AS (
    SELECT s.srcid, s.rel, s.item_id, s.cnt,
           ROW_NUMBER() OVER (PARTITION BY s.srcid, s.rel
                              ORDER BY s.cnt DESC, s.item_id) - 1 AS r
    FROM src s WHERE s.srcid IN ('t','c')),
tag AS (
    SELECT rk.srcid, rk.rel, rk.item_id, rk.cnt, w.bw,
           CASE WHEN rk.r < w.bw - w.bw/4 THEN 1 ELSE 0 END AS ishot
    FROM rk CROSS JOIN widths w),
res AS (
    SELECT srcid, rel, bw, item_id, cnt,
           COALESCE(SUM(cnt) OVER (PARTITION BY srcid, rel, bw
               ORDER BY item_id
               ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING), 0) AS cb,
           SUM(cnt) OVER (PARTITION BY srcid, rel, bw) AS n
    FROM tag WHERE ishot = 0)
SELECT srcid, rel, bw, item_id, 1 AS ishot, -1 AS gid FROM tag WHERE ishot = 1
UNION ALL
SELECT srcid, rel, bw, item_id, 0, (cb * (bw/4)) / n FROM res;

-- ------------------------------------------------------------- the samples
-- Systematic positional selection over the window ordered by op_id.  The
-- first retained operation is always position 0 of the window, whichever
-- blocks the window covers; op_id is a zero-padded string, so this is a
-- position test and not an arithmetic test on the identifier.
CREATE TEMP TABLE samp AS
SELECT rel, item_id, rix FROM (
    SELECT rel, item_id, rix, ROW_NUMBER() OVER (ORDER BY op_id) - 1 AS pos
    FROM win)
WHERE pos % :stride = 0 ORDER BY pos LIMIT :ns;

-- ------------------------------------------------------------ the map body
CREATE TEMP TABLE mapkey AS
SELECT d.mapid, g.rel, g.item_id, r.rix*1000000 + 1000 + g.gid AS keyid
FROM   gasg g
JOIN   mapdef d ON d.srcid = g.srcid AND d.fam = 'group' AND d.bw = g.bw
JOIN   relidx r ON r.rel = g.rel
UNION ALL
SELECT d.mapid, h.rel, h.item_id,
       CASE WHEN h.ishot = 1 THEN r.rix*1000000 + 500000 + h.item_id
            ELSE r.rix*1000000 + 1000 + h.gid END
FROM   hasg h
JOIN   mapdef d ON d.srcid = h.srcid AND d.fam = 'hot' AND d.bw = h.bw
JOIN   relidx r ON r.rel = h.rel
UNION ALL
SELECT DISTINCT 0, rel, item_id, rix*1000000 + 500000 + item_id FROM svd
UNION ALL
SELECT DISTINCT 14, rel, item_id, rix*1000000 + 500000 + item_id FROM samp;

-- ------------------------------------- cascade: the most dependent pair
-- Transaction footprints at the base map's group granularity, then the
-- integer contingency deviation over every relation pair.
CREATE TEMP TABLE fp AS
SELECT DISTINCT w.txn_id, w.rix, k.keyid
FROM   win w JOIN mapkey k
       ON k.mapid = :basemap AND k.rel = w.rel AND k.item_id = w.item_id;

CREATE TEMP TABLE nmarg AS
SELECT rix, keyid, COUNT(DISTINCT txn_id) AS nx FROM fp GROUP BY rix, keyid;

CREATE TEMP TABLE njoint AS
SELECT a.rix AS rx, a.keyid AS kx, b.rix AS ry, b.keyid AS ky,
       COUNT(DISTINCT a.txn_id) AS nxy
FROM   fp a JOIN fp b ON b.txn_id = a.txn_id AND b.rix > a.rix
GROUP BY a.rix, a.keyid, b.rix, b.keyid;

CREATE TEMP TABLE promote AS
WITH dev AS (
    SELECT j.rx, j.kx, j.ry, j.ky,
           ABS(:ntxnw * j.nxy - mx.nx * my.nx) AS d
    FROM   njoint j
    JOIN   nmarg mx ON mx.rix = j.rx AND mx.keyid = j.kx
    JOIN   nmarg my ON my.rix = j.ry AND my.keyid = j.ky),
best AS (
    SELECT rx, ry, SUM(d) AS tot, COUNT(*) AS cells
    FROM   dev GROUP BY rx, ry
    ORDER BY tot DESC, rx, ry LIMIT 1),
cell AS (
    SELECT d.rx, d.kx, d.ry, d.ky FROM dev d JOIN best b
           ON b.rx = d.rx AND b.ry = d.ry
    ORDER BY d.d DESC, d.kx, d.ky LIMIT 1)
SELECT k.rel, k.item_id, (SELECT cells FROM best) AS cells
FROM   mapkey k JOIN relidx r ON r.rel = k.rel
JOIN   cell c ON (r.rix = c.rx AND k.keyid = c.kx)
              OR (r.rix = c.ry AND k.keyid = c.ky)
WHERE  k.mapid = :basemap;

UPDATE mapkey
SET    keyid = (SELECT r.rix*1000000 + 500000 + mapkey.item_id
                FROM relidx r WHERE r.rel = mapkey.rel)
WHERE  mapid = 16
  AND  EXISTS (SELECT 1 FROM promote p
               WHERE p.rel = mapkey.rel AND p.item_id = mapkey.item_id);

CREATE INDEX ix_mapkey ON mapkey(mapid, rel, item_id);

-- --------------------------------------------------------- what it costs
-- An individual entry stores one item and one count; a group entry stores
-- two boundary items and two counts.  Every map carries a header of one
-- count per relation in the catalog, which is a property of the schema and
-- not of the window.
CREATE TEMP TABLE mapent AS
SELECT mapid, rel, keyid, COUNT(*) AS nitems
FROM   mapkey GROUP BY mapid, rel, keyid;

CREATE TEMP TABLE mapbits AS
SELECT m.mapid,
       COALESCE(SUM(CASE WHEN e.keyid % 1000000 >= 500000
                         THEN ib.ibits + c.cb
                         ELSE 2*ib.ibits + 2*c.cb END), 0)
       + :nrel * c.cb AS bits,
       COUNT(e.keyid) AS used
FROM   maps m JOIN mapcb c ON c.mapid = m.mapid
LEFT JOIN mapent e ON e.mapid = m.mapid
LEFT JOIN itembits ib ON ib.rel = e.rel
WHERE  m.mapid NOT IN (0, 13, 14, 16)
GROUP BY m.mapid;

-- blind stores nothing: the relation is the conflict key, which the schema
-- already names.
INSERT INTO mapbits VALUES (13, 0, 0);
INSERT INTO mapbits VALUES (0, 0, 0);

-- the sample is charged per retained operation, not per distinct item
INSERT INTO mapbits
SELECT 14, (SELECT SUM(:relbits + ib.ibits + 1) FROM samp s
            JOIN itembits ib ON ib.rel = s.rel),
       (SELECT COUNT(*) FROM mapent WHERE mapid = 14);

-- cascade pays for the base grouping, the occupied cells of the joint, and
-- the promoted items; the group entries it refines are still charged.
INSERT INTO mapbits
SELECT 16,
       (SELECT bits FROM mapbits WHERE mapid = :basemap)
       + (SELECT COALESCE(SUM(ib.ibits + :cb), 0) FROM promote p
          JOIN itembits ib ON ib.rel = p.rel)
       + (SELECT COALESCE(MAX(cells), 0) FROM promote)
         * (2 * (SELECT b FROM bitlen WHERE v = :bigbw - 1) + :cb),
       (SELECT used FROM mapbits WHERE mapid = :basemap)
       + (SELECT COALESCE(COUNT(*), 0) FROM promote);
