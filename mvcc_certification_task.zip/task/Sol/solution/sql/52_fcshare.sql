-- What share of the edges a certifier formed do not exist at all.
--
-- An edge is formed when two operations share a conflict key.  When the map
-- is coarse they may share a key without sharing an item, and the edge is an
-- artefact of the map rather than a dependency of the schedule.  The exact
-- map (mapid 0) is the arbiter: every formed edge is compared, bit by bit
-- and in its own direction, against the edge the same ordered pair has under
-- item granularity and the si convention.

DROP TABLE IF EXISTS fcshare;

CREATE TEMP TABLE fcshare AS
WITH ebits(b) AS (VALUES (1),(2),(4)),
f AS (
    SELECT s.cfg, fm.txn, fm.node, fm.mask,
           CASE WHEN fm.dir = 'p' THEN fm.node ELSE fm.txn END AS eu,
           CASE WHEN fm.dir = 'p' THEN fm.txn ELSE fm.node END AS ev
    FROM   formed fm JOIN stream s ON s.sid = fm.sid)
SELECT f.cfg,
       SUM(CASE WHEN f.mask & b.b > 0 THEN 1 ELSE 0 END) AS formed,
       SUM(CASE WHEN f.mask & b.b > 0
                 AND COALESCE(e.mask, 0) & b.b = 0 THEN 1 ELSE 0 END) AS wrong
FROM   f CROSS JOIN ebits b
LEFT JOIN edge e ON e.mapid = 0 AND e.vis = 'si'
                AND e.u = f.eu AND e.v = f.ev
GROUP BY f.cfg;
