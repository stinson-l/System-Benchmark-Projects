-- The dependency graph of the block, once per map and per visibility
-- convention.
--
-- Edges are a property of the recorded schedule, not of any certifier's
-- outcome: a certifier looks at the subgraph its committed set induces.
-- Mask bits are 1 ww, 2 wr, 4 rw.

DROP TABLE IF EXISTS opkey;
DROP TABLE IF EXISTS wset;
DROP TABLE IF EXISTS rset;
DROP TABLE IF EXISTS edge;

-- An operation's conflict key under each map.  An item the map never saw
-- falls back to its relation, which is the coarsest key the schema affords.
CREATE TEMP TABLE opkey AS
SELECT m.mapid, s.txn_id, s.op_kind, s.op_seq,
       COALESCE(k.keyid, s.rix*1000000) AS ck
FROM   svd s CROSS JOIN activemap m
LEFT JOIN mapkey k
       ON k.mapid = m.mapid AND k.rel = s.rel AND k.item_id = s.item_id;

CREATE TEMP TABLE wset AS
SELECT DISTINCT mapid, ck, txn_id FROM opkey WHERE op_kind = 'W';
CREATE INDEX ix_wset ON wset(mapid, ck);

-- A transaction's repeated reads of one key count once, positioned at its
-- earliest read of that key.
CREATE TEMP TABLE rset AS
SELECT mapid, ck, txn_id, MIN(op_seq) AS rseq
FROM   opkey WHERE op_kind = 'R' GROUP BY mapid, ck, txn_id;
CREATE INDEX ix_rset ON rset(mapid, ck);

CREATE TEMP TABLE edge AS
WITH srcs AS (
    -- ww: two writers of one key, oriented by commit order
    SELECT a.mapid, vi.vis, a.txn_id AS u, b.txn_id AS w, 1 AS mask
    FROM   wset a
    JOIN   wset b ON b.mapid = a.mapid AND b.ck = a.ck
                 AND b.txn_id <> a.txn_id
    JOIN   tb ta ON ta.txn_id = a.txn_id
    JOIN   tb tbb ON tbb.txn_id = b.txn_id
    CROSS JOIN visibility vi
    WHERE  ta.commit_seq < tbb.commit_seq
        OR (ta.commit_seq = tbb.commit_seq AND a.txn_id < b.txn_id)

    UNION ALL
    -- wr: the version read is the visible writer with the greatest
    -- (commit_seq, txn_id)
    SELECT mapid, vis, u, w, 2 FROM (
        SELECT r.mapid, vi.vis, x.txn_id AS u, r.txn_id AS w,
               ROW_NUMBER() OVER (
                   PARTITION BY r.mapid, vi.vis, r.ck, r.txn_id
                   ORDER BY tw.commit_seq DESC, x.txn_id DESC) AS rn
        FROM   rset r CROSS JOIN visibility vi
        JOIN   wset x ON x.mapid = r.mapid AND x.ck = r.ck
                     AND x.txn_id <> r.txn_id
        JOIN   tb tw ON tw.txn_id = x.txn_id
        JOIN   tb tv ON tv.txn_id = r.txn_id
        WHERE  (vi.vis = 'si'    AND tw.commit_seq < tv.begin_seq)
            OR (vi.vis = 'stale' AND tw.commit_seq < tv.begin_seq - :lag)
            OR (vi.vis = 'rc'    AND tw.commit_seq < r.rseq))
    WHERE rn = 1

    UNION ALL
    -- rw: a write the reader's snapshot did not include
    SELECT r.mapid, vi.vis, r.txn_id, x.txn_id, 4
    FROM   rset r CROSS JOIN visibility vi
    JOIN   wset x ON x.mapid = r.mapid AND x.ck = r.ck
                 AND x.txn_id <> r.txn_id
    JOIN   tb tw ON tw.txn_id = x.txn_id
    JOIN   tb tv ON tv.txn_id = r.txn_id
    WHERE  NOT ((vi.vis = 'si'    AND tw.commit_seq < tv.begin_seq)
             OR (vi.vis = 'stale' AND tw.commit_seq < tv.begin_seq - :lag)
             OR (vi.vis = 'rc'    AND tw.commit_seq < r.rseq)))
SELECT mapid, vis, u, w AS v,
       MAX(mask & 1) + MAX(mask & 2) + MAX(mask & 4) AS mask
FROM   srcs GROUP BY mapid, vis, u, w;

CREATE INDEX ix_edge_v ON edge(mapid, vis, v);
CREATE INDEX ix_edge_u ON edge(mapid, vis, u);
