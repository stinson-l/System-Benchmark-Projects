-- How the contention profile moves.
--
-- The statistic attached to an operation is the train-era access-frequency
-- rank of the item it touches.  An item the train era never saw takes rank
-- n_train + 1, so items that appear only later are all tied at the top of
-- the scale rather than being dropped.

DROP TABLE IF EXISTS opstat;
DROP TABLE IF EXISTS qtiles;
DROP TABLE IF EXISTS shares;

CREATE TEMP TABLE opstat AS
WITH tc AS (
    SELECT rel, item_id, COUNT(*) AS c FROM oplog
    WHERE block < :ep_len GROUP BY rel, item_id),
rk AS (
    SELECT rel, item_id,
           ROW_NUMBER() OVER (ORDER BY c DESC, rel, item_id) AS r FROM tc),
nt AS (SELECT COUNT(*) AS n FROM tc)
SELECT o.block / :ep_len AS epoch,
       COALESCE(rk.r, (SELECT n + 1 FROM nt)) * 1.0 AS stat
FROM   oplog o
LEFT JOIN rk ON rk.rel = o.rel AND rk.item_id = o.item_id;
CREATE INDEX ix_opstat ON opstat(epoch);

-- Interior quantiles of the train-era statistic, with linear interpolation
-- between the two order statistics that bracket the requested position.
CREATE TEMP TABLE qtiles AS
WITH tr AS (
    SELECT stat, ROW_NUMBER() OVER (ORDER BY stat) - 1 AS i
    FROM   opstat WHERE epoch = 0),
nn AS (SELECT COUNT(*) AS n FROM tr),
pk AS (SELECT b.nbins, k.k FROM binsets b JOIN kseq k ON k.k < b.nbins - 1),
h AS (SELECT pk.nbins, pk.k,
             (nn.n - 1) * (pk.k + 1) * 1.0 / pk.nbins AS hh
      FROM pk CROSS JOIN nn)
SELECT h.nbins, h.k,
       lo.stat + (h.hh - CAST(h.hh AS INTEGER)) * (hi.stat - lo.stat) AS edge
FROM   h
JOIN   tr lo ON lo.i = CAST(h.hh AS INTEGER)
JOIN   tr hi ON hi.i = MIN(CAST(h.hh AS INTEGER) + 1,
                           (SELECT n - 1 FROM nn));

-- A value falls in the bin given by the number of edges at or below it.
CREATE TEMP TABLE shares AS
WITH ep AS (SELECT k AS epoch FROM kseq WHERE k < :n_ep),
bn AS (SELECT b.nbins, k.k AS bin FROM binsets b JOIN kseq k
       ON k.k < b.nbins),
tot AS (SELECT epoch, COUNT(*) AS n FROM opstat GROUP BY epoch),
asg AS (
    SELECT o.epoch, q.nbins,
           (SELECT COUNT(*) FROM qtiles e
            WHERE e.nbins = q.nbins AND e.edge <= o.stat) AS bin
    FROM   opstat o CROSS JOIN binsets q),
cnt AS (SELECT epoch, nbins, bin, COUNT(*) AS c
        FROM asg GROUP BY epoch, nbins, bin)
SELECT ep.epoch, bn.nbins, bn.bin,
       COALESCE(c.c, 0) * 1.0 / t.n AS share
FROM   ep CROSS JOIN bn
JOIN   tot t ON t.epoch = ep.epoch
LEFT JOIN cnt c ON c.epoch = ep.epoch AND c.nbins = bn.nbins
                AND c.bin = bn.bin;
