-- The reference map of SPEC.md section 14: the `group` family at each
-- budget, certified under `sgt` and read under `si`, built once on the train
-- era and then applied to the train era and to the final era.
--
-- Nothing here is part of the sweep.  Its purpose is to hold everything
-- except the era fixed, so that the difference between the two eras is
-- drift and nothing else.

DROP TABLE IF EXISTS refsrc;
DROP TABLE IF EXISTS refmap;
DROP TABLE IF EXISTS refbits;

CREATE TABLE refsrc AS
SELECT o.rel, o.item_id, COUNT(*) AS cnt
FROM   oplog o WHERE o.block < :ep_len GROUP BY o.rel, o.item_id;

CREATE TABLE refmap AS
WITH tot AS (SELECT rel, SUM(cnt) n FROM refsrc GROUP BY rel),
cum AS (
    SELECT s.rel, s.item_id, s.cnt,
           COALESCE(SUM(s.cnt) OVER (PARTITION BY s.rel ORDER BY s.item_id
               ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING), 0) AS cb
    FROM   refsrc s)
SELECT 'ref_' || (w.bw * 4) AS cfg, 100 + w.bw AS mapid, c.rel, c.item_id,
       r.rix*1000000 + 1000 + (c.cb * w.bw) / t.n AS keyid
FROM   cum c JOIN tot t ON t.rel = c.rel
CROSS JOIN widths w JOIN relidx r ON r.rel = c.rel;

CREATE INDEX ix_refmap ON refmap(mapid, rel, item_id);

CREATE TABLE refbits AS
WITH ent AS (
    SELECT cfg, mapid, rel, keyid FROM refmap GROUP BY cfg, mapid, rel, keyid)
SELECT e.cfg, e.mapid,
       SUM(2*ib.ibits + 2*:cb) + :nrel * :cb AS bits,
       COUNT(*) AS used
FROM   ent e JOIN itembits ib ON ib.rel = e.rel
GROUP BY e.cfg, e.mapid;

-- Re-point the certification machinery at the three reference streams.  The
-- exact map stays active so that a formed edge can be compared with a real
-- one.
DELETE FROM stream;
DELETE FROM activemap;
INSERT INTO activemap VALUES (0),(120),(140),(180);
INSERT INTO stream(sid, mapid, vis, arm, cfg, scheme, needs_reach,
                   track_formed)
SELECT ROW_NUMBER() OVER (ORDER BY mapid), mapid, 'si', 't', cfg, 'sgt', 1, 1
FROM   refbits;
INSERT INTO maps SELECT mapid, 't', 'group', mapid - 100, cfg FROM refbits;
