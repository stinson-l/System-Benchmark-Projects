-- Per-block setup for the reference pass.  The map does not change from
-- block to block -- that is the point of the pass -- so only the served
-- block and the exact comparison map are rebuilt here.

DROP TABLE IF EXISTS tb;
DROP TABLE IF EXISTS svd;
DROP TABLE IF EXISTS mapkey;
DROP TABLE IF EXISTS fcshare;
DELETE FROM formed;

CREATE TEMP TABLE tb AS
SELECT txn_id, begin_seq, commit_seq FROM txn WHERE block = :blk;
CREATE UNIQUE INDEX ix_tb ON tb(txn_id);

CREATE TEMP TABLE svd AS
SELECT o.op_id, o.txn_id, o.op_seq, o.op_kind, o.rel, o.item_id, r.rix
FROM   oplog o JOIN relidx r ON r.rel = o.rel
WHERE  o.block = :blk;
CREATE INDEX ix_svd ON svd(rel, item_id);

CREATE TEMP TABLE mapkey AS
SELECT mapid, rel, item_id, keyid FROM refmap
UNION ALL
SELECT DISTINCT 0, rel, item_id, rix*1000000 + 500000 + item_id FROM svd;
CREATE INDEX ix_mapkey ON mapkey(mapid, rel, item_id);
