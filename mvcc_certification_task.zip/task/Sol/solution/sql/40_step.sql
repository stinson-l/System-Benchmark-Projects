-- One certification step: transaction :t reaches its commit point in every
-- stream at once.
--
-- A stream sees only the subgraph its own committed set induces, so the
-- streams diverge as soon as one of them aborts something another kept.
-- The transitive closure is maintained incrementally, which is why the
-- cycle test below is a join and not a recursion.

DELETE FROM pe;
DELETE FROM se;
DELETE FROM dcs;
DELETE FROM pcx;
DELETE FROM scx;

INSERT INTO pe(sid, node, mask)
SELECT s.sid, e.u, e.mask
FROM   stream s
JOIN   edge e ON e.mapid = s.mapid AND e.vis = s.vis AND e.v = :t
JOIN   comm c ON c.sid = s.sid AND c.txn = e.u;

INSERT INTO se(sid, node, mask)
SELECT s.sid, e.v, e.mask
FROM   stream s
JOIN   edge e ON e.mapid = s.mapid AND e.vis = s.vis AND e.u = :t
JOIN   comm c ON c.sid = s.sid AND c.txn = e.v;

INSERT INTO dcs(sid, abort, nex, ww, wr, rw)
WITH eff AS (
    SELECT s.sid,
           CASE WHEN s.scheme = 'mix'
                THEN CASE WHEN COALESCE(g.fired, 0) = 1
                          THEN 'danger' ELSE 'fcw' END
                ELSE s.scheme END AS es
    FROM   stream s
    LEFT JOIN trig g ON g.arm = s.arm AND g.cfg = s.cfg),
inc AS (
    SELECT sid, node, mask FROM pe
    UNION ALL SELECT sid, node, mask FROM se),
cnt AS (
    SELECT sid,
           SUM(CASE WHEN mask & 1 > 0 THEN 1 ELSE 0 END) AS ww,
           SUM(CASE WHEN mask & 2 > 0 THEN 1 ELSE 0 END) AS wr,
           SUM(CASE WHEN mask & 4 > 0 THEN 1 ELSE 0 END) AS rw
    FROM   inc GROUP BY sid),
nn AS (
    SELECT sid, COUNT(*) AS nex
    FROM   (SELECT DISTINCT sid, node FROM inc) GROUP BY sid),
-- first-committer-wins: an overlapping write already committed
fw AS (
    SELECT DISTINCT p.sid FROM pe p JOIN tb u ON u.txn_id = p.node
    WHERE  p.mask & 1 > 0 AND u.commit_seq > :tbeg),
-- the dangerous structure: an incoming and an outgoing antidependency,
-- both to concurrent committed transactions, makes :t a pivot
di AS (
    SELECT DISTINCT p.sid FROM pe p JOIN tb u ON u.txn_id = p.node
    WHERE  p.mask & 4 > 0 AND u.commit_seq > :tbeg),
dg AS (
    SELECT DISTINCT x.sid FROM se x JOIN tb v ON v.txn_id = x.node
    WHERE  x.mask & 4 > 0 AND v.commit_seq > :tbeg),
-- serialization-graph testing: :t closes a cycle when some successor
-- already reaches some predecessor
cy AS (
    SELECT DISTINCT p.sid
    FROM   pe p JOIN se x ON x.sid = p.sid
    LEFT JOIN reach r ON r.sid = p.sid AND r.u = x.node AND r.v = p.node
    WHERE  x.node = p.node OR r.u IS NOT NULL)
SELECT e.sid,
       CASE e.es
         WHEN 'fcw' THEN
              CASE WHEN e.sid IN (SELECT sid FROM fw) THEN 1 ELSE 0 END
         WHEN 'danger' THEN
              CASE WHEN e.sid IN (SELECT sid FROM di)
                    AND e.sid IN (SELECT sid FROM dg) THEN 1 ELSE 0 END
         ELSE CASE WHEN e.sid IN (SELECT sid FROM cy) THEN 1 ELSE 0 END
       END,
       COALESCE(n.nex, 0), COALESCE(c.ww, 0),
       COALESCE(c.wr, 0), COALESCE(c.rw, 0)
FROM   eff e
LEFT JOIN cnt c ON c.sid = e.sid
LEFT JOIN nn n ON n.sid = e.sid;

INSERT INTO dec(txn, sid, abort, nex, ww, wr, rw)
SELECT :t, sid, abort, nex, ww, wr, rw FROM dcs;

INSERT INTO formed(sid, txn, node, mask, dir)
SELECT p.sid, :t, p.node, p.mask, 'p' FROM pe p
JOIN   stream s ON s.sid = p.sid AND s.track_formed = 1
UNION ALL
SELECT x.sid, :t, x.node, x.mask, 's' FROM se x
JOIN   stream s ON s.sid = x.sid AND s.track_formed = 1;

INSERT OR IGNORE INTO comm(sid, txn)
SELECT sid, :t FROM dcs WHERE abort = 0;

-- ------------------------------------------------- close the graph again
INSERT OR IGNORE INTO pcx(sid, x)
SELECT p.sid, p.node FROM pe p
JOIN   dcs d ON d.sid = p.sid AND d.abort = 0
JOIN   stream s ON s.sid = p.sid AND s.needs_reach = 1;

INSERT OR IGNORE INTO pcx(sid, x)
SELECT r.sid, r.u FROM reach r
JOIN   pe p ON p.sid = r.sid AND p.node = r.v
JOIN   dcs d ON d.sid = r.sid AND d.abort = 0
JOIN   stream s ON s.sid = r.sid AND s.needs_reach = 1;

INSERT OR IGNORE INTO scx(sid, y)
SELECT x.sid, x.node FROM se x
JOIN   dcs d ON d.sid = x.sid AND d.abort = 0
JOIN   stream s ON s.sid = x.sid AND s.needs_reach = 1;

INSERT OR IGNORE INTO scx(sid, y)
SELECT r.sid, r.v FROM reach r
JOIN   se x ON x.sid = r.sid AND x.node = r.u
JOIN   dcs d ON d.sid = r.sid AND d.abort = 0
JOIN   stream s ON s.sid = r.sid AND s.needs_reach = 1;

INSERT OR IGNORE INTO reach(sid, u, v) SELECT sid, x, :t FROM pcx;
INSERT OR IGNORE INTO reach(sid, u, v) SELECT sid, :t, y FROM scx;
INSERT OR IGNORE INTO reach(sid, u, v)
SELECT p.sid, p.x, s.y FROM pcx p JOIN scx s ON s.sid = p.sid
WHERE  p.x <> s.y;
