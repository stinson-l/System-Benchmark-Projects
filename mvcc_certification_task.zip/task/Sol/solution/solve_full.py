"""
Full-scope reference solution.

    python solve_full.py <data_dir> <out_path>

Reproduces the complete study on the frozen inputs: the schedule report and
its three reference maps, the drift report, three visibility conventions, 28
certifiers per convention, 24 control arms per convention, and the paired
significance panels.

Where the work happens
----------------------
Every quantity is computed by SQL against a SQLite database built from the
frozen CSVs.  This file loads the inputs, walks the 30 evaluation blocks in
order and, within each block, the 50 transactions in commit order, executing
the scripts in ``sql/`` at each point.  It contains no map construction, no
edge derivation, no certification and no cost accounting of its own.  The two
exceptions are named in SPEC.md section 13 and are library calls, not
reimplementations: ``scipy.stats.ttest_rel`` and the normal tail used by the
two-method Nemenyi reduction, plus ``scipy.stats.ks_2samp`` for the drift
matrix.

Determinism
-----------
  * group boundaries   assigned by ``(cumulative_count * bw) / n`` in integer
                       division, so an item never straddles two groups and no
                       boundary depends on a floating-point comparison.
  * merge of ties      the hot list orders by count descending then item
                       ascending; commit order is (commit_seq, txn_id); the
                       version a read sees is the visible writer with the
                       greatest (commit_seq, txn_id).  Every one of those is
                       an integer comparison.
  * code widths        bit lengths come from the ``bitlen`` relation, built
                       by repeated integer halving rather than a logarithm.
  * control arm        a deal-into-P-piles permutation of each relation's
                       window access-count vector.  No pseudo-random
                       generator is consumed anywhere in the study, so there
                       is no seed to agree on and no draw order to get wrong.

The trigger stream is the fragile part.  It is defined by the ``si``
convention and by the block before the one being served, so a solver that
recomputes it inside the convention loop, or that lets a convention feed back
into it, reproduces every ``fcw``, ``danger`` and ``sgt`` number and gets
every ``mix`` number wrong.  The cross-convention invariants in the verifier
exist for that.

The standalone ``crosscheck/solve_narrow_crosscheck.py`` re-derives 38 of
these quantities from the specification text alone, in NumPy, with no SQL and
no shared code, and agrees with this file to within 1e-12 relative.
"""

from __future__ import annotations

import json
import math
import sqlite3
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats as st

warnings.filterwarnings("ignore")

SQL = Path(__file__).resolve().parent / "sql"
VIS = ("si", "rc", "stale")
FAMILIES = ("group", "hot")
SCHEMES = ("fcw", "danger", "sgt", "mix")
STRUCTURES = ("blind", "cascade", "oracle", "sampled")
STRUCT_SCHEME = {"blind": "fcw", "cascade": "sgt", "oracle": "sgt",
                 "sampled": "sgt"}
SIG_METRICS = (("mean_a_error", -1), ("p95_a_error", -1),
               ("bits_per_txn", -1), ("class_agreement_pct", 1))


# --------------------------------------------------------------- plumbing
def register_math(con: sqlite3.Connection) -> None:
    """Provide POW and LN regardless of how SQLite was compiled.

    SQLite has shipped pow/ln since 3.35, but only when built with
    SQLITE_ENABLE_MATH_FUNCTIONS, which is a compile-time option and is absent
    from a number of common distributions.  Relying on the build would make
    the pipeline pass or fail depending on the container it lands in, so both
    are registered unconditionally as application-defined functions -- which
    take precedence over the built-ins where those exist.

    Both delegate to libm through the math module, the same library the
    built-ins call, so registering them does not perturb any reported value.
    """
    con.create_function("POW", 2, math.pow, deterministic=True)
    con.create_function("LN", 1, math.log, deterministic=True)


def bl(v: int) -> int:
    # SPEC section 3: bit_length(0) == 0.  No clamp -- a single-relation
    # catalog would legitimately cost zero bits per relation code.
    return int(v).bit_length()


def load(data: Path):
    params = json.loads((data / "params.json").read_text())
    con = sqlite3.connect(":memory:")
    register_math(con)
    for name in ("oplog", "txn", "rel_catalog", "truth"):
        pd.read_csv(data / f"{name}.csv").to_sql(name, con, index=False)
    con.executescript((SQL / "10_setup.sql").read_text())

    rels = params["relations"]
    con.executemany("INSERT INTO piles VALUES (?,?)",
                    sorted(params["control_piles"].items()))
    con.executemany("INSERT INTO itembits VALUES (?,?)",
                    [(r, bl(params["n_items"][r] - 1)) for r in rels])
    con.executemany("INSERT INTO relidx VALUES (?,?)",
                    [(r, i) for i, r in enumerate(rels)])

    # ------------------------------------------------------- map catalogue
    buds = params["group_budgets"]
    maps, mapdef, mapcb = [], [], []
    nops_blk = con.execute(
        "SELECT COUNT(*) FROM oplog WHERE block=0").fetchone()[0]
    cb = bl(nops_blk * params["window_blocks"])
    ob = bl(nops_blk)
    maps.append((0, "t", "exact", 0, "exact"))
    mapcb.append((0, 0))
    for ai, arm in enumerate(("t", "c")):
        for fi, fam in enumerate(FAMILIES):
            for bi, bud in enumerate(buds):
                mid = ai * 6 + fi * 3 + bi + 1
                maps.append((mid, arm, fam, bud // 4, f"{arm}_{fam}_{bud}"))
                mapdef.append((mid, arm, fam, bud // 4))
                mapcb.append((mid, cb))
    base = 3                                    # t / group / widest
    maps += [(13, "t", "blind", 0, "blind"), (14, "t", "sampled", 0,
                                              "sampled"),
             (15, "t", "group", max(buds) // 4, "oracle"),
             (16, "t", "group", max(buds) // 4, "cascade")]
    mapdef += [(15, "o", "group", max(buds) // 4),
               (16, "t", "group", max(buds) // 4)]
    mapcb += [(13, 0), (14, 0), (15, ob), (16, cb)]
    con.execute("CREATE TABLE mapdef(mapid INTEGER, srcid TEXT, fam TEXT,"
                " bw INTEGER)")
    con.execute("CREATE TABLE mapcb(mapid INTEGER PRIMARY KEY, cb INTEGER)")
    con.executemany("INSERT INTO maps VALUES (?,?,?,?,?)", maps)
    con.executemany("INSERT INTO mapdef VALUES (?,?,?,?)", mapdef)
    con.executemany("INSERT INTO mapcb VALUES (?,?)", mapcb)

    # ------------------------------------------------------------ streams
    streams, sid = [], 0
    by_name = {m[4]: m[0] for m in maps}
    for vis in VIS:
        for arm in ("t", "c"):
            for fam in FAMILIES:
                for bud in buds:
                    mid = by_name[f"{arm}_{fam}_{bud}"]
                    for sch in SCHEMES:
                        sid += 1
                        streams.append((sid, mid, vis, arm,
                                        f"{fam}_{sch}_{bud}", sch,
                                        int(sch == "sgt")))
        for st in STRUCTURES:
            sid += 1
            sch = STRUCT_SCHEME[st]
            streams.append((sid, by_name[st], vis, "t", st, sch,
                            int(sch == "sgt")))
    con.executemany("INSERT INTO stream(sid, mapid, vis, arm, cfg, scheme,"
                    " needs_reach) VALUES (?,?,?,?,?,?,?)", streams)
    con.executemany("INSERT INTO activemap VALUES (?)",
                    [(m[0],) for m in maps])
    con.commit()
    return con, params, dict(cb=cb, ob=ob, base=base, nops_blk=nops_blk)


def bind(text: str, subs: dict) -> str:
    for k in sorted(subs, key=len, reverse=True):
        text = text.replace(k, str(subs[k]))
    return text


# ----------------------------------------------------------- walk-forward
def walk(con, params, subs, blocks, nq, target, gate) -> pd.DataFrame:
    map_sql = (SQL / "20_map.sql").read_text()
    edge_sql = (SQL / "30_edges.sql").read_text()
    step_sql = (SQL / "40_step.sql").read_text()
    nec = dict(con.execute(
        "SELECT block, SUM(true_abort) FROM truth GROUP BY block").fetchall())
    out = []
    for blk in blocks:
        s = dict(subs, **{":blk": blk})
        con.executescript(bind(map_sql, s))
        con.executescript(bind(edge_sql, s))
        con.execute("DELETE FROM comm")
        con.execute("DELETE FROM reach")
        con.execute("DELETE FROM dec")
        order = con.execute(
            "SELECT txn_id, begin_seq FROM tb"
            " ORDER BY commit_seq, txn_id").fetchall()
        for t, tbeg in order:
            con.executescript(bind(step_sql, dict(s, **{":tbeg": tbeg,
                                                        ":t": t})))
        rows = con.execute(f"""
            SELECT s.arm, s.cfg, s.vis, COUNT(*), SUM(d.abort),
                   SUM(bl.b), SUM(CASE WHEN
                     (CASE WHEN d.ww >= d.wr AND d.ww >= d.rw THEN 'WW'
                           WHEN d.wr >= d.rw THEN 'WR' ELSE 'RW' END) =
                     (CASE WHEN t.true_ww >= t.true_wr
                            AND t.true_ww >= t.true_rw THEN 'WW'
                           WHEN t.true_wr >= t.true_rw THEN 'WR'
                           ELSE 'RW' END) THEN 1 ELSE 0 END),
                   mb.bits, mb.used,
                   SUM(CASE WHEN d.abort NOT IN (0,1) THEN 1 ELSE 0 END)
            FROM   dec d
            JOIN   stream s ON s.sid = d.sid
            JOIN   bitlen bl ON bl.v = d.nex
            JOIN   mapbits mb ON mb.mapid = s.mapid
            JOIN   truth t ON t.block = {blk} AND t.txn_id = d.txn
            GROUP BY s.arm, s.cfg, s.vis
        """).fetchall()
        n = max(1, int(nec.get(blk, 0)))
        for r in rows:
            out.append((blk,) + tuple(r))
        # the trigger for the next block, read off the si stream only
        con.execute("DELETE FROM trig")
        fired = []
        for arm, cfg, vis, cnt, ab, nex, agr, bits, used, inval in rows:
            if vis != "si":
                continue
            a = max(max(ab, 1), n) / min(max(ab, 1), n)
            fired.append((arm, cfg, int(a > gate)))
        con.executemany("INSERT INTO trig VALUES (?,?,?)", fired)
        con.commit()
    df = pd.DataFrame(out, columns=["blk", "arm", "cfg", "vis", "n",
                                    "aborts", "nex", "agree", "bits", "used",
                                    "invalid"])
    df["nec"] = df.blk.map(lambda b: max(1, int(nec.get(b, 0))))
    act = np.maximum(df.aborts.to_numpy(), 1)
    df["ae"] = np.maximum(act, df.nec) / np.minimum(act, df.nec)
    df["bpt"] = (df.bits + df.nex) / nq
    df["agp"] = df.agree / nq * 100.0
    return df


# --------------------------------------------------------------- metrics
def metrics(g: pd.DataFrame, target: float) -> dict:
    a = g["ae"].to_numpy()
    d = g["bpt"].to_numpy()
    c = g["agp"].to_numpy()
    return {
        "mean_a_error": float(a.mean()),
        "p95_a_error": float(np.percentile(a, 95)),
        "max_a_error": float(a.max()),
        "pct_within_target": float((a <= target).mean()),
        "excess_ratio": float(np.maximum(0.0, a - target).mean()
                              / target),
        "bits_per_txn": float(d.mean()),
        "class_agreement_pct": float(c.mean()),
    }


def significance(strat: dict, ctrl: dict) -> dict:
    out = {}
    for fam in FAMILIES:
        names = sorted(n for n in ctrl if n.startswith(fam + "_"))
        panel = {}
        for metric, sign in SIG_METRICS:
            t = np.array([strat[n][metric] for n in names]) * sign
            c = np.array([ctrl[n][metric] for n in names]) * sign
            # rank 1 is the better arm, in the metric's own direction
            tr = np.where(t > c, 1.0, np.where(t < c, 2.0, 1.5))
            cr = 3.0 - tr
            q = abs(tr.mean() - cr.mean()) * np.sqrt(len(names))
            panel[metric] = {
                "control_rank": float(cr.mean()),
                "treatment_rank": float(tr.mean()),
                "t_test_p": float(st.ttest_rel(t, c,
                                               alternative="greater").pvalue),
                "nemenyi_p": float(min(2.0 * st.norm.sf(q), 1.0)),
            }
        out[fam] = panel
    return out


# ------------------------------------------------------------ the reports
def schedule_report(con, params, subs, meta, n_eval) -> dict:
    ref = reference_eras(con, params, subs, meta)
    rels = params["relations"]
    ib = dict(con.execute("SELECT rel, ibits FROM itembits").fetchall())
    cb, ob = meta["cb"], meta["ob"]
    nrel = len(rels)
    budget_bits = {
        str(b): int((b // 4) * sum(2 * ib[r] + 2 * cb for r in rels)
                    + nrel * cb)
        for b in params["group_budgets"]}
    q = con.execute
    return {
        "block_bits": int(ob),
        "budget_bits": budget_bits,
        "budgets": list(params["group_budgets"]),
        "count_bits": int(cb),
        "item_bits": {r: int(ib[r]) for r in rels},
        "mean_true_edges": float(q(
            "SELECT AVG(true_ww + true_wr + true_rw) FROM truth"
        ).fetchone()[0]),
        "n_blocks": subs[":n_blocks"],
        "n_eval_blocks": n_eval,
        "n_ops": int(q("SELECT COUNT(*) FROM oplog").fetchone()[0]),
        "n_relations": nrel,
        "n_transactions": int(q("SELECT COUNT(*) FROM txn").fetchone()[0]),
        "n_txn_per_block": subs[":nq"],
        "n_window_blocks": params["window_blocks"],
        "ops_per_txn": int(q("SELECT n_ops FROM txn LIMIT 1").fetchone()[0]),
        "required_aborts": int(q(
            "SELECT SUM(true_abort) FROM truth").fetchone()[0]),
        "schema_stats": ref,
    }


def reference_eras(con, params, subs, meta) -> dict:
    """The reference map: group family, sgt scheme, si convention, built on
    the train era and applied to the train era and to the final era."""
    ref_sql = (SQL / "50_reference.sql").read_text()
    step_sql = (SQL / "40_step.sql").read_text()
    ep = subs[":ep_len"]
    n_blocks = subs[":n_blocks"]
    nec = dict(con.execute(
        "SELECT block, SUM(true_abort) FROM truth GROUP BY block").fetchall())
    eras = {"train": list(range(ep)),
            "final": list(range(n_blocks - ep, n_blocks))}
    con.executescript(bind(ref_sql, subs))
    edge_sql = (SQL / "30_edges.sql").read_text()
    blk_sql = (SQL / "51_refblock.sql").read_text()
    fc_sql = (SQL / "52_fcshare.sql").read_text()
    acc = {}
    for era, blocks in eras.items():
        for blk in blocks:
            s = dict(subs, **{":blk": blk})
            con.executescript(bind(blk_sql, s))
            con.executescript(bind(edge_sql, s))
            con.execute("DELETE FROM comm")
            con.execute("DELETE FROM reach")
            con.execute("DELETE FROM dec")
            order = con.execute("SELECT txn_id, begin_seq FROM tb"
                                " ORDER BY commit_seq, txn_id").fetchall()
            for t, tbeg in order:
                con.executescript(bind(step_sql,
                                       dict(s, **{":tbeg": tbeg, ":t": t})))
            for row in con.execute(f"""
                SELECT s.cfg, SUM(d.abort), COUNT(*),
                       SUM(CASE WHEN
                         (CASE WHEN d.ww >= d.wr AND d.ww >= d.rw THEN 'WW'
                               WHEN d.wr >= d.rw THEN 'WR' ELSE 'RW' END) =
                         (CASE WHEN t.true_ww >= t.true_wr
                                AND t.true_ww >= t.true_rw THEN 'WW'
                               WHEN t.true_wr >= t.true_rw THEN 'WR'
                               ELSE 'RW' END) THEN 1 ELSE 0 END)
                FROM dec d JOIN stream s ON s.sid = d.sid
                JOIN truth t ON t.block = {blk} AND t.txn_id = d.txn
                GROUP BY s.cfg""").fetchall():
                acc.setdefault((row[0], era), []).append(
                    (blk, row[1], row[2], row[3]))
            con.executescript(bind(fc_sql, s))
            for row in con.execute("SELECT cfg, formed, wrong FROM fcshare"
                                   ).fetchall():
                acc.setdefault((row[0], era, "fc"), []).append(
                    (row[1], row[2]))
    bits = dict(con.execute("SELECT cfg, bits FROM refbits").fetchall())
    used = dict(con.execute("SELECT cfg, used FROM refbits").fetchall())
    out = {}
    for bud in params["group_budgets"]:
        cfg = f"ref_{bud}"
        row = {"map_bits_per_txn": float(bits[cfg]) / subs[":nq"],
               "groups_used": float(used[cfg])}
        for era in ("train", "final"):
            recs = acc[(cfg, era)]
            aes, abr, agr = [], [], []
            for blk, ab, cnt, agree in recs:
                n = max(1, int(nec.get(blk, 0)))
                a = max(max(ab, 1), n) / min(max(ab, 1), n)
                aes.append(a)
                abr.append(ab / cnt)
                agr.append(agree / cnt * 100.0)
            fc = acc[(cfg, era, "fc")]
            row[f"a_error_{era}_era"] = float(np.mean(aes))
            row[f"abort_rate_{era}_era"] = float(np.mean(abr))
            row[f"class_agreement_{era}_era"] = float(np.mean(agr))
            row[f"false_conflict_share_{era}_era"] = float(
                np.mean([w / max(1, f) for f, w in fc]))
        for era, lo, hi in (("train", 0, subs[":ep_len"] - 1),
                            ("final", subs[":n_blocks"] - subs[":ep_len"],
                             subs[":n_blocks"] - 1)):
            row[f"renyi_{era}_era"] = float(con.execute(f"""
                WITH p AS (SELECT COUNT(*)*1.0 /
                     (SELECT COUNT(*) FROM oplog
                      WHERE block BETWEEN {lo} AND {hi}) AS pp
                   FROM oplog WHERE block BETWEEN {lo} AND {hi}
                   GROUP BY rel, item_id)
                SELECT CASE WHEN COUNT(*) < 2 THEN 0.0 ELSE
                       LN(SUM(POW(pp, {params['renyi_alpha']})))
                       / (1 - {params['renyi_alpha']}) / LN(COUNT(*)) END
                FROM p""").fetchone()[0])
        out[str(bud)] = {k: row[k] for k in sorted(row)}
    return out


def drift_report(con, subs) -> dict:
    con.executescript(bind((SQL / "60_drift.sql").read_text(), subs))
    n_ep = subs[":n_ep"]
    sh = pd.read_sql("SELECT * FROM shares", con)
    six = sh[sh["nbins"] == 6].pivot(index="epoch", columns="bin",
                                     values="share").to_numpy()
    ten = sh[sh["nbins"] == 10].pivot(index="epoch", columns="bin",
                                      values="share").to_numpy()
    cond = six.copy()
    np.fill_diagonal(cond, 0.0)
    rs = cond.sum(axis=1, keepdims=True)
    cond = np.where(rs > 0, cond / np.where(rs == 0, 1.0, rs),
                    1.0 / (n_ep - 1))
    stat = pd.read_sql("SELECT epoch, stat FROM opstat", con)
    ks = np.zeros((n_ep, n_ep))
    byep = {e: g["stat"].to_numpy() for e, g in stat.groupby("epoch")}
    for i in range(n_ep):
        for j in range(n_ep):
            if i != j:
                ks[i, j] = st.ks_2samp(byep[i], byep[j]).statistic
    return {
        "conditional_epoch_share_matrix": [[float(x) for x in r]
                                           for r in cond],
        "decile_share_pct": {
            f"D{b}": {f"E{e}": float(ten[e][b] * 100.0) for e in range(n_ep)}
            for b in range(10)},
        "epoch_ks_matrix": [[float(x) for x in r] for r in ks],
        "epoch_share_matrix": [[float(x) for x in r] for r in six],
    }


# ------------------------------------------------------------------ main
def main(argv: list[str]) -> int:
    if len(argv) != 3:
        print("usage: python solve_full.py <data_dir> <out_path>",
              file=sys.stderr)
        return 2
    data, out_path = Path(argv[1]), Path(argv[2])
    con, params, meta = load(data)

    n_blocks = int(con.execute(
        "SELECT COUNT(DISTINCT block) FROM oplog").fetchone()[0])
    nq = int(con.execute(
        "SELECT COUNT(*) FROM txn WHERE block=0").fetchone()[0])
    w = params["window_blocks"]
    nw = meta["nops_blk"] * w
    blocks = list(range(w, n_blocks))
    subs = {":w": w, ":nw": nw, ":ns": params["sample_ops"],
            ":stride": nw // params["sample_ops"], ":nq": nq,
            ":n_blocks": n_blocks, ":n_ep": params["n_epochs"],
            ":ep_len": n_blocks // params["n_epochs"],
            ":lag": params["stale_lag"], ":cb": meta["cb"],
            ":obits": meta["ob"], ":basemap": meta["base"],
            ":bigbw": max(params["group_budgets"]) // 4,
            ":nrel": len(params["relations"]),
            ":relbits": bl(len(params["relations"]) - 1),
            ":ntxnw": nq * w}

    target = params["target_a_error"]
    gate = target * params["gate_multiple"]
    df = walk(con, params, subs, blocks, nq, target, gate)

    sweep = sorted(f"{f}_{s}_{b}" for f in FAMILIES for s in SCHEMES
                   for b in params["group_budgets"])
    audit = {blocks[s] for s in params["audit_steps"] if s < len(blocks)}
    invalid = int(df[df["blk"].isin(audit)]["invalid"].sum())

    variants = {}
    for vis in VIS:
        v = df[df["vis"] == vis]
        strat = {c: metrics(v[(v["arm"] == "t") & (v["cfg"] == c)], target)
                 for c in sweep + list(STRUCTURES)}
        ctrl = {c: metrics(v[(v["arm"] == "c") & (v["cfg"] == c)], target)
                for c in sweep}
        vs = v[(v["arm"] == "t") & (v["cfg"].isin(sweep))]
        best = min(sweep, key=lambda c: (strat[c]["mean_a_error"], c))
        blind = strat["blind"]["bits_per_txn"]
        variants[vis] = {
            "control_metrics": {k: ctrl[k] for k in sorted(ctrl)},
            "diagnostics": {
                "best_bits_per_txn": strat[best]["bits_per_txn"],
                "best_config": best,
                "best_mean_a_error": strat[best]["mean_a_error"],
                "cost_vs_blind_pct": float(
                    (strat[best]["bits_per_txn"] - blind) / blind * 100.0),
                "invalid_decisions_audited": invalid,
                "mean_class_agreement_pct": float(np.mean(
                    [strat[c]["class_agreement_pct"] for c in sweep])),
                "mean_groups_used": float(vs["used"].mean()),
                "n_eval_blocks": len(blocks),
                "trigger_rate": trigger_rate(df, gate),
            },
            "significance": significance(strat, ctrl),
            "strategy_metrics": {k: strat[k] for k in sorted(strat)},
        }

    results = {
        "drift_report": drift_report(con, subs),
        "schedule_report": schedule_report(con, params, subs, meta,
                                           len(blocks)),
        "variants": variants,
    }
    text = json.dumps(results, indent=1, sort_keys=True, allow_nan=False)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(text)
    print(f"wrote {out_path} ({len(text)} bytes)")
    return 0


def trigger_rate(df, gate) -> float:
    """Share of (configuration, block) pairs at which the trigger was armed,
    over the treatment sweep.  The trigger reads the si stream of the block
    before, so block 0 of the evaluation is never armed."""
    v = df[(df["vis"] == "si") & (df["arm"] == "t")
           & (~df["cfg"].isin(STRUCTURES))]
    p = v.pivot(index="blk", columns="cfg", values="ae")
    armed = (p > gate).shift(1).fillna(False)
    return float(armed.to_numpy().mean())


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
