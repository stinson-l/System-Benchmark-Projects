"""
Deterministic verifier suite for /app/results.json.

    pytest -q task/tests/test_outputs.py

Every check is programmatic and returns pass/fail with no human judgment. The
suite passes only if every check passes. Checks are ordered cheap-to-expensive
so a structurally broken submission fails in milliseconds.

Layers:
  V1-V3    the file and its shape
  V4-V5    comparison against the reference values
  V6-V9    internal consistency, needing no reference
  V10-V11  closed-form recomputation from the inputs alone
  V12-V15  independent recomputation of individual pipeline components
  V16-V18  the guarantee, stability and anti-hardcoding
  V19-V20  re-derivation in SQL, and freedom from the SQLite build
"""

from __future__ import annotations

import json
import math
import os
import sqlite3
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
SUBMISSION = Path(os.environ.get("SUBMISSION", "/app/results.json"))
if not SUBMISSION.exists():                      # local runs
    SUBMISSION = ROOT / "expected_results.json"
REFERENCE = ROOT / "expected_results.json"
# In the deployed harness data/ sits beside tests/; in this package tests/
# live under Sol/ and data/ is one level up. Accept either.
DATA = ROOT / "data" if (ROOT / "data").is_dir() else ROOT.parent / "data"
CROSSCHECK = ROOT / "crosscheck" / "solve_narrow_crosscheck.py"

TARGET = 2.0
N_EVAL = 30
N_TXN = 50
OPS_PER_TXN = 12
VARIANTS = ("si", "rc", "stale")
SCHEMES = ("fcw", "danger", "sgt", "mix")
FAMILIES = ("group", "hot")
STRUCTURES = ("blind", "sampled", "oracle", "cascade")
METRICS = ("mean_a_error", "p95_a_error", "max_a_error",
           "pct_within_target", "excess_ratio", "bits_per_txn",
           "class_agreement_pct")
EXACT_FIELDS = {"n_blocks", "n_ops", "n_transactions", "n_eval_blocks",
                "n_window_blocks", "n_relations", "n_txn_per_block",
                "ops_per_txn", "count_bits", "block_bits", "budgets",
                "budget_bits", "item_bits", "best_config",
                "invalid_decisions_audited", "required_aborts"}
RTOL = 1e-3


def _reject(x):
    raise AssertionError(f"non-finite token in JSON: {x}")


@pytest.fixture(scope="session")
def raw() -> str:
    assert SUBMISSION.exists(), f"missing {SUBMISSION}"
    return SUBMISSION.read_text(encoding="utf-8")


@pytest.fixture(scope="session")
def sub(raw) -> dict:
    return json.loads(raw, parse_constant=_reject)


@pytest.fixture(scope="session")
def ref() -> dict:
    return json.loads(REFERENCE.read_text(encoding="utf-8"))


@pytest.fixture(scope="session")
def inputs():
    import pandas as pd
    oplog = pd.read_csv(DATA / "oplog.csv")
    txn = pd.read_csv(DATA / "txn.csv")
    truth = pd.read_csv(DATA / "truth.csv")
    cat = pd.read_csv(DATA / "rel_catalog.csv")
    params = json.loads((DATA / "params.json").read_text())
    return oplog, txn, truth, cat, params


@pytest.fixture(scope="session")
def narrow(tmp_path_factory) -> dict:
    """Independent implementation, run fresh against the frozen inputs."""
    out = tmp_path_factory.mktemp("cc") / "narrow.json"
    subprocess.run([sys.executable, str(CROSSCHECK), str(DATA), str(out)],
                   check=True, capture_output=True)
    return json.loads(out.read_text())


def leaves(o, p=""):
    d = {}
    if isinstance(o, dict):
        for k, v in o.items():
            d.update(leaves(v, f"{p}/{k}"))
    elif isinstance(o, list):
        for i, v in enumerate(o):
            d.update(leaves(v, f"{p}[{i}]"))
    else:
        d[p] = o
    return d


def shape(o):
    if isinstance(o, dict):
        return {k: shape(v) for k, v in sorted(o.items())}
    if isinstance(o, list):
        return ["list", len(o)] + [shape(v) for v in o[:1]]
    if isinstance(o, bool):
        return "bool"
    if isinstance(o, str):
        return "str"
    if isinstance(o, (int, float)):
        return "num"
    return type(o).__name__


def close(got, exp) -> bool:
    if exp == 0:
        return abs(got) <= RTOL
    return abs(got - exp) <= RTOL * abs(exp)


def blen(v: int) -> int:
    """Bit length of a non-negative integer, as the pipeline defines it."""
    return int(v).bit_length()


def all_configs():
    return [f"{f}_{s}_{b}" for f in FAMILIES for s in SCHEMES
            for b in (80, 160, 320)]


# ------------------------------------------------------------------ V1-V3
def test_v1_file_is_strict_json(raw, sub):
    """V1: exists, decodes as UTF-8, parses as strict JSON, no NaN/Infinity."""
    assert raw.strip(), "submission is empty"
    assert isinstance(sub, dict), "top level must be an object"


def test_v2_top_level_keys(sub):
    """V2: exactly three top-level keys, no more, no fewer."""
    assert set(sub) == {"schedule_report", "drift_report", "variants"}, \
        f"top-level keys are {sorted(sub)}"


def test_v3_schema_matches_reference(sub, ref):
    """V3: identical nesting, container types, list lengths and leaf types.

    Compared as a structure rather than key by key, so a renamed branch or a
    truncated matrix fails here rather than surfacing as a value mismatch.
    """
    assert shape(sub) == shape(ref), "structure differs from the reference"
    assert len(leaves(sub)) == len(leaves(ref))


# ------------------------------------------------------------------ V4-V5
def test_v4_exact_fields(sub, ref):
    """V4: counts, sizes, names and the audit field compare for equality.

    These are integers, strings or lists of integers. A tolerance would be
    meaningless: the number of relations is four or the submission is wrong.
    """
    g, e = leaves(sub), leaves(ref)
    for path, want in e.items():
        field = path.rsplit("/", 1)[-1].split("[")[0]
        if field in EXACT_FIELDS or isinstance(want, str):
            assert g[path] == want, f"{path}: {g[path]!r} != {want!r}"


def test_v5_all_floats_within_tolerance(sub, ref):
    """V5: every remaining numeric leaf within 1e-3 relative (1e-3 abs at 0)."""
    g, e = leaves(sub), leaves(ref)
    bad = []
    for path, want in e.items():
        if isinstance(want, str):
            continue
        if not close(g[path], want):
            bad.append(f"{path}: {g[path]} != {want}")
    assert not bad, "values outside tolerance:\n  " + "\n  ".join(bad[:20])


# ------------------------------------------------------------------ V6-V9
def test_v6_metric_algebra(sub):
    """V6: relations among the seven metrics that hold by definition.

    The a-error is a ratio of the larger to the smaller of two positive
    integers, so it is at least one. Its mean cannot exceed its 95th
    percentile, which cannot exceed its maximum. A share lies in [0, 1] and a
    percentage in [0, 100]. Bits are non-negative. None of this depends on the
    data, so a submission failing here is internally incoherent whatever the
    inputs were.
    """
    for v in VARIANTS:
        panel = sub["variants"][v]
        for arm in ("strategy_metrics", "control_metrics"):
            for cfg, m in panel[arm].items():
                tag = f"{v}/{arm}/{cfg}"
                assert m["mean_a_error"] >= 1.0 - 1e-9, tag
                assert m["mean_a_error"] <= m["p95_a_error"] + 1e-9, tag
                assert m["p95_a_error"] <= m["max_a_error"] + 1e-9, tag
                assert 0.0 <= m["pct_within_target"] <= 1.0, tag
                assert m["excess_ratio"] >= 0.0, tag
                assert m["bits_per_txn"] >= 0.0, tag
                assert 0.0 <= m["class_agreement_pct"] <= 100.0, tag


def test_v7_quantization_of_observables(sub):
    """V7: rates are counts over fixed denominators and cannot be arbitrary.

    pct_within_target counts evaluation blocks, so it is a multiple of 1/30.
    class_agreement_pct counts transactions over 30 blocks of 50, so it is a
    multiple of 100/1500. A fabricated or smoothed number lands between the
    lattice points and fails.
    """
    for v in VARIANTS:
        panel = sub["variants"][v]
        for arm in ("strategy_metrics", "control_metrics"):
            for cfg, m in panel[arm].items():
                x = m["pct_within_target"] * N_EVAL
                assert abs(x - round(x)) < 1e-6, f"{v}/{arm}/{cfg} pct"
                y = m["class_agreement_pct"] * N_EVAL * N_TXN / 100.0
                assert abs(y - round(y)) < 1e-6, f"{v}/{arm}/{cfg} agreement"


def test_v8_significance_internal_consistency(sub):
    """V8: ranks sum to 3.0, p-values are probabilities, Nemenyi follows ranks.

    Two methods are ranked per metric, so the ranks are 1 and 2 and sum to 3
    whether or not they tie at 1.5. The Nemenyi p-value is a function of the
    rank gap and the number of blocks only, so it must be identical across
    metrics within a family whenever the gap is.
    """
    for v in VARIANTS:
        for fam, panel in sub["variants"][v]["significance"].items():
            for metric, s in panel.items():
                tag = f"{v}/{fam}/{metric}"
                assert abs(s["treatment_rank"] + s["control_rank"] - 3.0) \
                    < 1e-9, tag
                assert 0.0 <= s["t_test_p"] <= 1.0, tag
                assert 0.0 <= s["nemenyi_p"] <= 1.0, tag
            gaps = {round(abs(s["treatment_rank"] - s["control_rank"]), 9)
                    for s in panel.values()}
            if len(gaps) == 1:
                ps = {round(s["nemenyi_p"], 12) for s in panel.values()}
                assert len(ps) == 1, f"{v}/{fam}: equal gaps, unequal Nemenyi"


def test_v9_cross_variant_invariants(sub):
    """V9: what a visibility convention cannot change must not have changed.

    The convention decides which committed writer a read saw. It therefore
    moves the wr and rw edges, and it moves them only. Write-write conflicts
    are a property of the commit order alone.

    So first-committer-wins, which consults nothing but ww edges among
    concurrent committed predecessors, must reach the identical abort decision
    for every transaction under all three conventions; and since the required
    abort count comes from the frozen truth table rather than from the
    certifier, every a-error metric of every fcw configuration -- and of blind,
    which is fcw at relation granularity -- must be bit-identical across si, rc
    and stale.

    bits_per_txn and class_agreement_pct are deliberately excluded: the first
    charges for edges examined and the second reads the edge mix, both of which
    the convention does move. A submission that makes those invariant too has
    collapsed the conventions somewhere and fails a later layer.
    """
    fixed = ("mean_a_error", "p95_a_error", "max_a_error",
             "pct_within_target", "excess_ratio")
    cfgs = [c for c in all_configs() if "_fcw_" in c] + ["blind"]
    base = sub["variants"]["si"]
    for cfg in cfgs:
        for metric in fixed:
            want = base["strategy_metrics"][cfg][metric]
            for v in ("rc", "stale"):
                got = sub["variants"][v]["strategy_metrics"][cfg][metric]
                assert abs(got - want) < 1e-12, \
                    f"{cfg}/{metric} moved with the visibility convention"
    for key in ("mean_groups_used", "trigger_rate", "n_eval_blocks",
                "invalid_decisions_audited"):
        vals = {sub["variants"][v]["diagnostics"][key] for v in VARIANTS}
        assert len(vals) == 1, f"{key} differs across variants: {vals}"


# ---------------------------------------------------------------- V10-V11
def test_v10_cost_accounting_closed_form(sub, inputs):
    """V10: the bit accounting is recomputed from params.json alone.

    Widths follow from the shapes of the inputs and nothing else. An item
    identifier of a relation with n items costs bit_length(n - 1); a count
    within a six-block window over 600 operations per block costs
    bit_length(3600); a count within one served block costs bit_length(600).
    A group entry stores two item identifiers and two counts, so the budget
    ceiling for B groups per relation is B times the per-relation entry cost
    summed over relations, plus one count per relation for the catalogue
    header.
    """
    oplog, txn, truth, cat, params = inputs
    dr = sub["schedule_report"]
    n_blocks = int(oplog["block"].max()) + 1
    ops_per_block = len(oplog) // n_blocks
    nrel = len(params["relations"])

    cb = blen(ops_per_block * params["window_blocks"])
    ob = blen(ops_per_block)
    assert dr["count_bits"] == cb
    assert dr["block_bits"] == ob
    assert dr["n_relations"] == nrel
    assert dr["n_window_blocks"] == params["window_blocks"]
    assert dr["n_eval_blocks"] == n_blocks - params["window_blocks"]

    nitems = dict(zip(cat["rel"], cat["n_items"]))
    for rel, want in dr["item_bits"].items():
        assert want == blen(nitems[rel] - 1), rel

    per_rel = sum(2 * blen(nitems[r] - 1) + 2 * cb for r in params["relations"])
    for b in params["group_budgets"]:
        want = (b // 4) * per_rel + nrel * cb
        assert dr["budget_bits"][str(b)] == want, b

    # every map that is charged against a budget must respect its ceiling
    for b in params["group_budgets"]:
        ss = dr["schema_stats"][str(b)]
        total = ss["map_bits_per_txn"] * dr["n_txn_per_block"]
        assert total <= dr["budget_bits"][str(b)] + 1e-6, b
        assert ss["groups_used"] <= (b // 4) * nrel


def test_v11_structure_cost_floors(sub, inputs):
    """V11: the reference structures have costs fixed by construction.

    blind stores no map at all, so its whole charge is the per-transaction
    bit-length of the neighbour counts it examined; with fifty transactions in
    a block that can never exceed bit_length(49) = 6 bits each, and it must be
    strictly positive because every certifier examines something.

    sampled stores one relation identifier, one item identifier and one
    presence bit per retained operation, whatever the operation turns out to
    be, so its map cost is bracketed by the narrowest and widest item
    identifier in the catalogue. These bounds need no reference values.
    """
    oplog, txn, truth, cat, params = inputs
    nitems = dict(zip(cat["rel"], cat["n_items"]))
    ibits = {r: blen(nitems[r] - 1) for r in params["relations"]}
    rel_bits = blen(len(params["relations"]) - 1)
    nq = sub["schedule_report"]["n_txn_per_block"]

    for v in VARIANTS:
        sm = sub["variants"][v]["strategy_metrics"]
        b = sm["blind"]["bits_per_txn"]
        assert 0.0 < b <= blen(nq - 1), f"{v}: blind costs {b} bits/txn"

        lo = params["sample_ops"] * (rel_bits + min(ibits.values()) + 1) / nq
        hi = params["sample_ops"] * (rel_bits + max(ibits.values()) + 1) / nq
        s = sm["sampled"]["bits_per_txn"]
        assert lo <= s, f"{v}: sampled below its floor"
        assert s <= hi + blen(nq - 1), f"{v}: sampled above its ceiling"


# ---------------------------------------------------------------- V12-V15
def test_v12_schedule_and_drift(sub, narrow):
    """V12: schedule counts, the reference map and the drift binning."""
    dr = sub["schedule_report"]
    assert dr["n_ops"] == narrow["n_ops"]
    assert dr["n_transactions"] == narrow["n_transactions"]
    assert dr["n_blocks"] == narrow["n_blocks"]
    assert dr["n_txn_per_block"] == narrow["n_txn_per_block"]
    assert dr["count_bits"] == narrow["count_bits"]
    assert dr["block_bits"] == narrow["block_bits"]
    assert dr["item_bits"]["r1"] == narrow["item_bits_r1"]
    assert dr["item_bits"]["r3"] == narrow["item_bits_r3"]
    assert dr["required_aborts"] == narrow["required_aborts"]
    assert close(dr["mean_true_edges"], narrow["mean_true_edges"])
    assert dr["budget_bits"]["320"] == narrow["budget_bits_320"]

    ss = dr["schema_stats"]["320"]
    for k, n in (("groups_used", "ref320_groups_used"),
                 ("map_bits_per_txn", "ref320_map_bits_per_txn"),
                 ("a_error_train_era", "ref320_a_error_train_era"),
                 ("a_error_final_era", "ref320_a_error_final_era"),
                 ("false_conflict_share_train_era",
                  "ref320_false_conflict_share_train_era"),
                 ("false_conflict_share_final_era",
                  "ref320_false_conflict_share_final_era"),
                 ("renyi_train_era", "renyi_train_era")):
        assert close(ss[k], narrow[n]), k

    six = sub["drift_report"]["epoch_share_matrix"]
    assert close(six[0][0], narrow["epoch_share_0_0"])
    assert close(six[5][5], narrow["epoch_share_5_5"])
    for row in six:
        assert close(sum(row), 1.0)
    for row in sub["drift_report"]["conditional_epoch_share_matrix"]:
        assert close(sum(row), 1.0)


def test_v13_map_families_and_budgets(sub, narrow):
    """V13: the two map families and the budget ladder, recomputed.

    group at the smallest budget, group at the largest and hot at the largest
    are re-derived independently, which exercises equi-depth assignment, the
    hot/residue split and the budget scaling in turn. mean_groups_used is
    averaged over the whole sweep and so depends on every map built.
    """
    sm = sub["variants"]["si"]["strategy_metrics"]
    assert close(sm["group_fcw_80"]["mean_a_error"],
                 narrow["si_group_fcw_80_a_error"])
    assert close(sm["group_sgt_320"]["mean_a_error"],
                 narrow["si_group_sgt_320_a_error"])
    assert close(sm["hot_fcw_320"]["mean_a_error"],
                 narrow["si_hot_fcw_320_a_error"])
    assert close(sm["group_sgt_320"]["class_agreement_pct"],
                 narrow["si_group_sgt_320_class_agreement"])
    assert close(sub["variants"]["si"]["diagnostics"]["mean_groups_used"],
                 narrow["mean_groups_used"])


def test_v14_conventions_schemes_and_structures(sub, narrow):
    """V14: the three conventions, the four schemes and the four structures.

    group_sgt_320 is re-derived under each convention, isolating visibility
    with everything else held fixed; hot_danger_320 exercises the pivot test
    and group_mix_160 the trigger recursion, which is the one place where a
    block's result depends on the block before it.
    """
    assert close(sub["variants"]["si"]["strategy_metrics"]["group_sgt_320"]
                 ["mean_a_error"], narrow["si_group_sgt_320_a_error"])
    assert close(sub["variants"]["rc"]["strategy_metrics"]["group_sgt_320"]
                 ["mean_a_error"], narrow["rc_group_sgt_320_a_error"])
    assert close(sub["variants"]["stale"]["strategy_metrics"]["group_sgt_320"]
                 ["mean_a_error"], narrow["stale_group_sgt_320_a_error"])

    sm = sub["variants"]["si"]["strategy_metrics"]
    assert close(sm["hot_danger_320"]["mean_a_error"],
                 narrow["si_hot_danger_320_a_error"])
    assert close(sm["group_mix_160"]["mean_a_error"],
                 narrow["si_group_mix_160_a_error"])

    assert close(sm["blind"]["mean_a_error"], narrow["si_blind_a_error"])
    assert close(sm["blind"]["bits_per_txn"], narrow["si_blind_bits_per_txn"])
    assert close(sm["blind"]["class_agreement_pct"],
                 narrow["si_blind_class_agreement"])
    assert close(sm["sampled"]["mean_a_error"], narrow["si_sampled_a_error"])
    assert close(sm["sampled"]["bits_per_txn"],
                 narrow["si_sampled_bits_per_txn"])
    assert close(sm["oracle"]["mean_a_error"], narrow["si_oracle_a_error"])
    assert close(sm["cascade"]["mean_a_error"], narrow["si_cascade_a_error"])
    assert close(sm["cascade"]["bits_per_txn"],
                 narrow["si_cascade_bits_per_txn"])


def test_v15_control_arm_permutation(sub, narrow):
    """V15: the control arm, isolating the deal-into-piles permutation.

    The control keeps the multiset of access counts and destroys only which
    item carries which count, so any advantage the treatment shows is
    attributable to knowing where the contention is rather than to spending
    bits. The permutation is a fixed deal into a fixed number of piles and
    involves no random number generator, so it must reproduce exactly.
    """
    assert close(
        sub["variants"]["si"]["control_metrics"]["group_sgt_320"]
        ["mean_a_error"],
        narrow["si_control_group_sgt_320_a_error"])
    cm = sub["variants"]["si"]["control_metrics"]
    sm = sub["variants"]["si"]["strategy_metrics"]
    assert set(cm) == set(all_configs()), "control arm missing configurations"
    for cfg in all_configs():
        assert close(cm[cfg]["bits_per_txn"], cm[cfg]["bits_per_txn"])
        assert cfg in sm


# ---------------------------------------------------------------- V16-V18
def test_v16_decision_guarantee(sub):
    """V16: no certifier may take a decision outside the admissible set.

    A certification decision is to commit or to abort, and it may be taken
    only on evidence already available: committed transactions of the same
    block. The audit re-examines four evaluation steps per stream and counts
    decisions that consulted a transaction not yet committed, or that aborted
    a transaction with no incoming edge at all under a scheme that requires
    one. It must be zero for every convention.
    """
    for v, panel in sub["variants"].items():
        assert panel["diagnostics"]["invalid_decisions_audited"] == 0, v
        assert panel["diagnostics"]["n_eval_blocks"] == N_EVAL, v
        assert 0.0 <= panel["diagnostics"]["trigger_rate"] <= 1.0, v
        assert panel["diagnostics"]["best_config"] in all_configs(), v


@pytest.mark.skipif(not Path("/app/solve.py").exists(),
                    reason="no solver script to re-run")
def test_v17_stability_across_runs(raw):
    """V17: re-running the solver reproduces the submission byte for byte."""
    tmp = Path("/tmp/rerun.json")
    subprocess.run([sys.executable, "/app/solve.py", str(DATA), str(tmp)],
                   check=True, capture_output=True)
    assert tmp.read_text(encoding="utf-8") == raw, "output not reproducible"


@pytest.mark.skipif(not Path("/app/solve.py").exists(),
                    reason="no solver script to re-run")
def test_v18_not_hardcoded(tmp_path):
    """V18: perturbed inputs must change the output.

    Dropping the last block shortens the evaluation; a solver that emits
    stored constants returns n_eval_blocks unchanged and fails.
    """
    import pandas as pd
    d = tmp_path / "data"
    d.mkdir()
    for name in ("params.json", "rel_catalog.csv"):
        (d / name).write_bytes((DATA / name).read_bytes())
    o = pd.read_csv(DATA / "oplog.csv")
    last = o["block"].max()
    o[o["block"] < last].to_csv(d / "oplog.csv", index=False)
    for name in ("txn.csv", "truth.csv"):
        f = pd.read_csv(DATA / name)
        f[f["block"] < last].to_csv(d / name, index=False)
    out = tmp_path / "perturbed.json"
    subprocess.run([sys.executable, "/app/solve.py", str(d), str(out)],
                   check=True, capture_output=True)
    got = json.loads(out.read_text())
    assert got["schedule_report"]["n_eval_blocks"] == N_EVAL - 1
    assert got["schedule_report"]["n_blocks"] == last


# ---------------------------------------------------------------- V19-V20
def test_v19_sql_rederivation(sub, inputs):
    """V19: quantities re-derived in SQL against the shipped schedule.

    The report describes a database, and the claims that are purely relational
    are checked by querying it rather than by trusting any Python. The truth
    table is not taken on faith either: its edge counts are recomputed at item
    granularity from the operation log and the transaction table, using the
    same visibility rule the si convention uses, and must agree row for row.
    """
    oplog, txn, truth, cat, params = inputs
    db = DATA / "sched.db"
    assert db.exists(), "sched.db missing from data/"
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    try:
        dr = sub["schedule_report"]

        n_ops, n_blocks = con.execute(
            "SELECT COUNT(*), COUNT(DISTINCT block) FROM oplog").fetchone()
        assert dr["n_ops"] == n_ops
        assert dr["n_blocks"] == n_blocks

        (n_txn,) = con.execute("SELECT COUNT(*) FROM txn").fetchone()
        assert dr["n_transactions"] == n_txn

        (per_block,) = con.execute(
            "SELECT COUNT(*) FROM txn GROUP BY block LIMIT 1").fetchone()
        assert dr["n_txn_per_block"] == per_block

        (opt,) = con.execute(
            "SELECT COUNT(*) FROM oplog GROUP BY block, txn_id"
            " LIMIT 1").fetchone()
        assert dr["ops_per_txn"] == opt

        (nrel,) = con.execute(
            "SELECT COUNT(*) FROM rel_catalog").fetchone()
        assert dr["n_relations"] == nrel

        (req,) = con.execute("SELECT SUM(true_abort) FROM truth").fetchone()
        assert dr["required_aborts"] == req

        (mte,) = con.execute(
            "SELECT AVG(true_ww + true_wr + true_rw) FROM truth").fetchone()
        assert close(dr["mean_true_edges"], mte)

        # the truth table's edge counts, recomputed at item granularity
        rows = con.execute("""
            WITH w AS (
                SELECT DISTINCT o.block, o.txn_id, o.rel, o.item_id
                FROM oplog o WHERE o.op_kind = 'W'),
            r AS (
                SELECT o.block, o.txn_id, o.rel, o.item_id,
                       MIN(o.op_seq) AS s
                FROM oplog o WHERE o.op_kind = 'R'
                GROUP BY o.block, o.txn_id, o.rel, o.item_id),
            ww AS (
                SELECT a.block, a.txn_id AS u, b.txn_id AS v
                FROM w a JOIN w b
                  ON b.block = a.block AND b.rel = a.rel
                 AND b.item_id = a.item_id AND b.txn_id <> a.txn_id
                JOIN txn ta ON ta.block = a.block AND ta.txn_id = a.txn_id
                JOIN txn tb ON tb.block = b.block AND tb.txn_id = b.txn_id
                WHERE (ta.commit_seq, ta.txn_id) < (tb.commit_seq, tb.txn_id)
                GROUP BY a.block, a.txn_id, b.txn_id),
            wr AS (
                SELECT DISTINCT rd.block, rd.txn_id AS v,
                       (SELECT wa.txn_id FROM w wa
                        JOIN txn tw ON tw.block = wa.block
                                   AND tw.txn_id = wa.txn_id
                        WHERE wa.block = rd.block AND wa.rel = rd.rel
                          AND wa.item_id = rd.item_id
                          AND wa.txn_id <> rd.txn_id
                          AND tw.commit_seq < tr.begin_seq
                        ORDER BY tw.commit_seq DESC, wa.txn_id DESC
                        LIMIT 1) AS u
                FROM r rd JOIN txn tr ON tr.block = rd.block
                                     AND tr.txn_id = rd.txn_id),
            rw AS (
                SELECT rd.block, rd.txn_id AS u, wa.txn_id AS v
                FROM r rd
                JOIN txn tr ON tr.block = rd.block AND tr.txn_id = rd.txn_id
                JOIN w wa ON wa.block = rd.block AND wa.rel = rd.rel
                         AND wa.item_id = rd.item_id
                         AND wa.txn_id <> rd.txn_id
                JOIN txn tw ON tw.block = wa.block AND tw.txn_id = wa.txn_id
                WHERE tw.commit_seq >= tr.begin_seq
                GROUP BY rd.block, rd.txn_id, wa.txn_id),
            agg AS (
                SELECT block, txn_id, SUM(a) AS ww, SUM(b) AS wr,
                       SUM(c) AS rw FROM (
                  SELECT block, u AS txn_id, 1 a, 0 b, 0 c FROM ww
                  UNION ALL SELECT block, v, 1, 0, 0 FROM ww
                  UNION ALL SELECT block, u, 0, 1, 0 FROM wr WHERE u NOT NULL
                  UNION ALL SELECT block, v, 0, 1, 0 FROM wr WHERE u NOT NULL
                  UNION ALL SELECT block, u, 0, 0, 1 FROM rw
                  UNION ALL SELECT block, v, 0, 0, 1 FROM rw)
                GROUP BY block, txn_id)
            SELECT COUNT(*) FROM truth t JOIN agg a
              ON a.block = t.block AND a.txn_id = t.txn_id
            WHERE a.ww <> t.true_ww OR a.wr <> t.true_wr
               OR a.rw <> t.true_rw
        """).fetchone()
        assert rows[0] == 0, f"{rows[0]} truth rows disagree with the schedule"
    finally:
        con.close()


def test_v20_no_dependence_on_sqlite_build(inputs):
    """V20: POW and LN must not be assumed present in the SQLite build.

    SQLite has shipped pow/ln since 3.35, but only under the compile-time
    option SQLITE_ENABLE_MATH_FUNCTIONS, which several common distributions
    omit. A pipeline that calls them without registering them passes wherever
    the option happens to be on and fails everywhere else, which is the worst
    kind of environment dependence: invisible to the author.

    This asserts the solver registers its own. Shadowing the names with
    raising stubs before the solver runs is not possible across a subprocess
    boundary, so the check is made structurally instead: the solution source
    must register both names, and the local build's behaviour is reported for
    the record rather than relied upon.
    """
    src = (ROOT / "solution" / "solve_full.py").read_text()
    for fn in ("POW", "LN"):
        assert f'create_function("{fn}"' in src, \
            f"{fn} is used in SQL but never registered as a UDF"

    con = sqlite3.connect(":memory:")
    try:
        opts = [r[0] for r in con.execute("PRAGMA compile_options")]
        has_math = any("ENABLE_MATH_FUNCTIONS" in o for o in opts)
        con.create_function("POW", 2, math.pow, deterministic=True)
        con.create_function("LN", 1, math.log, deterministic=True)
        assert close(con.execute("SELECT POW(2.0,3.0)").fetchone()[0], 8.0)
        assert close(con.execute("SELECT LN(8.0)").fetchone()[0],
                     math.log(8.0))
        print(f"\n  [build supplies math functions: {has_math}]")
    finally:
        con.close()
