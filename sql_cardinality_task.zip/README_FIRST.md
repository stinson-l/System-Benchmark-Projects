# Cardinality estimation task package

A Terminal-Bench-style task package on selectivity estimation and access-path
choice, built to the same structure as the morphology/BPE package it was
modelled on.

## Layout

```
task/
  PROMPT.txt              what the solver is given
  SPEC.md                 authoritative: parameters, definitions, output schema
  SCHEMA_superseded.md    pointer to SPEC.md section 14
  data/
    fact.csv              144,000 rows, 36 blocks of 4,000
    dim_channel.csv       60 keys -> 3 channel groups
    dim_region.csv        40 keys -> 2 region groups
    workload.csv          100 six-predicate conjunctive queries
    truth.csv             3,600 block-query truths, incl. per-path intermediates
    params.json           fixed parameters
    warehouse.db          the same five tables as SQLite
  Sol/
    expected_results.json the gold file: 1,440 leaves, 59,859 bytes
    solution/
      solve_full.py       reference driver
      sql/*.sql           where the work actually happens (5 stages)
    crosscheck/
      solve_narrow_crosscheck.py   independent NumPy re-derivation, no SQL
    tests/
      test_outputs.py     19-layer verifier
```

The uploaded package that this one mirrors was the trimmed variant, without a
`research/` directory, so none is included here.

## Why SQL is intrinsic rather than decorative

The reference solution contains no selectivity estimation, no bucketing and no
cost accounting of its own. `solve_full.py` loads the frozen CSVs into SQLite,
walks the 30 evaluation blocks in order, and executes the five scripts in
`sql/`. Bucket assignment, MCV selection, the four combination schemes, the
three readouts, the joint contingency table, the systematic sample, the control
permutation, bit-length arithmetic and the drift binning are all relational.
The two exceptions are named in SPEC.md section 13 and are library calls, not
reimplementations: `scipy.stats.ttest_rel` and a normal tail.

The crosscheck re-derives 32 of these quantities in NumPy from the
specification text alone, sharing no code and executing no SQL. The two agree
to 3.4e-16 relative across all 104 compared quantities, which is the evidence
that the specification is sufficient to determine the answer — a solver need
not guess at anything the reference happened to do.

## Determinism

No pseudo-random generator is consumed anywhere. The control arm is a
deal-into-piles permutation, so there is no seed to agree on and no draw order
to get wrong. Bucket boundaries come from integer division, tie-breaks are
integer or string comparisons, and bit widths come from repeated halving rather
than a logarithm. Reruns are byte-identical.

## Running it

```
python task/Sol/solution/solve_full.py task/data /tmp/results.json   # ~60 s
python task/Sol/crosscheck/solve_narrow_crosscheck.py task/data /tmp/narrow.json
cd task/Sol && python -m pytest tests/test_outputs.py -q
```

The suite reports 17 passed and 2 skipped when run against the gold file alone;
the two skips are the rerun and perturbation layers, which need a solver at
`/app/solve.py`. With one staged there, all 19 pass.

## What the study finds

The headline result is a dissociation. Against a control that permutes each
attribute's frequency vector — preserving the count multiset exactly while
destroying the association between a value and its frequency — the real
histograms are indistinguishable on q-error (paired t, p = 0.95) and completely
separated on plan agreement (p = 1.2e-14). Knowing where the mass sits buys
almost nothing measurable in accuracy and nearly everything in plan choice.

Around that:

- Selinger's 1979 constants, storing nothing, land within 37% of a 320-bucket
  histogram on q-error (7.16 vs 5.25) and get 18.8% plan agreement against
  66.4%. The best sweep configuration costs 964% more bits.
- `minsel` has the worst q-error of any scheme (~23.5) and the best plan
  agreement (~68%). q-error and plan agreement rank estimators differently,
  which is the Leis et al. critique reproduced from scratch.
- `cascade` halves q-error, costs 2.1× the bits, and buys exactly 0.00 plan
  agreement, because the most dependent pair is consistently (a2,a3), which
  straddles the two access paths.
- Quadrupling the bucket budget moves q-error about 1%. Resolution is not the
  binding constraint; staleness is — across the train-to-final era the same
  synopsis goes from 11.71 to 17.56 q-error and from 61.5% to 38.8% plan
  agreement.
