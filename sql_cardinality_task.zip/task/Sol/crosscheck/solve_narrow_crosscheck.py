"""
Narrow crosscheck: an independent re-derivation of 32 reported quantities.

    python solve_narrow_crosscheck.py <data_dir> <out_path>

This file shares no code with the reference solution and issues no SQL.  It
was written from SPEC.md rather than from the reference implementation, and it
takes a different route to the same numbers: histograms are built by
``cumsum`` over a dense per-value count vector and applied to all 100 queries
at once as a matrix product, where the reference groups a bucket relation
against a predicate relation and lets the query planner choose the join order.
Bucket assignment there is integer division inside SQL; here it is integer
division inside NumPy.  The two agree to within 1e-12 relative on every
quantity below.

Its purpose is not coverage.  It is to establish that the specification is
sufficient: that a second implementation, reading only the prose, lands on the
same numbers.  Quantities are chosen to isolate one mechanism each -- the cost
accounting, the two synopsis families, the three readouts, the four
combination schemes, the trigger recursion, the plan comparison, the control
permutation, the drift binning -- so that a mismatch points somewhere.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ATTRS = ("a1", "a2", "a3", "a4")
PREDS = ("a1", "a2", "a3", "a4", "g1", "g2")


# ----------------------------------------------------------------- basics
def blen(v: int) -> int:
    return max(1, int(v).bit_length())


def equidepth(cnt: np.ndarray, vals: np.ndarray, B: int):
    """Equi-depth buckets: value v goes to bucket (cum_before(v) * B) // n."""
    n = int(cnt.sum())
    if n == 0:
        return np.empty(0, int), np.empty(0, int), np.empty(0, int)
    cb = np.concatenate(([0], np.cumsum(cnt)[:-1]))
    bid = (cb.astype(np.int64) * B) // n
    lo, hi, c = [], [], []
    for b in np.unique(bid):
        m = bid == b
        lo.append(vals[m][0])
        hi.append(vals[m][-1])
        c.append(int(cnt[m].sum()))
    return np.array(lo), np.array(hi), np.array(c)


def bucket_mass(lo, hi, cnt, qlo, qhi, ro):
    """Mass each query draws from each bucket, under one readout."""
    if len(lo) == 0:
        return np.zeros(len(qlo))
    L = np.maximum(qlo[:, None], lo[None, :])
    H = np.minimum(qhi[:, None], hi[None, :])
    ov = np.maximum(0, H - L + 1)
    span = (hi - lo + 1)[None, :]
    if ro == "interp":
        f = ov / span
    elif ro == "mid":
        mid = (lo + (hi - lo) // 2)[None, :]
        f = ((mid >= qlo[:, None]) & (mid <= qhi[:, None])).astype(float)
    else:
        f = np.where(ov == span, 1.0, np.where(ov > 0, 0.5, 0.0))
    return f @ cnt.astype(float)


def synopsis(counts: dict, B: int, fam: str):
    """Return per-attribute (lo, hi, cnt, mcv_vals, mcv_cnt) and bucket total."""
    out, used = {}, 0
    for a in ATTRS:
        vals, cnt = counts[a]
        if fam == "depth":
            lo, hi, c = equidepth(cnt, vals, B)
            out[a] = (lo, hi, c, np.empty(0, int), np.empty(0, int))
            used += len(lo)
        else:
            m = B - B // 4
            order = np.lexsort((vals, -cnt))[:m]
            keep = np.zeros(len(vals), bool)
            keep[order] = True
            mv, mc = vals[keep], cnt[keep]
            rv, rc = vals[~keep], cnt[~keep]
            lo, hi, c = equidepth(rc, rv, B // 4)
            out[a] = (lo, hi, c, mv, mc)
            used += len(lo) + len(mv)
    return out, used


def sel_attr(syn, qlo, qhi, n, ro):
    s = {}
    for a in ATTRS:
        lo, hi, c, mv, mc = syn[a]
        mass = bucket_mass(lo, hi, c, qlo[a], qhi[a], ro)
        if len(mv):
            inr = ((mv[None, :] >= qlo[a][:, None])
                   & (mv[None, :] <= qhi[a][:, None]))
            mass = mass + inr.astype(float) @ mc.astype(float)
        s[a] = np.minimum(1.0, mass / n)
    return s


def combine(s, nb, scheme, fired):
    """Full-conjunction selectivity under one scheme."""
    if scheme == "mix":
        scheme = "ebo" if fired else "avi"
    S = np.stack([s[p] for p in PREDS], axis=1)
    if scheme == "avi":
        return S.prod(axis=1)
    M = np.floor(nb * S + 0.5).astype(np.int64)
    order = np.lexsort((np.arange(len(PREDS))[None, :].repeat(len(S), 0), -M),
                       axis=1)
    R = np.take_along_axis(S, order, axis=1)
    if scheme == "minsel":
        return R[:, -1]
    e = np.array([1.0, 0.5, 0.25, 0.125, 0.0625, 0.03125])
    return np.prod(R ** e[None, :], axis=1)


def pair_sel(sx, sy, nb, scheme, fired):
    if scheme == "mix":
        scheme = "ebo" if fired else "avi"
    if scheme == "avi":
        return sx * sy
    mx = np.floor(nb * sx + 0.5)
    my = np.floor(nb * sy + 0.5)
    if scheme == "minsel":
        return np.where(mx <= my, sx, sy)
    hi = np.where(mx >= my, sx, sy)
    lo = np.where(mx >= my, sy, sx)
    return hi * lo ** 0.5


def clamp(nb, s):
    return np.clip(np.floor(nb * np.asarray(s) + 0.5).astype(np.int64), 1, nb)


def plan_of(a, b, c):
    return np.where((a <= b) & (a <= c), "A", np.where(b <= c, "B", "C"))


# ------------------------------------------------------------------- main
def main(argv: list[str]) -> int:
    data, out = Path(argv[1]), Path(argv[2])
    P = json.loads((data / "params.json").read_text())
    fact = pd.read_csv(data / "fact.csv")
    dch = pd.read_csv(data / "dim_channel.csv")
    drg = pd.read_csv(data / "dim_region.csv")
    wl = pd.read_csv(data / "workload.csv")
    truth = pd.read_csv(data / "truth.csv")

    fact = fact.merge(dch, on="k1").merge(drg, on="k2").sort_values("row_id")
    blocks = sorted(fact["block"].unique())
    nb = int((fact["block"] == blocks[0]).sum())
    W = P["window_blocks"]
    nq = len(wl)
    nw = nb * W
    dom = P["domain_size"]
    vbits = {a: blen(dom[a] - 1) for a in ATTRS}
    cbits_w, cbits_b = blen(nw), blen(nb)
    ng = fact["g1"].nunique() + fact["g2"].nunique()
    target = P["target_q_error"]
    gate = P["gate_multiple"] * target

    qlo = {a: wl[f"lo{a[1]}"].to_numpy() for a in ATTRS}
    qhi = {a: wl[f"hi{a[1]}"].to_numpy() for a in ATTRS}
    qg1, qg2 = wl["g1"].to_numpy(), wl["g2"].to_numpy()
    tru = {b: g.set_index("query_id").loc[wl["query_id"]]
           for b, g in truth.groupby("block")}

    def counts_of(rows, permute):
        c = {}
        for a in ATTRS:
            v, k = np.unique(rows[a].to_numpy(), return_counts=True)
            if permute:
                p = P["control_piles"][a]
                j = np.arange(len(v))
                k = k[np.lexsort((j, j % p))]
            c[a] = (v, k)
        return c

    def gsel(rows):
        n = len(rows)
        c1 = rows["g1"].value_counts()
        c2 = rows["g2"].value_counts()
        return (np.array([c1.get(g, 0) for g in qg1]) / n,
                np.array([c2.get(g, 0) for g in qg2]) / n)

    def syn_bits(syn, fam, cb):
        t = ng * cb
        for a in ATTRS:
            lo, _, _, mv, _ = syn[a]
            t += len(lo) * (2 * vbits[a] + 2 * cb)
            t += len(mv) * (vbits[a] + cb)
        return t

    # --------------------------------------------------- walk-forward pass
    want_sweep = ["depth_avi_320", "depth_avi_80", "depth_minsel_80",
                  "depth_mix_160", "mcv_avi_80"]
    readouts = ("interp", "mid", "half")
    acc = {}

    def push(key, r, d, g):
        acc.setdefault(key, []).append((r, d, g))

    fired = {(arm, c): False for arm in "tc" for c in want_sweep}
    for blk in blocks[W:]:
        win = fact[(fact["block"] >= blk - W) & (fact["block"] < blk)]
        srv = fact[fact["block"] == blk]
        tt = np.maximum(1, tru[blk]["true_rows"].to_numpy())
        tp = plan_of(tru[blk]["true_path_a"].to_numpy(),
                     tru[blk]["true_path_b"].to_numpy(),
                     tru[blk]["true_path_c"].to_numpy())
        sg1, sg2 = gsel(win)
        nxt = {}

        for arm in "tc":
            cnts = counts_of(win, arm == "c")
            for fam in ("depth", "mcv"):
                for B in (20, 40, 80):
                    cfg_syn, used = synopsis(cnts, B, fam)
                    bits = syn_bits(cfg_syn, fam, cbits_w)
                    for ro in readouts:
                        s = sel_attr(cfg_syn, qlo, qhi, nw, ro)
                        s["g1"], s["g2"] = sg1, sg2
                        for scheme in ("avi", "minsel", "mix"):
                            name = f"{fam}_{scheme}_{B * 4}"
                            if name not in want_sweep:
                                continue
                            f = fired[(arm, name)]
                            ef = clamp(nb, combine(s, nb, scheme, f))
                            ea = clamp(nb, pair_sel(s["a1"], s["a2"], nb,
                                                    scheme, f))
                            eb = clamp(nb, pair_sel(s["a3"], s["a4"], nb,
                                                    scheme, f))
                            ec = clamp(nb, pair_sel(sg1, sg2, nb, scheme, f))
                            q = np.maximum(ef, tt) / np.minimum(ef, tt)
                            bpq = (bits + sum(blen(int(x)) for x in ef)) / nq
                            push(f"{arm}/{ro}/{name}", q.mean(), bpq,
                                 (plan_of(ea, eb, ec) == tp).mean())
                            if ro == "interp":
                                nxt[(arm, name)] = q.mean() > gate

        # uniform, sample, oracle -- treatment only
        sr, se = P["selinger_range"], P["selinger_equality"]
        u = np.ones(nq)
        for a in ATTRS:
            u = u * np.where(qlo[a] == qhi[a], se, sr)
        u = u * (1.0 / fact["g1"].nunique()) * (1.0 / fact["g2"].nunique())
        ua = np.ones(nq)
        for a in ("a1", "a2"):
            ua = ua * np.where(qlo[a] == qhi[a], se, sr)
        ub = np.ones(nq)
        for a in ("a3", "a4"):
            ub = ub * np.where(qlo[a] == qhi[a], se, sr)
        uc = np.full(nq, (1.0 / fact["g1"].nunique())
                     * (1.0 / fact["g2"].nunique()))
        ef = clamp(nb, u)
        q = np.maximum(ef, tt) / np.minimum(ef, tt)
        for ro in readouts:
            push(f"t/{ro}/uniform", q.mean(),
                 sum(blen(int(x)) for x in ef) / nq,
                 (plan_of(clamp(nb, ua), clamp(nb, ub), clamp(nb, uc))
                  == tp).mean())

        ns = P["sample_rows"]
        step = nw // ns
        smp = win.iloc[::step][:ns]
        mA = ((smp["a1"].to_numpy()[None, :] >= qlo["a1"][:, None])
              & (smp["a1"].to_numpy()[None, :] <= qhi["a1"][:, None])
              & (smp["a2"].to_numpy()[None, :] >= qlo["a2"][:, None])
              & (smp["a2"].to_numpy()[None, :] <= qhi["a2"][:, None]))
        mB = ((smp["a3"].to_numpy()[None, :] >= qlo["a3"][:, None])
              & (smp["a3"].to_numpy()[None, :] <= qhi["a3"][:, None])
              & (smp["a4"].to_numpy()[None, :] >= qlo["a4"][:, None])
              & (smp["a4"].to_numpy()[None, :] <= qhi["a4"][:, None]))
        mC = ((smp["g1"].to_numpy()[None, :] == qg1[:, None])
              & (smp["g2"].to_numpy()[None, :] == qg2[:, None]))
        ef = clamp(nb, (mA & mB & mC).sum(1) / ns)
        q = np.maximum(ef, tt) / np.minimum(ef, tt)
        sbits = ns * (sum(vbits.values())
                      + blen(fact["g1"].nunique() - 1)
                      + blen(fact["g2"].nunique() - 1))
        for ro in readouts:
            push(f"t/{ro}/sample", q.mean(),
                 (sbits + sum(blen(int(x)) for x in ef)) / nq,
                 (plan_of(clamp(nb, mA.sum(1) / ns), clamp(nb, mB.sum(1) / ns),
                          clamp(nb, mC.sum(1) / ns)) == tp).mean())

        ocnt = counts_of(srv, False)
        osyn, oused = synopsis(ocnt, 80, "depth")
        obits = syn_bits(osyn, "depth", cbits_b)
        og1, og2 = gsel(srv)
        for ro in readouts:
            s = sel_attr(osyn, qlo, qhi, nb, ro)
            ef = clamp(nb, s["a1"] * s["a2"] * s["a3"] * s["a4"] * og1 * og2)
            q = np.maximum(ef, tt) / np.minimum(ef, tt)
            push(f"t/{ro}/oracle", q.mean(),
                 (obits + sum(blen(int(x)) for x in ef)) / nq,
                 (plan_of(clamp(nb, s["a1"] * s["a2"]),
                          clamp(nb, s["a3"] * s["a4"]),
                          clamp(nb, og1 * og2)) == tp).mean())

        # cascade: joint table on the most dependent width-20 pair
        tcnt = counts_of(win, False)
        c20, _ = synopsis(tcnt, 20, "depth")
        c80, u80 = synopsis(tcnt, 80, "depth")
        b80 = syn_bits(c80, "depth", cbits_w)
        gid = {}
        for a in ATTRS:
            lo, hi, _, _, _ = c20[a]
            gid[a] = np.searchsorted(hi, win[a].to_numpy(), side="left")
        best, bestd = None, -1
        for i in range(4):
            for j in range(i + 1, 4):
                x, y = ATTRS[i], ATTRS[j]
                nx, ny = len(c20[x][0]), len(c20[y][0])
                J = np.zeros((nx, ny), np.int64)
                np.add.at(J, (gid[x], gid[y]), 1)
                d = int(np.abs(nw * J - J.sum(1)[:, None] * J.sum(0)[None, :]).sum())
                if d > bestd:
                    best, bestd = (x, y), d
        x, y = best
        nx, ny = len(c20[x][0]), len(c20[y][0])
        J = np.zeros((nx, ny), np.int64)
        np.add.at(J, (gid[x], gid[y]), 1)
        cells = int((J > 0).sum())
        cbits = b80 + cells * (2 * blen(19) + cbits_w)
        for ro in readouts:
            s = sel_attr(c80, qlo, qhi, nw, ro)
            fx = frac(c20[x], qlo[x], qhi[x], ro)
            fy = frac(c20[y], qlo[y], qhi[y], ro)
            sp = np.minimum(1.0, np.einsum("qi,ij,qj->q", fx, J.astype(float),
                                           fy) / nw)
            rest = np.ones(nq)
            for a in ATTRS:
                if a not in (x, y):
                    rest = rest * s[a]
            ef = clamp(nb, sp * rest * sg1 * sg2)
            ea = clamp(nb, sp if (x, y) == ("a1", "a2") else s["a1"] * s["a2"])
            eb = clamp(nb, sp if (x, y) == ("a3", "a4") else s["a3"] * s["a4"])
            ec = clamp(nb, sg1 * sg2)
            q = np.maximum(ef, tt) / np.minimum(ef, tt)
            push(f"t/{ro}/cascade", q.mean(),
                 (cbits + sum(blen(int(v)) for v in ef)) / nq,
                 (plan_of(ea, eb, ec) == tp).mean())

        fired.update(nxt)

    def col(key, i):
        return float(np.mean([r[i] for r in acc[key]]))

    res = {"corpus": {
        "n_blocks": len(blocks), "n_rows": int(len(fact)),
        "n_queries": nq, "n_eval_blocks": len(blocks) - W,
        "rows_per_block": nb,
        "mean_true_rows": float(truth["true_rows"].mean()),
        "budget_bits_320": int(sum(80 * (2 * vbits[a] + 2 * cbits_w)
                                   for a in ATTRS) + ng * cbits_w)}}

    for ro in readouts:
        res[ro] = {}
        for name in want_sweep + ["uniform", "sample", "oracle", "cascade"]:
            k = f"t/{ro}/{name}"
            if k in acc:
                res[ro][f"{name}_mean_q_error"] = col(k, 0)
                res[ro][f"{name}_plan_agreement_pct"] = col(k, 2) * 100.0
                res[ro][f"{name}_bits_per_query"] = col(k, 1)
    res["control"] = {}
    for name in ("depth_avi_320", "mcv_avi_80", "depth_mix_160"):
        res["control"][f"interp_{name}_mean_q_error"] = col(f"c/interp/{name}", 0)
        res["control"][f"interp_{name}_plan_agreement_pct"] = \
            col(f"c/interp/{name}", 2) * 100.0

    res.update(era_and_drift(fact, wl, truth, P, blocks, nb, nq, vbits, ng))
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(res, indent=1, sort_keys=True, allow_nan=False))
    return 0


def frac(bk, qlo, qhi, ro):
    """Per-bucket fractional overlap, shape (n_queries, n_buckets)."""
    lo, hi, cnt = bk[0], bk[1], bk[2]
    L = np.maximum(qlo[:, None], lo[None, :])
    H = np.minimum(qhi[:, None], hi[None, :])
    ov = np.maximum(0, H - L + 1)
    span = (hi - lo + 1)[None, :]
    if ro == "interp":
        return ov / span
    if ro == "mid":
        mid = (lo + (hi - lo) // 2)[None, :]
        return ((mid >= qlo[:, None]) & (mid <= qhi[:, None])).astype(float)
    return np.where(ov == span, 1.0, np.where(ov > 0, 0.5, 0.0))


def era_and_drift(fact, wl, truth, P, blocks, nb, nq, vbits, ng):
    """Reference-synopsis era statistics and the drift binning."""
    n_ep = P["n_epochs"]
    ep_len = len(blocks) // n_ep
    train = fact[fact["block"] < ep_len]
    alpha = P["renyi_alpha"]
    qlo = {a: wl[f"lo{a[1]}"].to_numpy() for a in ATTRS}
    qhi = {a: wl[f"hi{a[1]}"].to_numpy() for a in ATTRS}

    cnts = {}
    for a in ATTRS:
        v, k = np.unique(train[a].to_numpy(), return_counts=True)
        cnts[a] = (v, k)
    n = len(train)
    syn, used = synopsis(cnts, 80, "depth")
    s = sel_attr(syn, qlo, qhi, n, "interp")
    c1 = train["g1"].value_counts()
    c2 = train["g2"].value_counts()
    sg1 = np.array([c1.get(g, 0) for g in wl["g1"]]) / n
    sg2 = np.array([c2.get(g, 0) for g in wl["g2"]]) / n
    full = s["a1"] * s["a2"] * s["a3"] * s["a4"] * sg1 * sg2
    per = dict(zip(wl["query_id"], clamp(nb, full)))

    era = {}
    for tag, lo, hi in (("train", 0, ep_len - 1),
                        ("final", len(blocks) - ep_len, len(blocks) - 1)):
        sub = truth[(truth["block"] >= lo) & (truth["block"] <= hi)]
        e = sub["query_id"].map(per).to_numpy()
        t = np.maximum(1, sub["true_rows"].to_numpy())
        era[f"q_error_{tag}_era_320"] = float(
            (np.maximum(e, t) / np.minimum(e, t)).mean())
        era[f"underestimate_share_{tag}_era_320"] = float((e < t).mean())
        rows = fact[(fact["block"] >= lo) & (fact["block"] <= hi)]
        p = rows.groupby(list(ATTRS)).size().to_numpy() / len(rows)
        era[f"renyi_{tag}_era"] = float(
            np.log((p ** alpha).sum()) / (1 - alpha) / np.log(len(p)))

    g = train.groupby(list(ATTRS)).size().reset_index(name="c")
    g = g.sort_values(["c"] + list(ATTRS), ascending=[False, True, True, True,
                                                      True])
    rank = {tuple(r[:-1]): i + 1 for i, r in enumerate(g.to_numpy())}
    absent = len(g) + 1
    stat = np.array([rank.get(tuple(r), absent)
                     for r in fact[list(ATTRS)].to_numpy()])
    ep = np.minimum(fact["block"].to_numpy() // ep_len, n_ep - 1)
    tr = stat[fact["block"].to_numpy() < ep_len]

    def shares(bins):
        edges = np.percentile(tr, [100.0 * i / bins for i in range(1, bins)],
                              method="linear")
        b = np.searchsorted(edges, stat, side="right")
        return np.array([[np.mean(b[ep == e] == k) for k in range(bins)]
                         for e in range(n_ep)])

    six, ten = shares(6), shares(10)
    a, bb = stat[ep == 0], stat[ep == n_ep - 1]
    xs = np.union1d(a, bb)
    ks = float(np.abs(np.searchsorted(np.sort(a), xs, "right") / len(a)
                      - np.searchsorted(np.sort(bb), xs, "right") / len(bb)).max())
    era.update({"share_5_5": float(six[5][5]), "share_0_0": float(six[0][0]),
                "ks_0_5": ks, "decile_D9_E5": float(ten[5][9] * 100.0)})
    return {"reference": era}


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
