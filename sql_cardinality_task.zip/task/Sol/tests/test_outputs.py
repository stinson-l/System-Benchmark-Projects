"""
Deterministic verifier suite for /app/results.json.

    pytest -q task/tests/test_outputs.py

Every check is programmatic and returns pass/fail with no human judgment. The
suite passes only if every check passes. Checks are ordered cheap-to-expensive
so a structurally broken submission fails in milliseconds.

Layers:
  V1-V3    the file and its shape
  V4-V5    comparison against the reference values
  V6-V9    internal consistency, needing no reference
  V10-V11  closed-form recomputation from the inputs alone
  V12-V15  independent recomputation of individual pipeline components
  V16-V18  the guarantee, stability and anti-hardcoding
  V19      re-derivation in SQL against the shipped warehouse
"""

from __future__ import annotations

import json
import math
import os
import sqlite3
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
SUBMISSION = Path(os.environ.get("SUBMISSION", "/app/results.json"))
if not SUBMISSION.exists():                      # local runs
    SUBMISSION = ROOT / "expected_results.json"
REFERENCE = ROOT / "expected_results.json"
# In the deployed harness data/ sits beside tests/; in this package tests/
# live under Sol/ and data/ is one level up. Accept either.
DATA = ROOT / "data" if (ROOT / "data").is_dir() else ROOT.parent / "data"
CROSSCHECK = ROOT / "crosscheck" / "solve_narrow_crosscheck.py"

TARGET = 4.0
N_EVAL = 30
N_QUERIES = 100
ROWS_PER_BLOCK = 4000
VARIANTS = ("interp", "mid", "half")
EXACT_FIELDS = {"n_blocks", "n_rows", "n_queries", "n_eval_blocks",
                "n_window_blocks", "n_attributes", "n_channel_groups",
                "n_region_groups", "rows_per_block", "count_bits",
                "budgets", "budget_bits", "attribute_bits", "best_config",
                "invalid_estimates_audited"}
RTOL = 1e-3


def _reject(x):
    raise AssertionError(f"non-finite token in JSON: {x}")


@pytest.fixture(scope="session")
def raw() -> str:
    assert SUBMISSION.exists(), f"missing {SUBMISSION}"
    return SUBMISSION.read_text(encoding="utf-8")


@pytest.fixture(scope="session")
def sub(raw) -> dict:
    return json.loads(raw, parse_constant=_reject)


@pytest.fixture(scope="session")
def ref() -> dict:
    return json.loads(REFERENCE.read_text(encoding="utf-8"))


@pytest.fixture(scope="session")
def inputs():
    import pandas as pd
    workload = pd.read_csv(DATA / "workload.csv")
    truth = pd.read_csv(DATA / "truth.csv")
    params = json.loads((DATA / "params.json").read_text())
    chan = pd.read_csv(DATA / "dim_channel.csv")
    reg = pd.read_csv(DATA / "dim_region.csv")
    return workload, truth, params, chan, reg


@pytest.fixture(scope="session")
def narrow(tmp_path_factory) -> dict:
    """Independent implementation, run fresh against the frozen inputs."""
    out = tmp_path_factory.mktemp("cc") / "narrow.json"
    subprocess.run([sys.executable, str(CROSSCHECK), str(DATA), str(out)],
                   check=True, capture_output=True)
    return json.loads(out.read_text())


def leaves(o, p=""):
    d = {}
    if isinstance(o, dict):
        for k, v in o.items():
            d.update(leaves(v, f"{p}/{k}"))
    elif isinstance(o, list):
        for i, v in enumerate(o):
            d.update(leaves(v, f"{p}[{i}]"))
    else:
        d[p] = o
    return d


def shape(o):
    if isinstance(o, dict):
        return {k: shape(v) for k, v in sorted(o.items())}
    if isinstance(o, list):
        return ["list", len(o)] + [shape(v) for v in o[:1]]
    if isinstance(o, bool):
        return "bool"
    if isinstance(o, str):
        return "str"
    if isinstance(o, (int, float)):
        return "num"
    return type(o).__name__


def close(got, exp) -> bool:
    if exp == 0:
        return abs(got) <= RTOL
    return abs(got - exp) <= RTOL * abs(exp)


def blen(v: int) -> int:
    """Bit length of a non-negative integer, as the pipeline defines it."""
    return int(v).bit_length()


# ------------------------------------------------------------------ V1-V3
def test_v1_file_is_strict_json(raw, sub):
    """V1: exists, decodes as UTF-8, parses as strict JSON, no NaN/Infinity."""
    for token in ("NaN", "Infinity", "-Infinity"):
        assert token not in raw, f"forbidden token {token!r} in output"
    assert isinstance(sub, dict)


def test_v2_top_level_keys(sub):
    """V2: exactly three top-level keys, no more, no fewer."""
    assert set(sub) == {"database_report", "drift_report", "variants"}
    assert set(sub["variants"]) == set(VARIANTS)


def test_v3_schema_matches_reference(sub, ref):
    """V3: identical nesting, container types, list lengths and leaf types.

    Catches an object emitted as an array (e.g. schema_stats as 12 floats),
    which no tolerance check would ever reach.
    """
    assert shape(sub) == shape(ref)


# ------------------------------------------------------------------ V4-V5
def test_v4_exact_fields(sub, ref):
    """V4: counts, sizes, names and the audit field compare for equality."""
    S, R = leaves(sub), leaves(ref)
    bad = []
    for k, exp in R.items():
        leaf = k.rsplit("/", 1)[-1].split("[")[0]
        parent = k.rsplit("/", 2)[-2] if "/" in k[1:] else ""
        if leaf in EXACT_FIELDS or parent in EXACT_FIELDS \
                or isinstance(exp, (str, bool)):
            if S.get(k) != exp:
                bad.append((k, exp, S.get(k)))
    assert not bad, f"{len(bad)} exact-equality mismatches, e.g. {bad[:3]}"


def test_v5_all_floats_within_tolerance(sub, ref):
    """V5: every remaining numeric leaf within 1e-3 relative (1e-3 abs at 0)."""
    S, R = leaves(sub), leaves(ref)
    bad = []
    for k, exp in R.items():
        if isinstance(exp, (str, bool)):
            continue
        got = S.get(k)
        assert isinstance(got, (int, float)), f"{k} is not numeric"
        if not close(got, exp):
            bad.append((k, exp, got))
    assert not bad, (f"{len(bad)} of {len(R)} values outside tolerance, "
                     f"e.g. {bad[:3]}")


# ------------------------------------------------------------------ V6-V9
def test_v6_metric_algebra(sub):
    """V6: relations among the seven metrics that hold by definition.

    A q-error is max(est,true)/min(est,true) and so is at least 1; the mean
    cannot exceed the 95th percentile, which cannot exceed the maximum; and
    excess_ratio is the mean divided by the target, exactly.
    """
    for v, panel in sub["variants"].items():
        for arm in ("strategy_metrics", "control_metrics"):
            for name, m in panel[arm].items():
                tag = f"{v}/{arm}/{name}"
                assert m["mean_q_error"] >= 1.0 - 1e-9, tag
                assert m["mean_q_error"] <= m["p95_q_error"] + 1e-9, tag
                assert m["p95_q_error"] <= m["max_q_error"] + 1e-9, tag
                assert 0.0 <= m["pct_within_target"] <= 1.0, tag
                assert 0.0 <= m["plan_agreement_pct"] <= 100.0 + 1e-9, tag
                assert m["bits_per_query"] >= 0.0, tag
                assert close(m["excess_ratio"],
                             m["mean_q_error"] / TARGET), tag


def test_v7_quantization_of_observables(sub):
    """V7: rates are counts over fixed denominators and cannot be arbitrary.

    Thirty evaluation blocks of one hundred queries each make plan agreement a
    multiple of 100/3000 and pct_within_target a multiple of 1/30. A
    fabricated or interpolated number lands off the lattice.
    """
    for v, panel in sub["variants"].items():
        for arm in ("strategy_metrics", "control_metrics"):
            for name, m in panel[arm].items():
                tag = f"{v}/{arm}/{name}"
                r = m["plan_agreement_pct"] * N_EVAL * N_QUERIES / 100.0
                assert abs(r - round(r)) < 1e-5, f"{tag} agreement off lattice"
                s = m["pct_within_target"] * N_EVAL
                assert abs(s - round(s)) < 1e-6, f"{tag} slo off lattice"


def test_v8_significance_internal_consistency(sub):
    """V8: ranks sum to 3.0, p-values are probabilities, Nemenyi follows ranks."""
    from scipy import stats as st
    for v, panel in sub["variants"].items():
        for fam, metrics in panel["significance"].items():
            for metric, s in metrics.items():
                tag = f"{v}/{fam}/{metric}"
                assert abs(s["control_rank"] + s["treatment_rank"] - 3.0) < 1e-9, tag
                assert 0.0 <= s["t_test_p"] <= 1.0, tag
                assert 0.0 <= s["nemenyi_p"] <= 1.0, tag
                q = abs(s["treatment_rank"] - s["control_rank"]) * math.sqrt(12)
                expect = min(2.0 * st.norm.sf(q / math.sqrt(2.0)), 1.0)
                assert close(s["nemenyi_p"], expect), tag


def test_v9_cross_variant_invariants(sub):
    """V9: what a readout convention cannot change must not have changed.

    A readout decides how a bucket already built is interpreted. Synopsis
    construction, the bucket counts it uses and the trigger stream are defined
    without reference to the readout, and uniform and sample never consult a
    bucket at all. A solver that rebuilds the synopsis inside the readout loop,
    or that lets the readout feed back into the trigger, breaks these and
    nothing else.
    """
    base = sub["variants"]["interp"]
    for v in VARIANTS[1:]:
        p = sub["variants"][v]
        for field in ("mean_buckets_used", "trigger_rate",
                      "invalid_estimates_audited", "n_eval_blocks"):
            assert close(p["diagnostics"][field],
                         base["diagnostics"][field]), f"{v}/{field}"
        for name in ("uniform", "sample"):
            for k, x in base["strategy_metrics"][name].items():
                assert close(p["strategy_metrics"][name][k], x), f"{v}/{name}/{k}"


# ---------------------------------------------------------------- V10-V11
def test_v10_cost_accounting_closed_form(sub, inputs):
    """V10: the bit accounting is recomputed from params.json alone.

    No window statistics enter these, so a mismatch isolates the code-width
    rule and the budget arithmetic from everything downstream. A bucket stores
    two boundary values and two counts; five counts of header follow each
    synopsis.
    """
    _, _, params, chan, reg = inputs
    dr = sub["database_report"]
    dom = params["domain_size"]
    vb = {a: blen(dom[a] - 1) for a in params["attributes"]}
    cb = blen(ROWS_PER_BLOCK * params["window_blocks"])

    assert dr["n_attributes"] == len(params["attributes"])
    assert dr["count_bits"] == cb
    assert dr["budgets"] == list(params["bucket_budgets"])
    assert dr["attribute_bits"] == {a: vb[a] for a in params["attributes"]}
    assert dr["n_channel_groups"] == chan["g1"].nunique()
    assert dr["n_region_groups"] == reg["g2"].nunique()

    # The synopsis header stores one count per distinct group value in the two
    # dimension catalogs -- a property of the schema, not of any window, so a
    # group absent from a particular window still occupies its slot.
    n_groups = chan["g1"].nunique() + reg["g2"].nunique()
    assert n_groups == 5, "this dataset has 3 channel groups and 2 region groups"
    per_bucket = sum(2 * vb[a] + 2 * cb for a in params["attributes"])
    for budget in params["bucket_budgets"]:
        want = (budget // len(params["attributes"])) * per_bucket + n_groups * cb
        assert dr["budget_bits"][str(budget)] == want, budget


def test_v11_uniform_baseline_closed_form(sub, inputs):
    """V11: the Selinger baseline has a closed form and needs no synopsis.

    The 1979 constants assign 1/10 to an equality predicate and 1/3 to a range
    predicate regardless of the data, and the two group predicates are charged
    the catalog reciprocal of their distinct-value counts. Every estimate is
    therefore fixed before a single row is read, which isolates the query
    parsing, the clamp and the q-error definition from every learned
    component.
    """
    workload, truth, params, chan, reg = inputs
    se, sr = params["selinger_equality"], params["selinger_range"]
    cat = (1.0 / chan["g1"].nunique()) * (1.0 / reg["g2"].nunique())
    nb = ROWS_PER_BLOCK

    sel = {}
    for r in workload.itertuples():
        s = cat
        for i in (1, 2, 3, 4):
            lo = getattr(r, f"lo{i}")
            hi = getattr(r, f"hi{i}")
            s *= se if lo == hi else sr
        sel[r.query_id] = s

    est = {q: min(nb, max(1, math.floor(nb * s + 0.5))) for q, s in sel.items()}
    evalb = sorted(truth["block"].unique())[-N_EVAL:]
    tv = truth[truth["block"].isin(evalb)]

    per_block = {}
    for b, g in tv.groupby("block"):
        qs = []
        for r in g.itertuples():
            e, t = est[r.query_id], max(1, r.true_rows)
            qs.append(max(e, t) / min(e, t))
        per_block[b] = sum(qs) / len(qs)
    exp_mean = sum(per_block.values()) / len(per_block)

    bits = sum(blen(est[q]) for q in workload["query_id"]) / N_QUERIES

    m = sub["variants"]["interp"]["strategy_metrics"]["uniform"]
    assert close(m["mean_q_error"], exp_mean), "uniform q-error"
    assert close(m["bits_per_query"], bits), "uniform description length"


# ---------------------------------------------------------------- V12-V15
def test_v12_database_and_drift(sub, narrow):
    """V12: warehouse counts, the reference synopsis and the drift binning."""
    dr, df = sub["database_report"], sub["drift_report"]
    n = narrow
    assert dr["n_blocks"] == n["corpus"]["n_blocks"]
    assert dr["n_rows"] == n["corpus"]["n_rows"]
    assert dr["n_queries"] == n["corpus"]["n_queries"]
    assert dr["n_eval_blocks"] == n["corpus"]["n_eval_blocks"]
    assert dr["rows_per_block"] == n["corpus"]["rows_per_block"]
    assert dr["budget_bits"]["320"] == n["corpus"]["budget_bits_320"]
    assert close(dr["mean_true_rows"], n["corpus"]["mean_true_rows"])

    s = dr["schema_stats"]["320"]
    assert close(s["q_error_train_era"], n["reference"]["q_error_train_era_320"])
    assert close(s["q_error_final_era"], n["reference"]["q_error_final_era_320"])
    assert close(s["underestimate_share_train_era"],
                 n["reference"]["underestimate_share_train_era_320"])
    assert close(s["underestimate_share_final_era"],
                 n["reference"]["underestimate_share_final_era_320"])
    assert close(s["renyi_train_era"], n["reference"]["renyi_train_era"])
    assert close(s["renyi_final_era"], n["reference"]["renyi_final_era"])

    assert close(df["epoch_ks_matrix"][0][5], n["reference"]["ks_0_5"])
    assert close(df["epoch_share_matrix"][0][0], n["reference"]["share_0_0"])
    assert close(df["epoch_share_matrix"][5][5], n["reference"]["share_5_5"])
    assert close(df["decile_share_pct"]["D9"]["E5"], n["reference"]["decile_D9_E5"])
    for row in df["epoch_share_matrix"]:
        assert abs(sum(row) - 1.0) < 1e-9
    for e, row in enumerate(df["conditional_epoch_share_matrix"]):
        assert abs(row[e]) < 1e-12, "conditional diagonal must be zero"
        assert abs(sum(row) - 1.0) < 1e-9


def test_v13_synopsis_families_and_budgets(sub, narrow):
    """V13: the two synopsis families and the budget ladder, recomputed.

    The mcv family is the sensitive one: it splits a budget between a most
    common value list and an equi-depth histogram over the residue, and an
    implementation that lets a value fall into both double counts its mass.
    """
    sm = sub["variants"]["interp"]["strategy_metrics"]
    n = narrow["interp"]
    assert close(sm["depth_avi_320"]["mean_q_error"],
                 n["depth_avi_320_mean_q_error"]), "depth family"
    assert close(sm["depth_avi_320"]["plan_agreement_pct"],
                 n["depth_avi_320_plan_agreement_pct"]), "depth plan agreement"
    assert close(sm["depth_avi_80"]["mean_q_error"],
                 n["depth_avi_80_mean_q_error"]), "depth at the tight budget"
    assert close(sm["mcv_avi_80"]["mean_q_error"],
                 n["mcv_avi_80_mean_q_error"]), "mcv family"
    assert close(sm["mcv_avi_80"]["plan_agreement_pct"],
                 n["mcv_avi_80_plan_agreement_pct"]), "mcv plan agreement"
    assert close(sm["depth_minsel_80"]["mean_q_error"],
                 n["depth_minsel_80_mean_q_error"]), "minimum-selectivity scheme"
    assert close(sm["depth_avi_320"]["bits_per_query"],
                 n["depth_avi_320_bits_per_query"]), "cost at the wide budget"


def test_v14_readouts_and_reference_structures(sub, narrow):
    """V14: the three readouts, plus uniform, sample, oracle and cascade."""
    V = sub["variants"]
    assert close(V["interp"]["strategy_metrics"]["uniform"]["mean_q_error"],
                 narrow["interp"]["uniform_mean_q_error"]), "uniform"
    assert close(V["interp"]["strategy_metrics"]["sample"]["mean_q_error"],
                 narrow["interp"]["sample_mean_q_error"]), "sample"
    assert close(V["interp"]["strategy_metrics"]["oracle"]["mean_q_error"],
                 narrow["interp"]["oracle_mean_q_error"]), "oracle"
    assert close(V["interp"]["strategy_metrics"]["cascade"]["mean_q_error"],
                 narrow["interp"]["cascade_mean_q_error"]), "cascade"
    assert close(V["interp"]["strategy_metrics"]["cascade"]["plan_agreement_pct"],
                 narrow["interp"]["cascade_plan_agreement_pct"]), "cascade plans"
    assert close(V["mid"]["strategy_metrics"]["depth_avi_80"]["mean_q_error"],
                 narrow["mid"]["depth_avi_80_mean_q_error"]), "mid readout"
    assert close(V["half"]["strategy_metrics"]["mcv_avi_80"]["mean_q_error"],
                 narrow["half"]["mcv_avi_80_mean_q_error"]), "half readout"
    assert close(V["half"]["strategy_metrics"]["depth_mix_160"]["bits_per_query"],
                 narrow["half"]["depth_mix_160_bits_per_query"]), "half cost"


def test_v15_control_arm_permutation(sub, narrow):
    """V15: the control arm, isolating the deal-into-piles permutation.

    The control permutes each attribute's count vector while holding its
    distinct-value set fixed, so the count multiset survives exactly and only
    the association between a value and its frequency is destroyed. A
    submission that permutes the value list instead, that permutes once for
    all four attributes rather than with each attribute's own pile count, or
    that reshuffles inside the configuration loop reproduces every treatment
    number and fails here.
    """
    c = sub["variants"]["interp"]["control_metrics"]
    n = narrow["control"]
    assert close(c["depth_avi_320"]["mean_q_error"],
                 n["interp_depth_avi_320_mean_q_error"])
    assert close(c["depth_avi_320"]["plan_agreement_pct"],
                 n["interp_depth_avi_320_plan_agreement_pct"])
    assert close(c["mcv_avi_80"]["mean_q_error"],
                 n["interp_mcv_avi_80_mean_q_error"])
    assert close(c["depth_mix_160"]["mean_q_error"],
                 n["interp_depth_mix_160_mean_q_error"])
    assert close(c["depth_mix_160"]["plan_agreement_pct"],
                 n["interp_depth_mix_160_plan_agreement_pct"])


# ---------------------------------------------------------------- V16-V18
def test_v16_estimate_guarantee(sub):
    """V16: no structure may emit an estimate outside the admissible range.

    Every estimate is an integer in [1, rows_per_block] after the clamp. The
    audit samples four evaluation steps and counts violations; it must be
    zero for every readout.
    """
    for v, panel in sub["variants"].items():
        assert panel["diagnostics"]["invalid_estimates_audited"] == 0, v


@pytest.mark.skipif(not Path("/app/solve.py").exists(),
                    reason="no solver script to re-run")
def test_v17_stability_across_runs(raw):
    """V17: re-running the solver reproduces the submission byte for byte."""
    tmp = Path("/tmp/rerun.json")
    subprocess.run([sys.executable, "/app/solve.py", str(DATA), str(tmp)],
                   check=True, capture_output=True)
    assert tmp.read_text(encoding="utf-8") == raw, "output not reproducible"


@pytest.mark.skipif(not Path("/app/solve.py").exists(),
                    reason="no solver script to re-run")
def test_v18_not_hardcoded(tmp_path):
    """V18: perturbed inputs must change the output.

    Dropping the last block shortens the evaluation; a solver that emits
    stored constants returns n_eval_blocks unchanged and fails.
    """
    import pandas as pd
    d = tmp_path / "data"
    d.mkdir()
    for name in ("workload.csv", "params.json",
                 "dim_channel.csv", "dim_region.csv"):
        (d / name).write_bytes((DATA / name).read_bytes())
    f = pd.read_csv(DATA / "fact.csv")
    last = f["block"].max()
    f[f["block"] < last].to_csv(d / "fact.csv", index=False)
    t = pd.read_csv(DATA / "truth.csv")
    t[t["block"] < last].to_csv(d / "truth.csv", index=False)
    out = tmp_path / "perturbed.json"
    subprocess.run([sys.executable, "/app/solve.py", str(d), str(out)],
                   check=True, capture_output=True)
    got = json.loads(out.read_text())
    assert got["database_report"]["n_eval_blocks"] == N_EVAL - 1


# -------------------------------------------------------------------- V19
def test_v20_no_dependence_on_sqlite_build(inputs):
    """V20: POW and LN must not be assumed present in the SQLite build.

    SQLite has shipped pow/ln since 3.35, but only under the compile-time
    option SQLITE_ENABLE_MATH_FUNCTIONS, which several common distributions
    omit. A pipeline that calls them without registering them passes wherever
    the option happens to be on and fails everywhere else, which is the worst
    kind of environment dependence: invisible to the author.

    This asserts the solver registers its own. Shadowing the names with
    raising stubs before the solver runs is not possible across a subprocess
    boundary, so the check is made structurally instead: the solution source
    must register both names, and the local build's behaviour is reported for
    the record rather than relied upon.
    """
    src = (ROOT / "solution" / "solve_full.py").read_text()
    for fn in ("POW", "LN"):
        assert f'create_function("{fn}"' in src, \
            f"{fn} is used in SQL but never registered as a UDF"

    con = sqlite3.connect(":memory:")
    try:
        opts = [r[0] for r in con.execute("PRAGMA compile_options")]
        has_math = any("ENABLE_MATH_FUNCTIONS" in o for o in opts)
        # Whether or not the build supplies them, registration must work.
        con.create_function("POW", 2, math.pow, deterministic=True)
        con.create_function("LN", 1, math.log, deterministic=True)
        assert close(con.execute("SELECT POW(2.0,3.0)").fetchone()[0], 8.0)
        assert close(con.execute("SELECT LN(8.0)").fetchone()[0], math.log(8.0))
        print(f"\n  [build supplies math functions: {has_math}]")
    finally:
        con.close()


def test_v19_sql_rederivation(sub, inputs):
    """V19: quantities re-derived in SQL against the shipped warehouse.

    The report describes a database, and the claims that are purely relational
    are checked by querying it rather than by trusting any Python. The window
    is the six blocks before the first evaluation block, and the equi-depth
    boundary rule places a value in bucket floor(cum_before * B / n), so no
    value is ever split across buckets and the bucket count actually used may
    fall short of the budget. The counts below come out of SQLite directly.
    """
    _, _, params, _, _ = inputs
    db = DATA / "warehouse.db"
    assert db.exists(), "warehouse.db missing from data/"
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    try:
        dr = sub["database_report"]

        n_rows, n_blocks = con.execute(
            "SELECT COUNT(*), COUNT(DISTINCT block) FROM fact").fetchone()
        assert dr["n_rows"] == n_rows
        assert dr["n_blocks"] == n_blocks

        (per_block,) = con.execute(
            "SELECT COUNT(*) FROM fact GROUP BY block LIMIT 1").fetchone()
        assert dr["rows_per_block"] == per_block

        (nq,) = con.execute("SELECT COUNT(*) FROM workload").fetchone()
        assert dr["n_queries"] == nq

        (ng1,) = con.execute(
            "SELECT COUNT(DISTINCT g1) FROM dim_channel").fetchone()
        (ng2,) = con.execute(
            "SELECT COUNT(DISTINCT g2) FROM dim_region").fetchone()
        assert dr["n_channel_groups"] == ng1
        assert dr["n_region_groups"] == ng2

        # mean_true_rows spans every block in truth, not only the evaluated
        # ones: it describes the workload against the warehouse, not the run.
        w = params["window_blocks"]
        (mtr,) = con.execute("SELECT AVG(true_rows) FROM truth").fetchone()
        assert close(dr["mean_true_rows"], mtr)
        (ntruth,) = con.execute("SELECT COUNT(*) FROM truth").fetchone()
        assert ntruth == n_blocks * nq, "truth must cover every block-query pair"

        # truth must agree with the fact table it claims to describe
        row = con.execute("""
            SELECT t.true_rows, (
                SELECT COUNT(*) FROM fact f
                JOIN dim_channel c ON c.k1 = f.k1
                JOIN dim_region  r ON r.k2 = f.k2
                WHERE f.block = t.block
                  AND f.a1 BETWEEN q.lo1 AND q.hi1
                  AND f.a2 BETWEEN q.lo2 AND q.hi2
                  AND f.a3 BETWEEN q.lo3 AND q.hi3
                  AND f.a4 BETWEEN q.lo4 AND q.hi4
                  AND c.g1 = q.g1 AND r.g2 = q.g2)
            FROM truth t JOIN workload q ON q.query_id = t.query_id
            WHERE t.block = ? AND t.query_id = ?""",
            (w, "Q000")).fetchone()
        assert row[0] == row[1], "truth.csv disagrees with the fact table"

        # buckets actually used by the reference synopsis, in SQL
        budget = 320
        B = budget // len(params["attributes"])
        used = 0
        for a in params["attributes"]:
            (u,) = con.execute(f"""
                WITH v AS (SELECT {a} AS val, COUNT(*) AS cnt
                           FROM fact WHERE block < ? GROUP BY {a}),
                     n AS (SELECT SUM(cnt) AS n FROM v),
                     c AS (SELECT val, cnt,
                                  COALESCE(SUM(cnt) OVER (ORDER BY val
                                      ROWS BETWEEN UNBOUNDED PRECEDING
                                               AND 1 PRECEDING), 0) AS before
                           FROM v)
                SELECT COUNT(DISTINCT (c.before * ?) / n.n)
                FROM c CROSS JOIN n""", (w, B)).fetchone()
            used += u
        assert dr["schema_stats"][str(budget)]["buckets_used"] == used, \
            "buckets_used disagrees with the equi-depth rule in SQL"
    finally:
        con.close()
