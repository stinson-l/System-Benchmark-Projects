-- ============================================================ drift report
DROP TABLE IF EXISTS trank;
DROP TABLE IF EXISTS rowstat;
DROP TABLE IF EXISTS epcum;
DROP TABLE IF EXISTS ksmat;
DROP TABLE IF EXISTS edges;
DROP TABLE IF EXISTS shares;

CREATE TEMP TABLE trank AS
SELECT a1, a2, a3, a4,
       ROW_NUMBER() OVER (ORDER BY COUNT(*) DESC, a1, a2, a3, a4) AS rnk
FROM fact WHERE block < :train_end GROUP BY a1, a2, a3, a4;

CREATE TEMP TABLE rowstat AS
SELECT f.block,
       MIN(f.block / :ep_len, :n_ep - 1) AS epoch,
       COALESCE(t.rnk, (SELECT COUNT(*) + 1 FROM trank)) AS stat
FROM fact f LEFT JOIN trank t
  ON t.a1=f.a1 AND t.a2=f.a2 AND t.a3=f.a3 AND t.a4=f.a4;
CREATE INDEX ix_rowstat ON rowstat(epoch, stat);

CREATE TEMP TABLE epcum AS
WITH c AS (SELECT epoch, stat, COUNT(*) n FROM rowstat GROUP BY epoch, stat)
SELECT epoch, stat,
       SUM(n) OVER (PARTITION BY epoch ORDER BY stat) * 1.0
       / SUM(n) OVER (PARTITION BY epoch) AS f
FROM c;

CREATE TEMP TABLE ksmat AS
WITH eps AS (SELECT DISTINCT epoch FROM rowstat),
sts AS (SELECT DISTINCT stat FROM rowstat),
grid AS (SELECT a.epoch e1, b.epoch e2, s.stat
         FROM eps a CROSS JOIN eps b CROSS JOIN sts s),
j AS (SELECT g.e1, g.e2, g.stat, c1.f f1, c2.f f2
      FROM grid g LEFT JOIN epcum c1 ON c1.epoch=g.e1 AND c1.stat=g.stat
                  LEFT JOIN epcum c2 ON c2.epoch=g.e2 AND c2.stat=g.stat),
ff AS (SELECT e1, e2, stat,
              COALESCE(MAX(f1) OVER (PARTITION BY e1,e2 ORDER BY stat), 0.0) F1,
              COALESCE(MAX(f2) OVER (PARTITION BY e1,e2 ORDER BY stat), 0.0) F2
       FROM j)
SELECT e1, e2, CASE WHEN e1=e2 THEN 0.0 ELSE MAX(ABS(F1-F2)) END AS d
FROM ff GROUP BY e1, e2;

-- bin edges: interior quantiles of the train-era statistic, linear interp
CREATE TEMP TABLE edges AS
WITH s AS (SELECT stat, ROW_NUMBER() OVER (ORDER BY stat) - 1 AS i
           FROM rowstat WHERE block < :train_end),
n AS (SELECT COUNT(*) n FROM s),
lv AS (SELECT nb.nbins, k.k, (k.k * 1.0 / nb.nbins) * (n.n - 1) AS h
       FROM binsets nb JOIN kseq k ON k.k < nb.nbins AND k.k >= 1 CROSS JOIN n)
SELECT lv.nbins, lv.k,
       lo.stat + (lv.h - CAST(lv.h AS INTEGER)) * (hi.stat - lo.stat) AS edge
FROM lv JOIN s lo ON lo.i = CAST(lv.h AS INTEGER)
        JOIN s hi ON hi.i = MIN(CAST(lv.h AS INTEGER) + 1,
                                (SELECT n - 1 FROM n));

CREATE TEMP TABLE shares AS
WITH assign AS (
    SELECT b.nbins, r.epoch,
           (SELECT COUNT(*) FROM edges e
            WHERE e.nbins = b.nbins AND e.edge <= r.stat) AS bin
    FROM rowstat r CROSS JOIN binsets b),
tot AS (SELECT nbins, epoch, COUNT(*) n FROM assign GROUP BY nbins, epoch),
cnt AS (SELECT nbins, epoch, bin, COUNT(*) c FROM assign GROUP BY nbins, epoch, bin)
SELECT t.nbins, t.epoch, k.k AS bin, COALESCE(c.c, 0) * 1.0 / t.n AS share
FROM tot t JOIN kseq k ON k.k < t.nbins
     LEFT JOIN cnt c ON c.nbins=t.nbins AND c.epoch=t.epoch AND c.bin=k.k;
