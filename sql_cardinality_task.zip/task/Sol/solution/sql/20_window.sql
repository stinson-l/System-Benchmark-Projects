DROP TABLE IF EXISTS win;
DROP TABLE IF EXISTS svd;
DROP TABLE IF EXISTS wv;
DROP TABLE IF EXISTS bkt;
DROP TABLE IF EXISTS mcvl;
DROP TABLE IF EXISTS rbkt;
DROP TABLE IF EXISTS gsel;
DROP TABLE IF EXISTS attr_sel;
DROP TABLE IF EXISTS s6;
DROP TABLE IF EXISTS ranked;
DROP TABLE IF EXISTS syn_bits;
DROP TABLE IF EXISTS joint;
DROP TABLE IF EXISTS jpair;

-- ---------------------------------------------------------------- row sets
CREATE TEMP TABLE win AS
SELECT f.row_id, f.a1, f.a2, f.a3, f.a4, c.g1, r.g2
FROM   fact f JOIN dim_channel c ON c.k1 = f.k1
              JOIN dim_region  r ON r.k2 = f.k2
WHERE  f.block >= :blk - :w AND f.block < :blk;

CREATE TEMP TABLE svd AS
SELECT f.row_id, f.a1, f.a2, f.a3, f.a4, c.g1, r.g2
FROM   fact f JOIN dim_channel c ON c.k1 = f.k1
              JOIN dim_region  r ON r.k2 = f.k2
WHERE  f.block = :blk;

-- --------------------------------------------------- attribute value counts
CREATE TEMP TABLE wv AS
WITH raw AS (
    SELECT 't' src, 'a1' attr, a1 val, COUNT(*) cnt FROM win GROUP BY a1
    UNION ALL SELECT 't','a2', a2, COUNT(*) FROM win GROUP BY a2
    UNION ALL SELECT 't','a3', a3, COUNT(*) FROM win GROUP BY a3
    UNION ALL SELECT 't','a4', a4, COUNT(*) FROM win GROUP BY a4
    UNION ALL SELECT 'o','a1', a1, COUNT(*) FROM svd GROUP BY a1
    UNION ALL SELECT 'o','a2', a2, COUNT(*) FROM svd GROUP BY a2
    UNION ALL SELECT 'o','a3', a3, COUNT(*) FROM svd GROUP BY a3
    UNION ALL SELECT 'o','a4', a4, COUNT(*) FROM svd GROUP BY a4),
idx AS (
    SELECT src, attr, val, cnt,
           ROW_NUMBER() OVER (PARTITION BY src, attr ORDER BY val) - 1 AS j
    FROM raw),
perm AS (
    SELECT i.attr, i.j,
           ROW_NUMBER() OVER (PARTITION BY i.attr
                              ORDER BY (i.j % p.piles), i.j) - 1 AS r
    FROM idx i JOIN piles p ON p.attr = i.attr
    WHERE i.src = 't')
SELECT src AS arm, attr, val, cnt FROM idx
UNION ALL
SELECT 'c', v.attr, v.val, c.cnt
FROM   perm pm
JOIN   idx v ON v.src = 't' AND v.attr = pm.attr AND v.j = pm.r
JOIN   idx c ON c.src = 't' AND c.attr = pm.attr AND c.j = pm.j;

-- --------------------------------------------------- equi-depth histograms
CREATE TEMP TABLE bkt AS
WITH tot AS (SELECT arm, attr, SUM(cnt) n FROM wv GROUP BY arm, attr),
cum AS (
    SELECT w.arm, w.attr, w.val, w.cnt,
           COALESCE(SUM(w.cnt) OVER (PARTITION BY w.arm, w.attr ORDER BY w.val
               ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING), 0) AS cb
    FROM wv w),
asg AS (
    SELECT c.arm, c.attr, wid.bw AS bw, c.val, c.cnt,
           (c.cb * wid.bw) / t.n AS bid
    FROM cum c JOIN tot t ON t.arm = c.arm AND t.attr = c.attr
    CROSS JOIN widths wid)
SELECT arm, attr, bw, bid,
       MIN(val) lo, MAX(val) hi, SUM(cnt) cnt, COUNT(*) dcnt
FROM   asg GROUP BY arm, attr, bw, bid;

-- ------------------------------------------------------------- MCV + tail
CREATE TEMP TABLE mcvl AS
WITH rk AS (
    SELECT w.arm, w.attr, w.val, w.cnt,
           ROW_NUMBER() OVER (PARTITION BY w.arm, w.attr
                              ORDER BY w.cnt DESC, w.val) rn
    FROM wv w)
SELECT rk.arm, rk.attr, wid.bw AS bw, rk.val, rk.cnt
FROM   rk CROSS JOIN widths wid
WHERE  rk.rn <= wid.bw - wid.bw / 4;

CREATE TEMP TABLE rbkt AS
WITH res AS (
    SELECT w.arm, w.attr, wid.bw AS bw, w.val, w.cnt
    FROM   wv w CROSS JOIN widths wid
    WHERE  NOT EXISTS (SELECT 1 FROM mcvl m
                       WHERE m.arm = w.arm AND m.attr = w.attr
                         AND m.bw = wid.bw AND m.val = w.val)),
tot AS (SELECT arm, attr, bw, SUM(cnt) n FROM res GROUP BY arm, attr, bw),
cum AS (
    SELECT r.arm, r.attr, r.bw, r.val, r.cnt,
           COALESCE(SUM(r.cnt) OVER (PARTITION BY r.arm, r.attr, r.bw
               ORDER BY r.val ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING),
               0) AS cb
    FROM res r),
asg AS (
    SELECT c.arm, c.attr, c.bw, c.val, c.cnt,
           (c.cb * (c.bw / 4)) / t.n AS bid
    FROM cum c JOIN tot t
      ON t.arm = c.arm AND t.attr = c.attr AND t.bw = c.bw
    WHERE t.n > 0)
SELECT arm, attr, bw, bid,
       MIN(val) lo, MAX(val) hi, SUM(cnt) cnt, COUNT(*) dcnt
FROM   asg GROUP BY arm, attr, bw, bid;

-- ------------------------------------------------------- group selectivity
-- Arms 't' and 'c' read group frequencies from the trailing window; arm 'o'
-- (oracle) reads them from the served block, so that every statistic the
-- oracle uses comes from the same rows its histograms were built on.
CREATE TEMP TABLE gsel AS
WITH src AS (
    SELECT 't' arm, g1, g2 FROM win
    UNION ALL SELECT 'c', g1, g2 FROM win
    UNION ALL SELECT 'o', g1, g2 FROM svd),
n AS (SELECT arm, COUNT(*) n FROM src GROUP BY arm),
g1c AS (SELECT arm, g1 g, COUNT(*) c FROM src GROUP BY arm, g1),
g2c AS (SELECT arm, g2 g, COUNT(*) c FROM src GROUP BY arm, g2)
SELECT n.arm, q.query_id, 'g1' pred, COALESCE(g1c.c, 0) * 1.0 / n.n AS s
FROM   workload q CROSS JOIN n
LEFT JOIN g1c ON g1c.g = q.g1 AND g1c.arm = n.arm
UNION ALL
SELECT n.arm, q.query_id, 'g2', COALESCE(g2c.c, 0) * 1.0 / n.n
FROM   workload q CROSS JOIN n
LEFT JOIN g2c ON g2c.g = q.g2 AND g2c.arm = n.arm;

-- --------------------------------------------------- attribute selectivity
CREATE TEMP TABLE attr_sel AS
WITH tot AS (SELECT arm, attr, SUM(cnt) n FROM wv GROUP BY arm, attr),
dep AS (
    SELECT b.arm, 'depth' fam, b.bw, ro.ro, q.query_id, b.attr,
           SUM(CASE ro.ro
               WHEN 'interp' THEN b.cnt * 1.0
                    * MAX(0, MIN(q.hi, b.hi) - MAX(q.lo, b.lo) + 1)
                    / (b.hi - b.lo + 1)
               WHEN 'mid' THEN CASE
                    WHEN b.lo + (b.hi - b.lo) / 2 BETWEEN q.lo AND q.hi
                    THEN b.cnt * 1.0 ELSE 0.0 END
               ELSE CASE
                    WHEN q.lo <= b.lo AND q.hi >= b.hi THEN b.cnt * 1.0
                    WHEN MIN(q.hi, b.hi) >= MAX(q.lo, b.lo) THEN b.cnt * 0.5
                    ELSE 0.0 END END) AS mass
    FROM bkt b JOIN qpred q ON q.attr = b.attr CROSS JOIN readouts ro
    GROUP BY b.arm, b.bw, ro.ro, q.query_id, b.attr),
mcv_part AS (
    SELECT m.arm, m.bw, q.query_id, m.attr, SUM(m.cnt) * 1.0 AS mass
    FROM mcvl m JOIN qpred q ON q.attr = m.attr
    WHERE m.val BETWEEN q.lo AND q.hi
    GROUP BY m.arm, m.bw, q.query_id, m.attr),
tail_part AS (
    SELECT b.arm, b.bw, ro.ro, q.query_id, b.attr,
           SUM(CASE ro.ro
               WHEN 'interp' THEN b.cnt * 1.0
                    * MAX(0, MIN(q.hi, b.hi) - MAX(q.lo, b.lo) + 1)
                    / (b.hi - b.lo + 1)
               WHEN 'mid' THEN CASE
                    WHEN b.lo + (b.hi - b.lo) / 2 BETWEEN q.lo AND q.hi
                    THEN b.cnt * 1.0 ELSE 0.0 END
               ELSE CASE
                    WHEN q.lo <= b.lo AND q.hi >= b.hi THEN b.cnt * 1.0
                    WHEN MIN(q.hi, b.hi) >= MAX(q.lo, b.lo) THEN b.cnt * 0.5
                    ELSE 0.0 END END) AS mass
    FROM rbkt b JOIN qpred q ON q.attr = b.attr CROSS JOIN readouts ro
    GROUP BY b.arm, b.bw, ro.ro, q.query_id, b.attr),
grid AS (
    SELECT DISTINCT arm, bw, ro, query_id, attr FROM dep
),
mix AS (
    SELECT g.arm, 'mcv' fam, g.bw, g.ro, g.query_id, g.attr,
           COALESCE(m.mass, 0.0) + COALESCE(t.mass, 0.0) AS mass
    FROM grid g
    LEFT JOIN mcv_part m ON m.arm = g.arm AND m.bw = g.bw
         AND m.query_id = g.query_id AND m.attr = g.attr
    LEFT JOIN tail_part t ON t.arm = g.arm AND t.bw = g.bw AND t.ro = g.ro
         AND t.query_id = g.query_id AND t.attr = g.attr)
SELECT d.arm, d.fam, d.bw, d.ro, d.query_id, d.attr AS pred,
       MIN(1.0, d.mass / t.n) AS s
FROM dep d JOIN tot t ON t.arm = d.arm AND t.attr = d.attr
UNION ALL
SELECT x.arm, x.fam, x.bw, x.ro, x.query_id, x.attr,
       MIN(1.0, x.mass / t.n)
FROM mix x JOIN tot t ON t.arm = x.arm AND t.attr = x.attr;

-- ------------------------------------------------- assemble six predicates
CREATE TEMP TABLE s6 AS
SELECT arm, fam, bw, ro, query_id, pred, s FROM attr_sel
UNION ALL
SELECT a.arm, a.fam, a.bw, a.ro, g.query_id, g.pred, g.s
FROM   (SELECT DISTINCT arm, fam, bw, ro FROM attr_sel) a
JOIN   gsel g ON g.arm = a.arm;

CREATE TEMP TABLE ranked AS
SELECT arm, fam, bw, ro, query_id, pred, s,
       CAST(:nb * s + 0.5 AS INTEGER) AS mrows,
       ROW_NUMBER() OVER (PARTITION BY arm, fam, bw, ro, query_id
                          ORDER BY CAST(:nb * s + 0.5 AS INTEGER) DESC, pred)
           AS rn
FROM   s6;
