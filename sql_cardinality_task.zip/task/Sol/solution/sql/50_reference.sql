DROP TABLE IF EXISTS refrows;
DROP TABLE IF EXISTS refwv;
DROP TABLE IF EXISTS refbkt;
DROP TABLE IF EXISTS refbits;
DROP TABLE IF EXISTS refsel;
DROP TABLE IF EXISTS refera;

CREATE TEMP TABLE refrows AS
SELECT f.row_id, f.a1, f.a2, f.a3, f.a4, c.g1, r.g2
FROM   fact f JOIN dim_channel c ON c.k1=f.k1 JOIN dim_region r ON r.k2=f.k2
WHERE  f.block < :train_end;

CREATE TEMP TABLE refwv AS
SELECT 'a1' attr, a1 val, COUNT(*) cnt FROM refrows GROUP BY a1
UNION ALL SELECT 'a2', a2, COUNT(*) FROM refrows GROUP BY a2
UNION ALL SELECT 'a3', a3, COUNT(*) FROM refrows GROUP BY a3
UNION ALL SELECT 'a4', a4, COUNT(*) FROM refrows GROUP BY a4;

CREATE TEMP TABLE refbkt AS
WITH tot AS (SELECT attr, SUM(cnt) n FROM refwv GROUP BY attr),
cum AS (SELECT w.attr, w.val, w.cnt,
               COALESCE(SUM(w.cnt) OVER (PARTITION BY w.attr ORDER BY w.val
                   ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING), 0) cb
        FROM refwv w),
asg AS (SELECT c.attr, wid.bw bw, c.val, c.cnt, (c.cb * wid.bw) / t.n bid
        FROM cum c JOIN tot t ON t.attr=c.attr CROSS JOIN widths wid)
SELECT attr, bw, bid, MIN(val) lo, MAX(val) hi, SUM(cnt) cnt, COUNT(*) dcnt
FROM asg GROUP BY attr, bw, bid;

CREATE TEMP TABLE refbits AS
WITH cb AS (SELECT b AS cbits FROM bitlen WHERE v = :nref),
gb AS (SELECT (SELECT COUNT(DISTINCT g1) FROM dim_channel)
            + (SELECT COUNT(DISTINCT g2) FROM dim_region) AS ng)
SELECT b.bw, SUM(2*a.vbits + 2*cb.cbits) + (SELECT ng FROM gb)*(SELECT cbits FROM cb)
       AS bits, COUNT(*) AS used
FROM refbkt b JOIN attrbits a ON a.attr=b.attr CROSS JOIN cb
GROUP BY b.bw;

CREATE TEMP TABLE refsel AS
WITH tot AS (SELECT attr, SUM(cnt) n FROM refwv GROUP BY attr),
nall AS (SELECT COUNT(*) n FROM refrows),
g1c AS (SELECT g1 g, COUNT(*) c FROM refrows GROUP BY g1),
g2c AS (SELECT g2 g, COUNT(*) c FROM refrows GROUP BY g2),
am AS (SELECT b.bw, q.query_id, b.attr,
              SUM(b.cnt * 1.0 * MAX(0, MIN(q.hi,b.hi) - MAX(q.lo,b.lo) + 1)
                  / (b.hi-b.lo+1)) mass
       FROM refbkt b JOIN qpred q ON q.attr=b.attr
       GROUP BY b.bw, q.query_id, b.attr),
sa AS (SELECT am.bw, am.query_id, am.attr, MIN(1.0, am.mass/t.n) s
       FROM am JOIN tot t ON t.attr=am.attr)
SELECT s.bw, s.query_id,
       MAX(CASE WHEN attr='a1' THEN s END) s1,
       MAX(CASE WHEN attr='a2' THEN s END) s2,
       MAX(CASE WHEN attr='a3' THEN s END) s3,
       MAX(CASE WHEN attr='a4' THEN s END) s4,
       (SELECT COALESCE(g1c.c,0)*1.0/(SELECT n FROM nall) FROM workload w
        LEFT JOIN g1c ON g1c.g=w.g1 WHERE w.query_id=s.query_id) sg1,
       (SELECT COALESCE(g2c.c,0)*1.0/(SELECT n FROM nall) FROM workload w
        LEFT JOIN g2c ON g2c.g=w.g2 WHERE w.query_id=s.query_id) sg2
FROM sa s GROUP BY s.bw, s.query_id;

CREATE TEMP TABLE refera AS
SELECT r.bw,
       CASE WHEN t.block < :train_end THEN 'train' ELSE 'final' END AS era,
       t.query_id, t.block,
       MAX(1, MIN(:nb, CAST(:nb * r.s1*r.s2*r.s3*r.s4*r.sg1*r.sg2 + 0.5
                            AS INTEGER))) AS ef,
       MAX(1, MIN(:nb, CAST(:nb * r.s1*r.s2 + 0.5 AS INTEGER))) AS ea,
       MAX(1, MIN(:nb, CAST(:nb * r.s3*r.s4 + 0.5 AS INTEGER))) AS eb,
       MAX(1, MIN(:nb, CAST(:nb * r.sg1*r.sg2 + 0.5 AS INTEGER))) AS ec,
       MAX(1, t.true_rows) AS tt,
       CASE WHEN t.true_path_a <= t.true_path_b
                 AND t.true_path_a <= t.true_path_c THEN 'A'
            WHEN t.true_path_b <= t.true_path_c THEN 'B' ELSE 'C' END AS tp
FROM refsel r JOIN truth t ON t.query_id = r.query_id
WHERE t.block < :train_end OR t.block >= :final_start;
