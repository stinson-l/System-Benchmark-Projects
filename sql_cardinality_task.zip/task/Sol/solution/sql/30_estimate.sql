DROP TABLE IF EXISTS sw;
DROP TABLE IF EXISTS rw;
DROP TABLE IF EXISTS synb;
DROP TABLE IF EXISTS gridpos;
DROP TABLE IF EXISTS jpair;
DROP TABLE IF EXISTS jcell;
DROP TABLE IF EXISTS bfrac;
DROP TABLE IF EXISTS casc;
DROP TABLE IF EXISTS smp;
DROP TABLE IF EXISTS est;
DROP TABLE IF EXISTS blockout;

-- ------------------------------------------------------------ wide pivots
CREATE TEMP TABLE sw AS
SELECT arm, fam, bw, ro, query_id,
       MAX(CASE WHEN pred='a1' THEN s END) s1,
       MAX(CASE WHEN pred='a2' THEN s END) s2,
       MAX(CASE WHEN pred='a3' THEN s END) s3,
       MAX(CASE WHEN pred='a4' THEN s END) s4,
       MAX(CASE WHEN pred='g1' THEN s END) sg1,
       MAX(CASE WHEN pred='g2' THEN s END) sg2,
       MAX(CASE WHEN pred='a1' THEN mrows END) m1,
       MAX(CASE WHEN pred='a2' THEN mrows END) m2,
       MAX(CASE WHEN pred='a3' THEN mrows END) m3,
       MAX(CASE WHEN pred='a4' THEN mrows END) m4,
       MAX(CASE WHEN pred='g1' THEN mrows END) mg1,
       MAX(CASE WHEN pred='g2' THEN mrows END) mg2
FROM ranked GROUP BY arm, fam, bw, ro, query_id;

CREATE TEMP TABLE rw AS
SELECT arm, fam, bw, ro, query_id,
       MAX(CASE WHEN rn=1 THEN s END) r1,
       MAX(CASE WHEN rn=2 THEN s END) r2,
       MAX(CASE WHEN rn=3 THEN s END) r3,
       MAX(CASE WHEN rn=4 THEN s END) r4,
       MAX(CASE WHEN rn=5 THEN s END) r5,
       MAX(CASE WHEN rn=6 THEN s END) r6,
       MAX(CASE WHEN rn=6 THEN s END) rmin
FROM ranked GROUP BY arm, fam, bw, ro, query_id;

-- --------------------------------------------------------- synopsis budget
CREATE TEMP TABLE synb AS
WITH cb(arm, cbits) AS (
        SELECT 't', (SELECT b FROM bitlen WHERE v = :nw)
  UNION SELECT 'c', (SELECT b FROM bitlen WHERE v = :nw)
  UNION SELECT 'o', (SELECT b FROM bitlen WHERE v = :nb)),
gb AS (SELECT (SELECT COUNT(DISTINCT g1) FROM dim_channel)
            + (SELECT COUNT(DISTINCT g2) FROM dim_region) AS ng),
dep AS (SELECT b.arm, b.bw, SUM(2*a.vbits + 2*cb.cbits) bits, COUNT(*) used
        FROM bkt b JOIN attrbits a ON a.attr=b.attr JOIN cb ON cb.arm=b.arm
        GROUP BY b.arm, b.bw),
mv AS (SELECT m.arm, m.bw, SUM(a.vbits + cb.cbits) bits, COUNT(*) used
       FROM mcvl m JOIN attrbits a ON a.attr=m.attr JOIN cb ON cb.arm=m.arm
       GROUP BY m.arm, m.bw),
rb AS (SELECT b.arm, b.bw, SUM(2*a.vbits + 2*cb.cbits) bits, COUNT(*) used
       FROM rbkt b JOIN attrbits a ON a.attr=b.attr JOIN cb ON cb.arm=b.arm
       GROUP BY b.arm, b.bw)
SELECT dep.arm, 'depth' fam, dep.bw, dep.bits + gb.ng*cb.cbits AS bits, dep.used
FROM dep CROSS JOIN gb JOIN cb ON cb.arm=dep.arm
UNION ALL
SELECT mv.arm, 'mcv', mv.bw,
       mv.bits + COALESCE(rb.bits,0) + gb.ng*cb.cbits,
       mv.used + COALESCE(rb.used,0)
FROM mv CROSS JOIN gb JOIN cb ON cb.arm=mv.arm
     LEFT JOIN rb ON rb.arm=mv.arm AND rb.bw=mv.bw;

-- ----------------------------------------------------- joint pair (cascade)
CREATE TEMP TABLE gridpos AS
SELECT w.row_id, 'a1' attr, b.bid FROM win w JOIN bkt b
  ON b.arm='t' AND b.attr='a1' AND b.bw=20 AND w.a1 BETWEEN b.lo AND b.hi
UNION ALL SELECT w.row_id,'a2',b.bid FROM win w JOIN bkt b
  ON b.arm='t' AND b.attr='a2' AND b.bw=20 AND w.a2 BETWEEN b.lo AND b.hi
UNION ALL SELECT w.row_id,'a3',b.bid FROM win w JOIN bkt b
  ON b.arm='t' AND b.attr='a3' AND b.bw=20 AND w.a3 BETWEEN b.lo AND b.hi
UNION ALL SELECT w.row_id,'a4',b.bid FROM win w JOIN bkt b
  ON b.arm='t' AND b.attr='a4' AND b.bw=20 AND w.a4 BETWEEN b.lo AND b.hi;

CREATE TEMP TABLE jpair AS
WITH pairs(x,y) AS (VALUES ('a1','a2'),('a1','a3'),('a1','a4'),
                           ('a2','a3'),('a2','a4'),('a3','a4')),
cell AS (SELECT p.x, p.y, gx.bid bx, gy.bid byy, COUNT(*) nxy
         FROM pairs p
         JOIN gridpos gx ON gx.attr = p.x
         JOIN gridpos gy ON gy.attr = p.y AND gy.row_id = gx.row_id
         GROUP BY p.x, p.y, gx.bid, gy.bid),
marg AS (SELECT attr, bid, COUNT(*) n FROM gridpos GROUP BY attr, bid),
tot AS (SELECT COUNT(*) n FROM win),
dep AS (SELECT c.x, c.y, SUM(ABS(t.n*c.nxy - mx.n*my.n)) d
        FROM cell c JOIN marg mx ON mx.attr=c.x AND mx.bid=c.bx
                    JOIN marg my ON my.attr=c.y AND my.bid=c.byy
                    CROSS JOIN tot t
        GROUP BY c.x, c.y)
SELECT x, y FROM dep ORDER BY d DESC, x, y LIMIT 1;

CREATE TEMP TABLE jcell AS
SELECT gx.bid bx, gy.bid byy, COUNT(*) nxy
FROM jpair p
JOIN gridpos gx ON gx.attr = p.x
JOIN gridpos gy ON gy.attr = p.y AND gy.row_id = gx.row_id
GROUP BY gx.bid, gy.bid;

CREATE TEMP TABLE bfrac AS
SELECT b.attr, b.bid, ro.ro, q.query_id,
       (CASE ro.ro
          WHEN 'interp' THEN 1.0
               * MAX(0, MIN(q.hi,b.hi) - MAX(q.lo,b.lo) + 1) / (b.hi-b.lo+1)
          WHEN 'mid' THEN CASE WHEN b.lo + (b.hi-b.lo)/2 BETWEEN q.lo AND q.hi
                               THEN 1.0 ELSE 0.0 END
          ELSE CASE WHEN q.lo <= b.lo AND q.hi >= b.hi THEN 1.0
                    WHEN MIN(q.hi,b.hi) >= MAX(q.lo,b.lo) THEN 0.5
                    ELSE 0.0 END END) AS f
FROM bkt b JOIN qpred q ON q.attr = b.attr CROSS JOIN readouts ro
WHERE b.arm = 't' AND b.bw = 20;

CREATE TEMP TABLE casc AS
WITH sp AS (
    SELECT p.x, p.y, f1.ro, f1.query_id,
           SUM(c.nxy * f1.f * f2.f) / (SELECT COUNT(*) FROM win) AS spair
    FROM jpair p JOIN jcell c
    JOIN bfrac f1 ON f1.attr=p.x AND f1.bid=c.bx
    JOIN bfrac f2 ON f2.attr=p.y AND f2.bid=c.byy
         AND f2.ro=f1.ro AND f2.query_id=f1.query_id
    GROUP BY p.x, p.y, f1.ro, f1.query_id)
SELECT sp.ro, sp.query_id,
       MIN(1.0, sp.spair) * (CASE sp.x || sp.y
            WHEN 'a1a2' THEN sw.s3*sw.s4  WHEN 'a1a3' THEN sw.s2*sw.s4
            WHEN 'a1a4' THEN sw.s2*sw.s3  WHEN 'a2a3' THEN sw.s1*sw.s4
            WHEN 'a2a4' THEN sw.s1*sw.s3  ELSE sw.s1*sw.s2 END)
         * sw.sg1 * sw.sg2 AS sfull,
       CASE WHEN sp.x='a1' AND sp.y='a2' THEN MIN(1.0, sp.spair)
            ELSE sw.s1*sw.s2 END AS sa,
       CASE WHEN sp.x='a3' AND sp.y='a4' THEN MIN(1.0, sp.spair)
            ELSE sw.s3*sw.s4 END AS sb,
       sw.sg1*sw.sg2 AS scc,
       synb.bits + (SELECT COUNT(*) FROM jcell)
            * (2*(SELECT b FROM bitlen WHERE v=19)
               + (SELECT b FROM bitlen WHERE v=:nw)) AS synbits,
       synb.used + (SELECT COUNT(*) FROM jcell) AS used
FROM sp
JOIN sw ON sw.arm='t' AND sw.fam='depth' AND sw.bw=80
        AND sw.ro=sp.ro AND sw.query_id=sp.query_id
JOIN synb ON synb.arm='t' AND synb.fam='depth' AND synb.bw=80;

-- ------------------------------------------------------------ sample arm
CREATE TEMP TABLE smp AS
SELECT row_id, a1, a2, a3, a4, g1, g2 FROM (
  SELECT *, ROW_NUMBER() OVER (ORDER BY row_id) - 1 AS j FROM win)
WHERE j % (:nw / :ns) = 0 AND j / (:nw / :ns) < :ns;

-- ------------------------------------------------------------- estimates
CREATE TEMP TABLE est AS
SELECT sw.arm, sw.fam || '_' || sc.scheme || '_' || (sw.bw*4) AS cfg,
       sw.ro, sw.query_id,
       (CASE sc.scheme
          WHEN 'avi' THEN sw.s1*sw.s2*sw.s3*sw.s4*sw.sg1*sw.sg2
          WHEN 'ebo' THEN rw.r1*POW(rw.r2,0.5)*POW(rw.r3,0.25)*POW(rw.r4,0.125)*POW(rw.r5,0.0625)*POW(rw.r6,0.03125)
          WHEN 'minsel' THEN rw.rmin
          ELSE CASE WHEN COALESCE(tg.fired,0)=1
                 THEN rw.r1*POW(rw.r2,0.5)*POW(rw.r3,0.25)*POW(rw.r4,0.125)*POW(rw.r5,0.0625)*POW(rw.r6,0.03125)
                 ELSE sw.s1*sw.s2*sw.s3*sw.s4*sw.sg1*sw.sg2 END END) AS sfull,
       (CASE WHEN sc.scheme='avi'
                  OR (sc.scheme='mix' AND COALESCE(tg.fired,0)=0)
               THEN sw.s1*sw.s2
             WHEN sc.scheme='minsel'
               THEN CASE WHEN sw.m1<=sw.m2 THEN sw.s1 ELSE sw.s2 END
             ELSE CASE WHEN sw.m1>=sw.m2 THEN sw.s1*POW(sw.s2,0.5)
                       ELSE sw.s2*POW(sw.s1,0.5) END END) AS sa,
       (CASE WHEN sc.scheme='avi'
                  OR (sc.scheme='mix' AND COALESCE(tg.fired,0)=0)
               THEN sw.s3*sw.s4
             WHEN sc.scheme='minsel'
               THEN CASE WHEN sw.m3<=sw.m4 THEN sw.s3 ELSE sw.s4 END
             ELSE CASE WHEN sw.m3>=sw.m4 THEN sw.s3*POW(sw.s4,0.5)
                       ELSE sw.s4*POW(sw.s3,0.5) END END) AS sb,
       (CASE WHEN sc.scheme='avi'
                  OR (sc.scheme='mix' AND COALESCE(tg.fired,0)=0)
               THEN sw.sg1*sw.sg2
             WHEN sc.scheme='minsel'
               THEN CASE WHEN sw.mg1<=sw.mg2 THEN sw.sg1 ELSE sw.sg2 END
             ELSE CASE WHEN sw.mg1>=sw.mg2 THEN sw.sg1*POW(sw.sg2,0.5)
                       ELSE sw.sg2*POW(sw.sg1,0.5) END END) AS scc,
       synb.bits AS synbits, synb.used AS used
FROM sw JOIN rw ON rw.arm=sw.arm AND rw.fam=sw.fam AND rw.bw=sw.bw
                AND rw.ro=sw.ro AND rw.query_id=sw.query_id
CROSS JOIN schemes sc
JOIN synb ON synb.arm=sw.arm AND synb.fam=sw.fam AND synb.bw=sw.bw
LEFT JOIN trig tg ON tg.arm=sw.arm
     AND tg.cfg = sw.fam || '_' || sc.scheme || '_' || (sw.bw*4)
WHERE sw.arm IN ('t','c')

UNION ALL
SELECT 't', 'oracle', sw.ro, sw.query_id,
       sw.s1*sw.s2*sw.s3*sw.s4*sw.sg1*sw.sg2,
       sw.s1*sw.s2, sw.s3*sw.s4, sw.sg1*sw.sg2, synb.bits, synb.used
FROM sw JOIN synb ON synb.arm='o' AND synb.fam='depth' AND synb.bw=80
WHERE sw.arm='o' AND sw.fam='depth' AND sw.bw=80

UNION ALL
SELECT 't', 'uniform', ro.ro, q.query_id,
       (CASE WHEN q.lo1=q.hi1 THEN :se ELSE :sr END)
       * (CASE WHEN q.lo2=q.hi2 THEN :se ELSE :sr END)
       * (CASE WHEN q.lo3=q.hi3 THEN :se ELSE :sr END)
       * (CASE WHEN q.lo4=q.hi4 THEN :se ELSE :sr END)
       * cat.s1 * cat.s2,
       (CASE WHEN q.lo1=q.hi1 THEN :se ELSE :sr END)
       * (CASE WHEN q.lo2=q.hi2 THEN :se ELSE :sr END),
       (CASE WHEN q.lo3=q.hi3 THEN :se ELSE :sr END)
       * (CASE WHEN q.lo4=q.hi4 THEN :se ELSE :sr END),
       cat.s1 * cat.s2, 0, 0
FROM workload q CROSS JOIN readouts ro
CROSS JOIN (SELECT 1.0/(SELECT COUNT(DISTINCT g1) FROM dim_channel) s1,
                   1.0/(SELECT COUNT(DISTINCT g2) FROM dim_region) s2) cat

UNION ALL
SELECT 't', 'sample', ro.ro, q.query_id,
       (SELECT COUNT(*) FROM smp s WHERE s.a1 BETWEEN q.lo1 AND q.hi1
          AND s.a2 BETWEEN q.lo2 AND q.hi2 AND s.a3 BETWEEN q.lo3 AND q.hi3
          AND s.a4 BETWEEN q.lo4 AND q.hi4 AND s.g1=q.g1 AND s.g2=q.g2)
         * 1.0 / :ns,
       (SELECT COUNT(*) FROM smp s WHERE s.a1 BETWEEN q.lo1 AND q.hi1
          AND s.a2 BETWEEN q.lo2 AND q.hi2) * 1.0 / :ns,
       (SELECT COUNT(*) FROM smp s WHERE s.a3 BETWEEN q.lo3 AND q.hi3
          AND s.a4 BETWEEN q.lo4 AND q.hi4) * 1.0 / :ns,
       (SELECT COUNT(*) FROM smp s WHERE s.g1=q.g1 AND s.g2=q.g2) * 1.0 / :ns,
       :ns * ((SELECT SUM(vbits) FROM attrbits)
              + (SELECT SUM(vbits) FROM grpbits)),
       :ns
FROM workload q CROSS JOIN readouts ro

UNION ALL
SELECT 't', 'cascade', ro, query_id, sfull, sa, sb, scc, synbits, used
FROM casc;

-- -------------------------------------------------- per-block aggregation
CREATE TEMP TABLE blockout AS
WITH e AS (
  SELECT e.arm, e.cfg, e.ro, e.query_id, e.synbits, e.used,
         MAX(1, MIN(:nb, CAST(:nb * e.sfull + 0.5 AS INTEGER))) AS ef,
         MAX(1, MIN(:nb, CAST(:nb * e.sa + 0.5 AS INTEGER))) AS ea,
         MAX(1, MIN(:nb, CAST(:nb * e.sb + 0.5 AS INTEGER))) AS eb,
         MAX(1, MIN(:nb, CAST(:nb * e.scc + 0.5 AS INTEGER))) AS ec,
         MAX(1, t.true_rows) AS tt,
         CASE WHEN t.true_path_a <= t.true_path_b
                   AND t.true_path_a <= t.true_path_c THEN 'A'
              WHEN t.true_path_b <= t.true_path_c THEN 'B' ELSE 'C' END AS tp
  FROM est e JOIN truth t ON t.block = :blk AND t.query_id = e.query_id)
SELECT arm, cfg, ro,
       COUNT(*) nq,
       SUM(MAX(e.ef, e.tt) * 1.0 / MIN(e.ef, e.tt)) sum_q,
       SUM(CASE WHEN (CASE WHEN e.ea<=e.eb AND e.ea<=e.ec THEN 'A'
                           WHEN e.eb<=e.ec THEN 'B' ELSE 'C' END) = e.tp
                THEN 1 ELSE 0 END) agree,
       SUM(COALESCE(bl.b, 0)) sum_bits,
       SUM(CASE WHEN e.ef < e.tt THEN 1 ELSE 0 END) under,
       SUM(CASE WHEN e.ef < 1 OR e.ef > :nb
                     OR e.ef <> CAST(e.ef AS INTEGER) THEN 1 ELSE 0 END) invalid,
       MAX(e.synbits) synbits, MAX(e.used) used
FROM e LEFT JOIN bitlen bl ON bl.v = e.ef
GROUP BY e.arm, e.cfg, e.ro;
