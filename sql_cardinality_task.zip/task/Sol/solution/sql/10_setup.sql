-- Constant relations the rest of the pipeline joins against.  Nothing here
-- depends on the data; everything here is fixed by SPEC.md and params.json.

CREATE TABLE widths(bw INTEGER PRIMARY KEY);
INSERT INTO widths VALUES (20),(40),(80);

CREATE TABLE readouts(ro TEXT PRIMARY KEY);
INSERT INTO readouts VALUES ('interp'),('mid'),('half');

CREATE TABLE schemes(scheme TEXT PRIMARY KEY);
INSERT INTO schemes VALUES ('avi'),('ebo'),('minsel'),('mix');

CREATE TABLE binsets(nbins INTEGER PRIMARY KEY);
INSERT INTO binsets VALUES (6),(10);

CREATE TABLE kseq(k INTEGER PRIMARY KEY);
WITH RECURSIVE q(k) AS (SELECT 0 UNION ALL SELECT k+1 FROM q WHERE k < 9)
INSERT INTO kseq SELECT k FROM q;

CREATE TABLE piles(attr TEXT PRIMARY KEY, piles INTEGER);
CREATE TABLE attrbits(attr TEXT PRIMARY KEY, vbits INTEGER);
CREATE TABLE grpbits(grp TEXT PRIMARY KEY, vbits INTEGER);
CREATE TABLE trig(arm TEXT, cfg TEXT, fired INTEGER);

-- The predicate box of every query, one row per attribute predicate.
CREATE TABLE qpred AS
    SELECT query_id, 'a1' attr, lo1 lo, hi1 hi FROM workload
    UNION ALL SELECT query_id, 'a2', lo2, hi2 FROM workload
    UNION ALL SELECT query_id, 'a3', lo3, hi3 FROM workload
    UNION ALL SELECT query_id, 'a4', lo4, hi4 FROM workload;
CREATE INDEX ix_qpred ON qpred(attr);

-- Integer bit lengths, by repeated halving.  Used for every code width in
-- the cost model, so that no reported cost depends on a logarithm.
CREATE TABLE bitlen AS
WITH RECURSIVE nums(v) AS (
        SELECT 0 UNION ALL SELECT v+1 FROM nums WHERE v < 30000),
walk(v, x, b) AS (
        SELECT v, v, 0 FROM nums
        UNION ALL SELECT v, x/2, b+1 FROM walk WHERE x > 0)
SELECT v, MAX(b) AS b FROM walk GROUP BY v;
CREATE UNIQUE INDEX ix_bitlen ON bitlen(v);

CREATE INDEX ix_fact_blk ON fact(block);
CREATE INDEX ix_truth_blk ON truth(block, query_id);
