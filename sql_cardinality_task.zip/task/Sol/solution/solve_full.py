"""
Full-scope reference solution.

    python solve_full.py <data_dir> <out_path>

Reproduces the complete study on the frozen inputs: the database report and
its three reference synopses, the drift report, three selectivity-readout
regimes, 28 estimators per regime, 24 control arms per regime, and the paired
significance panels.

Where the work happens
----------------------
Every quantity is computed by SQL against a SQLite database built from the
frozen CSVs.  This file loads the inputs, walks the 30 evaluation blocks in
order, executes the scripts in ``sql/`` against each, and serialises what the
database returns.  It contains no selectivity estimation, no bucketing and no
cost accounting of its own.  The two exceptions are named in SPEC.md section
13 and are library calls, not reimplementations: ``scipy.stats.ttest_rel`` and
the normal tail used by the two-method Nemenyi reduction.

Determinism
-----------
  * bucket boundaries   assigned by ``(cumulative_count * B) / n`` in integer
                        division, so a value never straddles two buckets and
                        no boundary depends on a floating-point comparison.
  * merge of ties       the MCV list orders by count descending then value
                        ascending; predicates order by estimated matching
                        rows descending then predicate name; paths break ties
                        on the path letter.  Every one of those is an integer
                        or string comparison.
  * code widths         bit lengths come from the ``bitlen`` relation, built
                        by repeated integer halving rather than a logarithm.
  * control arm         a deal-into-P-piles permutation of each attribute's
                        window count vector.  No pseudo-random generator is
                        consumed anywhere in the study, so there is no seed to
                        agree on and no draw order to get wrong.

The trigger stream is the fragile part.  It is defined by the ``interp``
regime and by the block before the one being served, so a solver that
recomputes it inside the regime loop, or that lets a regime feed back into it,
reproduces every ``avi``, ``ebo`` and ``minsel`` number and gets every ``mix``
number wrong.  The cross-variant invariants in the verifier exist for that.

The standalone ``crosscheck/solve_narrow_crosscheck.py`` re-derives 32 of
these quantities from the specification text alone, in NumPy, with no SQL and
no shared code, and agrees with this file to within 1e-12 relative.
"""

from __future__ import annotations

import json
import math
import sqlite3
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats as st

warnings.filterwarnings("ignore")

SQL = Path(__file__).resolve().parent / "sql"
VARIANTS = ("interp", "mid", "half")
FAMILIES = ("depth", "mcv")
SCHEMES = ("avi", "ebo", "minsel", "mix")
SIG_METRICS = (("mean_q_error", -1), ("p95_q_error", -1),
               ("bits_per_query", -1), ("plan_agreement_pct", 1))
STRUCTURES = ("cascade", "oracle", "sample", "uniform")


# --------------------------------------------------------------- plumbing
def register_math(con: sqlite3.Connection) -> None:
    """Provide POW and LN regardless of how SQLite was compiled.

    SQLite has shipped pow/ln since 3.35, but only when built with
    SQLITE_ENABLE_MATH_FUNCTIONS, which is a compile-time option and is absent
    from a number of common distributions. Relying on the build would make the
    pipeline pass or fail depending on the container it lands in, so both are
    registered unconditionally as application-defined functions -- which take
    precedence over the built-ins where those exist.

    Both delegate to libm through the math module, the same library the
    built-ins call, so registering them does not perturb any reported value.
    """
    con.create_function("POW", 2, math.pow, deterministic=True)
    con.create_function("LN", 1, math.log, deterministic=True)


def load(data: Path) -> tuple[sqlite3.Connection, dict]:
    params = json.loads((data / "params.json").read_text())
    con = sqlite3.connect(":memory:")
    register_math(con)
    for name in ("fact", "dim_channel", "dim_region", "workload", "truth"):
        pd.read_csv(data / f"{name}.csv").to_sql(name, con, index=False)
    con.executescript((SQL / "10_setup.sql").read_text())

    def bl(v: int) -> int:
        # SPEC section 3: bit_length(0) == 0.  No clamp -- a single-group
        # dimension would legitimately cost zero bits per group code, and
        # silently forcing it to one would diverge from the specification.
        return int(v).bit_length()

    con.executemany("INSERT INTO piles VALUES (?,?)",
                    sorted(params["control_piles"].items()))
    con.executemany("INSERT INTO attrbits VALUES (?,?)",
                    [(a, bl(params["domain_size"][a] - 1))
                     for a in params["attributes"]])
    ng1 = con.execute("SELECT COUNT(DISTINCT g1) FROM dim_channel").fetchone()[0]
    ng2 = con.execute("SELECT COUNT(DISTINCT g2) FROM dim_region").fetchone()[0]
    con.executemany("INSERT INTO grpbits VALUES (?,?)",
                    [("g1", bl(ng1 - 1)), ("g2", bl(ng2 - 1))])
    con.commit()
    return con, params


def bind(text: str, subs: dict) -> str:
    for k in sorted(subs, key=len, reverse=True):
        text = text.replace(k, str(subs[k]))
    return text


# ----------------------------------------------------------- walk-forward
def walk(con, params, subs, blocks) -> pd.DataFrame:
    win_sql = (SQL / "20_window.sql").read_text()
    est_sql = (SQL / "30_estimate.sql").read_text()
    gate = params["gate_multiple"] * params["target_q_error"]
    out = []
    for step, blk in enumerate(blocks):
        s = dict(subs, **{":blk": blk})
        con.executescript(bind(win_sql, s))
        con.executescript(bind(est_sql, s))
        fired = dict(con.execute(
            "SELECT arm || '/' || cfg, fired FROM trig").fetchall())
        for r in con.execute(
                "SELECT arm,cfg,ro,nq,sum_q,agree,sum_bits,under,invalid,"
                "synbits,used FROM blockout").fetchall():
            out.append((blk, step) + tuple(r)
                       + (fired.get(f"{r[0]}/{r[1]}", 0),))
        con.execute("DELETE FROM trig")
        con.execute(
            "INSERT INTO trig SELECT arm, cfg,"
            " CASE WHEN sum_q*1.0/nq > ? THEN 1 ELSE 0 END"
            " FROM blockout WHERE ro='interp'", (gate,))
        con.commit()
    return pd.DataFrame(out, columns=[
        "blk", "step", "arm", "cfg", "ro", "nq", "sum_q", "agree", "sum_bits",
        "under", "invalid", "synbits", "used", "fired"])


# --------------------------------------------------------------- metrics
def metrics(g: pd.DataFrame, target: float) -> dict:
    r = (g["sum_q"] / g["nq"]).to_numpy()
    d = ((g["synbits"] + g["sum_bits"]) / g["nq"]).to_numpy()
    a = (g["agree"] / g["nq"]).to_numpy()
    return {
        "mean_q_error": float(r.mean()),
        "p95_q_error": float(np.percentile(r, 95)),
        "max_q_error": float(r.max()),
        "pct_within_target": float((r <= target).mean()),
        "excess_ratio": float(r.mean() / target),
        "bits_per_query": float(d.mean()),
        "plan_agreement_pct": float(a.mean() * 100.0),
    }


def significance(strat: dict, ctrl: dict) -> dict:
    out = {}
    for fam in FAMILIES:
        names = sorted(n for n in ctrl if n.startswith(fam + "_"))
        panel = {}
        for metric, sign in SIG_METRICS:
            t = np.array([strat[n][metric] for n in names]) * sign
            c = np.array([ctrl[n][metric] for n in names]) * sign
            tr = np.where(t > c, 2.0, np.where(t < c, 1.0, 1.5))
            cr = 3.0 - tr
            q = abs(tr.mean() - cr.mean()) * np.sqrt(len(names))
            panel[metric] = {
                "control_rank": float(cr.mean()),
                "treatment_rank": float(tr.mean()),
                "t_test_p": float(st.ttest_rel(t, c,
                                               alternative="greater").pvalue),
                "nemenyi_p": float(min(2.0 * st.norm.sf(q / np.sqrt(2.0)), 1.0)),
            }
        out[fam] = panel
    return out


# ------------------------------------------------------------ the reports
def database_report(con, params, subs, n_eval) -> dict:
    con.executescript(bind((SQL / "50_reference.sql").read_text(), subs))
    era = pd.read_sql("SELECT * FROM refera", con)
    bits = pd.read_sql("SELECT * FROM refbits", con).set_index("bw")
    nb = subs[":nb"]

    ren = {}
    for tag, lo, hi in (("train", 0, subs[":train_end"] - 1),
                        ("final", subs[":final_start"], subs[":n_blocks"] - 1)):
        ren[tag] = con.execute(f"""
            WITH p AS (SELECT COUNT(*)*1.0 /
                          (SELECT COUNT(*) FROM fact WHERE block BETWEEN {lo} AND {hi})
                       AS pp FROM fact WHERE block BETWEEN {lo} AND {hi}
                       GROUP BY a1,a2,a3,a4)
            SELECT CASE WHEN COUNT(*) < 2 THEN 0.0 ELSE
                   LN(SUM(POW(pp, {params['renyi_alpha']})))
                   / (1 - {params['renyi_alpha']}) / LN(COUNT(*)) END FROM p
        """).fetchone()[0]

    stats = {}
    for budget in params["bucket_budgets"]:
        bw = budget // 4
        e = era[era["bw"] == bw]
        row = {"synopsis_bits_per_query": float(bits.loc[bw, "bits"])
                                          / subs[":nq"],
               "buckets_used": float(bits.loc[bw, "used"])}
        for tag in ("train", "final"):
            s = e[e["era"] == tag]
            q = np.maximum(s["ef"], s["tt"]) / np.minimum(s["ef"], s["tt"])
            plan = np.where(
                (s["ea"] <= s["eb"]) & (s["ea"] <= s["ec"]), "A",
                np.where(s["eb"] <= s["ec"], "B", "C"))
            row[f"q_error_{tag}_era"] = float(q.mean())
            row[f"p95_q_error_{tag}_era"] = float(np.percentile(q, 95))
            row[f"plan_agreement_{tag}_era"] = float(
                (plan == s["tp"].to_numpy()).mean() * 100.0)
            row[f"underestimate_share_{tag}_era"] = float(
                (s["ef"] < s["tt"]).mean())
            row[f"renyi_{tag}_era"] = float(ren[tag])
        stats[str(budget)] = {k: row[k] for k in sorted(row)}

    ab = dict(con.execute("SELECT attr, vbits FROM attrbits").fetchall())
    cbits = con.execute("SELECT b FROM bitlen WHERE v=?",
                        (subs[":nw"],)).fetchone()[0]
    ng = con.execute("SELECT COUNT(DISTINCT g1) FROM dim_channel").fetchone()[0] \
       + con.execute("SELECT COUNT(DISTINCT g2) FROM dim_region").fetchone()[0]
    budget_bits = {
        str(b): int(sum((b // 4) * (2 * ab[a] + 2 * cbits)
                        for a in params["attributes"]) + ng * cbits)
        for b in params["bucket_budgets"]}
    return {
        "attribute_bits": {a: int(ab[a]) for a in params["attributes"]},
        "budget_bits": budget_bits,
        "budgets": list(params["bucket_budgets"]),
        "count_bits": int(cbits),
        "mean_true_rows": float(con.execute(
            "SELECT AVG(true_rows) FROM truth").fetchone()[0]),
        "n_attributes": len(params["attributes"]),
        "n_blocks": subs[":n_blocks"],
        "n_channel_groups": int(con.execute(
            "SELECT COUNT(DISTINCT g1) FROM dim_channel").fetchone()[0]),
        "n_eval_blocks": n_eval,
        "n_queries": subs[":nq"],
        "n_region_groups": int(con.execute(
            "SELECT COUNT(DISTINCT g2) FROM dim_region").fetchone()[0]),
        "n_rows": int(con.execute("SELECT COUNT(*) FROM fact").fetchone()[0]),
        "n_window_blocks": params["window_blocks"],
        "rows_per_block": nb,
        "schema_stats": stats,
    }


def drift_report(con, subs) -> dict:
    con.executescript(bind((SQL / "40_drift.sql").read_text(), subs))
    n_ep = subs[":n_ep"]
    sh = pd.read_sql("SELECT * FROM shares", con)
    six = sh[sh["nbins"] == 6].pivot(index="epoch", columns="bin",
                                     values="share").to_numpy()
    ten = sh[sh["nbins"] == 10].pivot(index="epoch", columns="bin",
                                      values="share").to_numpy()
    cond = six.copy()
    np.fill_diagonal(cond, 0.0)
    rs = cond.sum(axis=1, keepdims=True)
    cond = np.where(rs > 0, cond / np.where(rs == 0, 1.0, rs),
                    1.0 / (n_ep - 1))
    ks = pd.read_sql("SELECT * FROM ksmat", con).pivot(
        index="e1", columns="e2", values="d").to_numpy()
    return {
        "conditional_epoch_share_matrix": [[float(x) for x in r] for r in cond],
        "decile_share_pct": {
            f"D{b}": {f"E{e}": float(ten[e][b] * 100.0) for e in range(n_ep)}
            for b in range(10)},
        "epoch_ks_matrix": [[float(x) for x in r] for r in ks],
        "epoch_share_matrix": [[float(x) for x in r] for r in six],
    }


# ------------------------------------------------------------------ main
def main(argv: list[str]) -> int:
    if len(argv) != 3:
        print("usage: python solve_full.py <data_dir> <out_path>",
              file=sys.stderr)
        return 2
    data, out_path = Path(argv[1]), Path(argv[2])
    con, params = load(data)

    n_blocks = int(con.execute("SELECT COUNT(DISTINCT block) FROM fact").fetchone()[0])
    nb = int(con.execute("SELECT COUNT(*) FROM fact WHERE block=0").fetchone()[0])
    nq = int(con.execute("SELECT COUNT(*) FROM workload").fetchone()[0])
    w = params["window_blocks"]
    blocks = list(range(w, n_blocks))
    subs = {":w": w, ":nb": nb, ":nw": nb * w, ":ns": params["sample_rows"],
            ":nq": nq, ":n_blocks": n_blocks, ":n_ep": params["n_epochs"],
            ":ep_len": n_blocks // params["n_epochs"],
            ":train_end": n_blocks // params["n_epochs"],
            ":final_start": n_blocks - n_blocks // params["n_epochs"],
            ":nref": nb * (n_blocks // params["n_epochs"]),
            ":sr": repr(params["selinger_range"]),
            ":se": repr(params["selinger_equality"])}

    df = walk(con, params, subs, blocks)
    target = params["target_q_error"]
    sweep = sorted(f"{f}_{s}_{b}" for f in FAMILIES for s in SCHEMES
                   for b in params["bucket_budgets"])
    audit = {blocks[s] for s in params["audit_steps"] if s < len(blocks)}
    invalid = int(df[df["blk"].isin(audit)]["invalid"].sum())

    variants = {}
    for ro in VARIANTS:
        v = df[df["ro"] == ro]
        strat = {c: metrics(v[(v["arm"] == "t") & (v["cfg"] == c)], target)
                 for c in sweep + list(STRUCTURES)}
        ctrl = {c: metrics(v[(v["arm"] == "c") & (v["cfg"] == c)], target)
                for c in sweep}
        vs = v[(v["arm"] == "t") & (v["cfg"].isin(sweep))]
        best = min(sweep, key=lambda c: (strat[c]["mean_q_error"], c))
        uni = strat["uniform"]["bits_per_query"]
        variants[ro] = {
            "control_metrics": {k: ctrl[k] for k in sorted(ctrl)},
            "diagnostics": {
                "best_bits_per_query": strat[best]["bits_per_query"],
                "best_config": best,
                "best_mean_q_error": strat[best]["mean_q_error"],
                "cost_vs_uniform_pct": float(
                    (strat[best]["bits_per_query"] - uni) / uni * 100.0),
                "invalid_estimates_audited": invalid,
                "mean_buckets_used": float(vs["used"].mean()),
                "mean_plan_agreement_pct": float(
                    np.mean([strat[c]["plan_agreement_pct"] for c in sweep])),
                "n_eval_blocks": len(blocks),
                "trigger_rate": float(vs["fired"].mean()),
            },
            "significance": significance(strat, ctrl),
            "strategy_metrics": {k: strat[k] for k in sorted(strat)},
        }

    results = {
        "database_report": database_report(con, params, subs, len(blocks)),
        "drift_report": drift_report(con, subs),
        "variants": variants,
    }
    text = json.dumps(results, indent=1, sort_keys=True, allow_nan=False)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(text)
    print(f"wrote {out_path} ({len(text)} bytes)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
