# Selectivity estimation and access-path choice under correlation and drift

This document is authoritative. It defines every parameter, every quantity to
be reported, and the structure of the output file. Where it fixes a value, that
value is not to be tuned. Where it fixes an ordering, ties are to be broken as
written and not otherwise.

The study asks a question the optimizer literature has argued over since
Selinger et al. (1979) fixed the independence assumption into System R: what
does a query optimizer actually buy by storing statistics about its data? The
answer is measured two ways at once — by q-error against the true cardinality,
in the sense of Moerkotte et al., and by whether the estimate leads to the same
access path the true cardinalities would have chosen, in the sense of Leis et
al. (VLDB 2015). The two need not agree, and a control arm is included so that
disagreement can be attributed.

---

## 1. Fixed parameters

Read from `data/params.json`. No value here is derived from the data.

| Parameter | Value | Meaning |
|---|---|---|
| `attributes` | a1, a2, a3, a4 | the estimated attributes, in this order |
| `domain_size` | a1:64, a2:32, a3:16, a4:64 | value `v` of attribute `a` satisfies 0 <= v < domain_size[a] |
| `window_blocks` | 6 | blocks of history a synopsis is built from |
| `bucket_budgets` | 80, 160, 320 | total buckets across all four attributes |
| `sample_rows` | 320 | rows retained by the sample structure |
| `target_q_error` | 4.0 | the service level a configuration is held to |
| `gate_multiple` | 1.25 | multiplier on the target that arms the trigger |
| `selinger_range` | 1/3 | the 1979 constant for a range predicate |
| `selinger_equality` | 1/10 | the 1979 constant for an equality predicate |
| `renyi_alpha` | 2.5 | order of the Rényi concentration statistic |
| `n_epochs` | 6 | epochs the block range is divided into |
| `control_piles` | a1:7, a2:11, a3:13, a4:5 | pile counts for the control permutation |
| `audit_steps` | 0, 8, 16, 24 | evaluation steps at which the guarantee is audited |

Derived and used throughout: `rows_per_block` N = 4000, `n_blocks` = 36,
`n_queries` = 100, window size `nw` = N × 6 = 24000, epoch length = 6 blocks,
buckets per attribute B = budget / 4, so B ∈ {20, 40, 80}.

## 2. Inputs

`fact.csv` holds 144,000 rows in 36 blocks of 4,000, in ascending block order.
Each row carries `row_id`, `block`, the four attribute values `a1`..`a4`, and
two foreign keys `k1`, `k2`.

`dim_channel.csv` maps each of 60 `k1` values to a channel group `g1` (3
groups). `dim_region.csv` maps each of 40 `k2` values to a region group `g2` (2
groups). A fact row's group membership is the group of the key it references.

`workload.csv` holds 100 queries. Query q is the conjunction of six predicates:
`a1 BETWEEN lo1 AND hi1`, likewise for a2, a3, a4, and the two equality
predicates `g1 = q.g1`, `g2 = q.g2`. A range with `lo = hi` is an equality
predicate on that attribute; this occurs for a2 and a3 in part of the workload
and never for a1 or a4.

`truth.csv` holds one row per block-query pair, 3,600 in all: the true result
cardinality `true_rows` of q against that block, and the three true access-path
intermediate cardinalities `true_path_a`, `true_path_b`, `true_path_c` defined
in section 4.

`warehouse.db` holds the same five tables as a SQLite database. It is provided
for convenience and adds no information.

Truth is a measurement instrument, not an input to estimation. Section 16 says
exactly what it may be read for.

## 3. Cost accounting

Every structure is charged for what it would cost to store, in bits, under a
fixed and deliberately simple code. The point is not to model a real catalog
page but to make storage comparable across structures that have nothing else in
common.

A value of attribute `a` costs `value_bits(a) = bit_length(domain_size[a] - 1)`
bits: a1 and a4 cost 6, a2 costs 5, a3 costs 4. A count over a row set of size
n costs `count_bits = bit_length(n)` bits: 15 over the 24,000-row window, 12
over a single 4,000-row block.

An equi-depth bucket stores two boundary values and two counts, so it costs
`2·value_bits(a) + 2·count_bits`. An MCV entry stores one value and one count,
so it costs `value_bits(a) + count_bits`. Each synopsis additionally carries a
header of one count per distinct group value **in the two dimension catalogs** —
`COUNT(DISTINCT g1)` over `dim_channel` plus `COUNT(DISTINCT g2)` over
`dim_region`, which is 3 + 2 = 5 for this warehouse.

The header is a property of the schema, not of any particular row set. A group
that happens to be absent from a given window still occupies its slot, with a
count of zero. Deriving the header from the rows summarised instead would make
the cost of a synopsis depend on which groups a window happened to contain, and
every window in this study contains all five, so the two readings agree here and
would diverge on data where they do not.

`bit_length` is the position of the highest set bit, with `bit_length(0) = 0`
and no clamping at 1 — a single-group dimension would legitimately cost zero
bits per group code.
It is computed by integer halving, never by a logarithm, so no result depends
on floating-point rounding.

Two transcendental functions are needed elsewhere — a power, in the backoff
scheme of section 6, and a natural logarithm, in the Rényi statistic of section
14. SQLite exposes `POW` and `LN` only when built with
`SQLITE_ENABLE_MATH_FUNCTIONS`, which is a compile-time option that some
distributions omit. An implementation must not assume the build provides them;
register them as application-defined functions instead, which take precedence
over the built-ins where those exist. Both delegate to the same C library the
built-ins call, so no reported value changes either way.

The budget line for a budget is the closed form

    budget_bits(budget) = (budget / 4) · Σ_a (2·value_bits(a) + 2·count_bits)
                          + 5 · count_bits

with `count_bits` = 15, giving 3315, 6555 and 13035 bits. This is what the
budget would cost if every bucket were used; section 5 explains why a synopsis
may use fewer.

A configuration's reported cost is `bits_per_query`, the mean over evaluation
blocks of

    (synopsis_bits + Σ_q bit_length(est_q)) / n_queries

so a structure pays both for the statistics it stores and for the width of the
estimates it emits.

## 4. Access paths and the plan decision

Three access paths are available. Path A applies the predicates on a1 and a2,
path B those on a3 and a4, path C the two group equality predicates. The
optimizer picks the path with the smallest estimated intermediate cardinality,
breaking ties toward the earlier letter: A before B before C.

The true intermediate cardinalities are the three columns of `truth.csv`, and
the true path is the argmin over them under the same tie rule. A configuration
agrees on a query when the path chosen from its own estimates equals the true
path. `plan_agreement_pct` is the percentage of such agreements, averaged over
blocks.

Every intermediate estimate is clamped exactly as a full estimate is, by the
rule in section 12, before the comparison.

## 5. Synopsis construction

A synopsis is built from the six blocks strictly preceding the block being
served, and from nothing else. For attribute `a` let the window value counts be
the pairs (v, n_v) for each distinct v present, in ascending v.

**Bucket assignment.** With `cum_before(v)` the total count of all window rows
whose value is strictly less than v, and n the window size, value v is assigned
to bucket

    bid(v) = (cum_before(v) · B) / n        (integer division)

A value therefore never straddles two buckets, and the assignment involves no
floating-point comparison. A bucket's boundaries `lo`, `hi` are the least and
greatest values assigned to it, and its count the sum of their counts.

Because a single frequent value can absorb the mass of several nominal buckets,
the number of buckets a synopsis actually occupies may be less than B. This
shortfall is real and is reported, not corrected: `buckets_used` counts the
buckets that exist, and cost is charged on those, not on the budget.

**Family `depth`.** B buckets per attribute by the rule above, and nothing else.

**Family `mcv`.** The most common `B − B/4` values of the attribute (integer
division; 15, 30 and 60 for the three budgets), ordered by count descending and
then by value ascending, are stored explicitly as MCV entries. The remaining
values — the residue — are bucketed by the same rule with `B/4` buckets, over
the residue's own count total. A value appears in exactly one of the two parts,
never both. This is the shape PostgreSQL's per-attribute statistics take.

## 6. Combination schemes

For query q a synopsis yields a selectivity `s_p` for each of the six
predicates p. The four schemes combine them differently.

`avi` takes the product of all six, the independence assumption in its original
form.

`ebo` is exponential backoff in the SQL Server sense. Order the six predicates
by estimated matching rows descending — that is, by `round(N · s_p)` — breaking
ties by predicate name ascending, and take

    s = s_(1) · s_(2)^(1/2) · s_(3)^(1/4) · s_(4)^(1/8) · s_(5)^(1/16) · s_(6)^(1/32)

`minsel` takes the single smallest selectivity among the six and ignores the
rest.

`mix` takes `ebo` when the trigger of section 7 is armed for this configuration
at this block, and `avi` otherwise.

For a path's intermediate estimate the same scheme is applied to just the two
predicates on that path, under the same tie rules.

## 7. The feedback trigger

The trigger is the study's one concession to a learning optimizer, in the
spirit of LEO (Stillger et al.): a configuration may notice that it did badly
and change how it combines predicates, but only on the strength of blocks
already served.

Configuration c is armed at block i when its own mean q-error at block i−1,
measured under the `interp` readout, exceeded `gate_multiple · target_q_error`
= 5.0. At the first evaluation block no configuration is armed.

The trigger is defined by the `interp` readout in every variant. This is what
makes it an invariant across variants rather than three separate streams, and
it is the single most fragile point in the specification: a solver that
recomputes the trigger inside the readout loop reproduces every `avi`, `ebo`
and `minsel` number and gets every `mix` number wrong.

## 8. Families, schemes, budgets

The sweep is the full crossing of 2 families × 4 schemes × 3 budgets = 24
configurations, named `{family}_{scheme}_{budget}`, for example `depth_avi_320`
or `mcv_mix_80`.

## 9. Readout conventions — the three variants

A readout decides how a bucket already built is *read*, given a query range. It
changes nothing about how the synopsis was constructed, what it cost, or which
buckets exist. For a bucket spanning `[lo, hi]` and a query range `[qlo, qhi]`,
the fraction of the bucket's count that the query is charged is

`interp` — linear interpolation on the bucket's span:
`max(0, min(qhi,hi) − max(qlo,lo) + 1) / (hi − lo + 1)`.

`mid` — all or nothing on the midpoint: 1 if `lo + (hi−lo)/2` (integer
division) lies in `[qlo, qhi]`, else 0.

`half` — 1 if the query covers the bucket entirely, else 1/2 if it overlaps at
all, else 0.

An MCV entry is exact under every readout: its value either satisfies the
predicate or does not. A selectivity is the charged mass over the row set
total, capped at 1.

The three variants of the output are these three readouts. Because a readout
cannot reach construction, cost or the trigger, the quantities named in section
15 are identical across all three.

## 10. Four further structures

These sit outside the sweep and are reported alongside it.

`uniform` is Selinger's 1979 estimator: 1/3 for a range predicate, 1/10 for an
equality predicate, and the catalog reciprocal 1/|G| for each group predicate.
It reads no data, stores nothing, and is charged 0 synopsis bits — its
`bits_per_query` is the width of its estimates alone. It is the floor against
which the value of statistics is measured.

`sample` retains 320 rows of the window by systematic selection. Order the
window rows by `row_id` ascending and number them by **position** from 0, so
the first row of the window is always position 0 regardless of which blocks the
window covers. Keep the rows whose position is divisible by the stride
`nw / 320` = 75, up to 320 rows.

The selection is positional, not a property of the `row_id` value. `row_id` is
a zero-padded string, so an arithmetic test on it is not well defined in any
case; but note that the two readings coincide on the first evaluation window
and diverge on the other twenty-nine, so checking the sample against one block
will not reveal the difference. Estimates are exact counts over the sample, scaled.
Each retained row costs `Σ_a value_bits(a)` = 21 bits plus a channel-group code
of `bit_length(2)` = 2 bits and a region-group code of `bit_length(1)` = 1 bit,
so the sample costs 320 × 24 bits. It never reads a bucket, so it is identical
across all three variants.

`oracle` is `depth`/`avi`/320 built on the block it is about to serve rather
than on the window. Every statistic it uses — histograms and group frequencies
alike — comes from that block, and its counts are charged at `count_bits` = 12
for a 4,000-row block. It is not implementable; it bounds what any synopsis of
that shape could achieve if drift were absent.

`cascade` extends `depth`/`avi`/320 with one joint contingency table. Among the
six attribute pairs, at width 20 per attribute, choose the pair maximising

    Σ_{x,y} | n · n_xy − n_x · n_y |

in integer arithmetic over the 20×20 grid, where n_xy is the window count in
cell (x,y) and n_x, n_y the marginal bucket counts; ties are broken by (x,y)
ascending in the order a1a2, a1a3, a1a4, a2a3, a2a4, a3a4. The joint replaces
the two marginals for that pair; the other two attributes and the group
predicates are combined as `avi`. Each occupied cell stores two bucket indices
at `bit_length(19)` = 5 bits each plus one count at `count_bits`, and that is
added to the cost of the underlying `depth`/320 synopsis.

## 11. The control arm

The control answers: how much of a configuration's performance comes from
knowing *where* the mass sits, as opposed to knowing the shape of the frequency
distribution at all?

For each attribute independently, take the window count vector in ascending
value order and permute it by dealing into P piles, where P is that attribute's
entry in `control_piles`: index the distinct values j = 0, 1, 2, …, and send
position j to the rank of (j mod P, j) in ascending order. The permuted counts
are then re-attached to the same ascending value list.

This preserves the multiset of counts exactly and the set of distinct values
exactly. What it destroys is the association between a value and its frequency
— and with it, any spatial structure the histogram could exploit. Because the
count multiset survives, so does the total, so a control synopsis costs very
nearly what its treatment costs.

The control arm is run for the 24 sweep configurations only. `uniform` reads no
data; `sample` and `cascade` are row-level and joint and are untouched by a
permutation of marginal counts; `oracle` is already an upper bound.

No pseudo-random generator is consumed anywhere in this study. There is no seed
to agree on and no draw order to get wrong.

## 12. Estimates, q-error, metrics

An estimate is clamped to the admissible range and rounded to an integer:

    est = min(N, max(1, floor(N · s + 0.5)))

with N = `rows_per_block`. The q-error against a true cardinality T is

    q = max(est, T') / min(est, T')        with T' = max(1, T)

symmetric in over- and under-estimation, as Moerkotte et al. define it.

Per block a configuration's q-error is the mean over the 100 queries. Seven
metrics are then reported over the 30 evaluation blocks:

| Metric | Definition |
|---|---|
| `mean_q_error` | mean of the per-block mean q-errors |
| `p95_q_error` | 95th percentile of the per-block means (linear interpolation) |
| `max_q_error` | maximum of the per-block means |
| `pct_within_target` | share of blocks whose mean q-error is at most 4.0 |
| `excess_ratio` | `mean_q_error` / 4.0 |
| `bits_per_query` | as defined in section 3, averaged over blocks |
| `plan_agreement_pct` | as defined in section 4, averaged over blocks |

## 13. Significance

For each family separately, the 12 configurations of that family are paired
with the identically named control. Four metrics are tested, oriented so that
larger is better: `mean_q_error`, `p95_q_error` and `bits_per_query` are
negated; `plan_agreement_pct` is not.

`treatment_rank` is the mean over the 12 pairs of 2 when treatment beats
control, 1 when it loses, 1.5 when they tie; `control_rank` is 3 minus that.

`t_test_p` is `scipy.stats.ttest_rel(treatment, control, alternative="greater")`
on the oriented values.

`nemenyi_p` is the two-method reduction of the Nemenyi test: with
`q = |treatment_rank − control_rank| · sqrt(12)`, the p-value is
`min(2 · Φ̄(q / sqrt(2)), 1)`.

These two library calls are the only computation in the study that is not
relational.

## 14. Output structure

`results.json` is a single JSON object with exactly three top-level keys.

**`database_report`** — `attribute_bits` (object keyed by attribute),
`budget_bits` (keyed by budget as a string), `budgets` (list), `count_bits`,
`mean_true_rows` (over all 3,600 truth rows), `n_attributes`, `n_blocks`,
`n_channel_groups`, `n_eval_blocks`, `n_queries`, `n_region_groups`, `n_rows`,
`n_window_blocks`, `rows_per_block`, and `schema_stats`.

`schema_stats` is keyed by budget and holds twelve values per budget, computed
from a single reference synopsis — `depth`/`avi` under the `interp` readout,
built on the train era (blocks 0–5) and applied to the train era and to the
final era (blocks 30–35): `synopsis_bits_per_query`, `buckets_used`,
`q_error_train_era`, `q_error_final_era`, `p95_q_error_train_era`,
`p95_q_error_final_era`, `plan_agreement_train_era`, `plan_agreement_final_era`,
`underestimate_share_train_era`, `underestimate_share_final_era`,
`renyi_train_era`, `renyi_final_era`.

The Rényi statistic of order α = 2.5 over the era's joint (a1,a2,a3,a4)
distribution is `ln(Σ p^α) / (1 − α) / ln(K)` with K the number of distinct
tuples, and 0 when K < 2.

**`drift_report`** — the statistic attached to a fact row is the train-era
frequency rank of its (a1,a2,a3,a4) tuple, ordered by count descending then
tuple ascending, with tuples absent from the train era taking rank
`n_train + 1`. Bin edges are the interior quantiles of that statistic over the
train era, with linear interpolation, and a value falls in the bin given by
`searchsorted(edges, v, side="right")`.

`epoch_share_matrix` is 6×6, row per epoch, column per sextile bin, rows
summing to 1. `conditional_epoch_share_matrix` is the same with the diagonal
zeroed and rows renormalised, a zero row becoming uniform at 1/5.
`epoch_ks_matrix` is 6×6 of two-sample Kolmogorov–Smirnov statistics between
epochs. `decile_share_pct` is keyed `D0`..`D9`, each holding `E0`..`E5` as
percentages.

**`variants`** — keyed `interp`, `mid`, `half`, each holding:

`diagnostics` — `n_eval_blocks`, `mean_buckets_used`, `trigger_rate`,
`mean_plan_agreement_pct`, `best_config`, `best_mean_q_error`,
`best_bits_per_query`, `cost_vs_uniform_pct`, `invalid_estimates_audited`.
`best_config` is the sweep configuration with the least `mean_q_error`, ties
broken by name ascending. `cost_vs_uniform_pct` is the percentage by which the
best configuration's `bits_per_query` exceeds `uniform`'s.

`strategy_metrics` — 28 entries: the 24 sweep configurations plus `cascade`,
`oracle`, `sample`, `uniform`, each holding the seven metrics of section 12.

`control_metrics` — the 24 sweep configurations under the control arm.

`significance` — keyed by family, then by metric, each holding `control_rank`,
`treatment_rank`, `t_test_p`, `nemenyi_p`.

## 15. Conventions

Object keys are sorted. Floating-point values are serialised as JSON numbers;
`NaN`, `Infinity` and `-Infinity` are invalid anywhere in the file.

Evaluation runs over blocks 6 through 35 in ascending order, 30 blocks, and a
block is served only after every block preceding it.

The following are identical across all three variants, because a readout cannot
reach them: `mean_buckets_used`, `trigger_rate`, `invalid_estimates_audited`,
`n_eval_blocks`, and every metric of `uniform` and of `sample`.

Percentiles use linear interpolation. Integer division truncates toward zero and
is used wherever this document writes it. Ties are broken as each section
states and never by input order.

## 16. What `truth.csv` licenses

`truth.csv` may be read for exactly two purposes.

The first is measurement: computing q-error, plan agreement, underestimate
share, and every metric derived from them, after an estimate has been formed.

The second is the trigger of section 7, and only in the form stated there —
a configuration's own realised mean q-error at blocks strictly earlier than the
one being served. This mirrors what a real feedback optimizer learns from
executed queries and nothing more.

Truth may not enter synopsis construction, bucket assignment, MCV selection,
scheme choice, the cascade pair choice, or the readout. It may not be consulted
for the block being served. A solver that uses `true_rows` at block i to
influence any estimate at block i has not solved this task, and the invariants
of section 15 together with the guarantee audit of section 12 are the checks
that make such use visible.

`invalid_estimates_audited` counts, at the four audit steps, estimates that are
not integers within [1, N]. It must be zero.
