"""
Narrow crosscheck: an independent re-derivation of 30 reported quantities.

    python solve_narrow_crosscheck.py <data_dir> <out_path>

This file imports nothing from the research library. It was written from
SPEC.md rather than from the reference solution, and it uses a different merge
update strategy: each word type carries its own set of current adjacent pairs
and the words touched by a merge are found by testing that set, where the
reference keeps a global pair-to-word index. The two disagree by 0.0e+00 on
every quantity below.

Its purpose is not coverage. It is to establish that the specification is
sufficient: that a second implementation, reading only the prose, lands on the
same numbers. Quantities are chosen to isolate one mechanism each -- the cost
accounting, the cut constraints, the two merge families, the three regimes, the
control permutation, the drift binning -- so that a mismatch points somewhere.
"""

from __future__ import annotations

import json
import math
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats as st

WINDOW = 6
TARGET = 2.0
N_EPOCH = 6


# ------------------------------------------------------------------ basics

def cbits(v: int) -> int:
    return max(1, (v - 1).bit_length())


def table_bits(A: int, t: int) -> int:
    return sum(2 * cbits(A + j) for j in range(t))


def varieties(types):
    s, p = defaultdict(set), defaultdict(set)
    for w in types:
        for i in range(1, len(w)):
            s[w[:i]].add(w[i])
            p[w[i:]].add(w[i - 1])
    return {k: len(v) for k, v in s.items()}, {k: len(v) for k, v in p.items()}


def cuts_of(word, scheme, succ, pred, th):
    if scheme == "free":
        return frozenset()
    r = set()
    for i in range(1, len(word)):
        if succ.get(word[:i], 0) >= th:
            r.add(i)
        elif scheme == "bidi" and pred.get(word[i:], 0) >= th:
            r.add(i)
    return frozenset(r)


# ------------------------------------------------------------- merge rules

def learn(counts, budget, family, scheme, succ, pred, th, floor):
    syms, offs, freq, cut, own = [], [], [], [], []
    for w in sorted(counts):
        if len(w) < 2:
            continue
        syms.append(list(w))
        offs.append(list(range(len(w) + 1)))
        freq.append(counts[w])
        cut.append(cuts_of(w, scheme, succ, pred, th))
        own.append(set())

    pc, sc = Counter(), Counter()

    def refresh(i, sign):
        s, o, f = syms[i], offs[i], freq[i]
        for x in s:
            sc[x] += sign * f
        cur = set()
        for j in range(len(s) - 1):
            if o[j + 1] in cut[i]:
                continue
            key = (s[j], s[j + 1])
            pc[key] += sign * f
            cur.add(key)
        if sign > 0:
            own[i] = cur

    for i in range(len(syms)):
        refresh(i, +1)

    out = []
    for _ in range(budget):
        pick = None
        if family == "freq":
            top = 0
            for k, v in pc.items():
                if v > top or (v == top and pick is not None and k < pick):
                    top, pick = v, k
        else:
            bn = bd = 0
            for k, v in pc.items():
                if v < floor:
                    continue
                d = sc[k[0]] * sc[k[1]]
                if d <= 0:
                    continue
                if pick is None:
                    bn, bd, pick = v, d, k
                elif v * bd > bn * d or (v * bd == bn * d and k < pick):
                    bn, bd, pick = v, d, k
        if pick is None or pc.get(pick, 0) <= 0:
            break

        a, b = pick
        joined = a + b
        for i in range(len(syms)):
            if pick not in own[i]:
                continue
            refresh(i, -1)
            s, o, ns, no, j = syms[i], offs[i], [], [offs[i][0]], 0
            while j < len(s):
                if (j + 1 < len(s) and s[j] == a and s[j + 1] == b
                        and o[j + 1] not in cut[i]):
                    ns.append(joined)
                    no.append(o[j + 2])
                    j += 2
                else:
                    ns.append(s[j])
                    no.append(o[j + 1])
                    j += 1
            syms[i], offs[i] = ns, no
            refresh(i, +1)
        out.append(pick)
        pc.pop(pick, None)
    return out


# ------------------------------------------------------------- segmenting

def make_vocab(alpha, merges):
    voc = list(alpha) + [a + b for a, b in merges]
    return voc, {p: i for i, p in enumerate(merges)}, set(voc), max(map(len, voc))


def seg(word, regime, rank, vset, mx):
    if regime == "rank":
        s = list(word)
        while True:
            lo, at = None, -1
            for j in range(len(s) - 1):
                r = rank.get((s[j], s[j + 1]))
                if r is not None and (lo is None or r < lo):
                    lo, at = r, j
            if lo is None:
                return s
            s[at:at + 2] = [s[at] + s[at + 1]]
    if regime == "greedy":
        o, i = [], 0
        while i < len(word):
            j = min(len(word), i + mx)
            while j > i + 1 and word[i:j] not in vset:
                j -= 1
            o.append(word[i:j])
            i = j
        return o
    n = len(word)
    best = [n + 2] * (n + 1)
    cut = [0] * (n + 1)
    best[n] = 0
    for i in range(n - 1, -1, -1):
        for j in range(min(n, i + mx), i, -1):
            if j - i == 1 or word[i:j] in vset:
                if 1 + best[j] < best[i]:
                    best[i], cut[i] = 1 + best[j], j
    o, i = [], 0
    while i < n:
        o.append(word[i:cut[i]])
        i = cut[i]
    return o


def bounds(pieces):
    r, a = set(), 0
    for p in pieces[:-1]:
        a += len(p)
        r.add(a)
    return r


def score(words, pmap, gold):
    tot = tp = npd = ngd = 0
    for w in words:
        p = pmap[w]
        tot += len(p)
        b = bounds(p)
        g = gold[w]
        tp += len(b & g)
        npd += len(b)
        ngd += len(g)
    if tp == 0 or npd == 0 or ngd == 0:
        f = 0.0
    else:
        pr, rc = tp / npd, tp / ngd
        f = 2 * pr * rc / (pr + rc)
    return tot, f


# ------------------------------------------------------------------- main

def main(argv):
    data, out = Path(argv[1]), Path(argv[2])
    corpus = pd.read_csv(data / "corpus.csv", dtype={"word": str})
    lex = pd.read_csv(data / "lexicon.csv", dtype={"word": str, "morphs": str})
    alpha = json.loads((data / "alphabet.json").read_text())

    A = len(alpha["symbols"])
    abits = sum(alpha["symbol_bits"][c] for c in alpha["symbols"])
    th = alpha["variety_threshold"]
    floor = alpha["min_pair_count"]
    budget = alpha["merge_budget"]

    gold = {}
    for w, m in zip(lex["word"], lex["morphs"]):
        acc, cs = 0, set()
        parts = m.split("+")
        for p in parts[:-1]:
            acc += len(p)
            if 0 < acc < len(w):
                cs.add(acc)
        gold[w] = cs

    blocks = sorted(corpus["block"].unique().tolist())
    words = {b: g["word"].tolist() for b, g in corpus.groupby("block")}
    nb = len(blocks)
    bs = len(words[blocks[0]])
    ev = blocks[WINDOW:]

    res = {"corpus": {
        "n_blocks": nb, "n_tokens": int(len(corpus)), "n_types": int(len(lex)),
        "n_eval_blocks": len(ev), "alphabet_size": A, "alphabet_bits": abits,
        "mean_word_len": float(np.mean([len(w) for b in blocks
                                        for w in words[b]])),
        "vocab_bits_128": table_bits(A, 128),
        "vocab_bits_320": table_bits(A, 320),
        "vocab_bits_600": table_bits(A, 600)}}

    # ---- reference vocabulary on the train era -------------------------
    tr_blocks, fi_blocks = blocks[:WINDOW], blocks[-WINDOW:]
    tc = Counter()
    for b in tr_blocks:
        tc.update(words[b])
    s0, p0 = varieties(sorted(tc))
    full = learn(dict(tc), budget, "freq", "free", s0, p0, th, floor)

    ref = {}
    for size, tag in ((320, "320"), (600, "600")):
        _, rk, vs, mx = make_vocab(alpha["symbols"], full[:size])
        for era, blks in (("train", tr_blocks), ("final", fi_blocks)):
            ws = [w for b in blks for w in words[b]]
            pm = {w: seg(w, "rank", rk, vs, mx) for w in set(ws)}
            tot, f = score(ws, pm, gold)
            ref[f"fertility_{era}_era_{tag}"] = tot / len(ws)
            ref[f"boundary_f1_{era}_era_{tag}"] = f * 100.0
            if era == "train" and size == 320:
                cnt = Counter(p for w in ws for p in pm[w])
                q = np.array(list(cnt.values()), float)
                q = q / q.sum()
                h = math.log(float(np.power(q, 2.5).sum())) / (1 - 2.5)
                ref["renyi_train_era_320"] = h / math.log(len(cnt))
    res["reference"] = ref

    # ---- drift ---------------------------------------------------------
    order = sorted(tc.items(), key=lambda kv: (-kv[1], kv[0]))
    rk_of = {w: i + 1 for i, (w, _) in enumerate(order)}
    novel = len(order) + 1
    per = {b: np.array([rk_of.get(w, novel) for w in words[b]], float)
           for b in blocks}
    ep = [np.concatenate([per[b] for b in blocks if min(b // WINDOW, 5) == e])
          for e in range(6)]
    tr_s = np.concatenate([per[b] for b in tr_blocks])

    def share(nb_):
        e_ = np.percentile(tr_s, [100.0 * i / nb_ for i in range(1, nb_)])
        return [np.bincount(np.searchsorted(e_, ep[e], side="right"),
                            minlength=nb_)[:nb_] / len(ep[e])
                for e in range(6)]

    s6, s10 = share(6), share(10)
    res["drift"] = {
        "ks_0_5": float(st.ks_2samp(ep[0], ep[5], method="asymp").statistic),
        "share_5_5": float(s6[5][5]),
        "decile_D9_E5": float(s10[5][9] * 100.0),
        "decile_D0_E0": float(s10[0][0] * 100.0)}

    # ---- walk forward --------------------------------------------------
    rng = np.random.default_rng(11)
    wtypes = []
    for b in ev:
        ws = []
        for k in range(b - WINDOW, b):
            ws.extend(words[k])
        wtypes.append(sorted(set(ws)))
    perms = [rng.permutation(len(t)) for t in wtypes]
    _ = rng.random(len(ev))

    acc = defaultdict(list)
    for step, b in enumerate(ev):
        types = wtypes[step]
        wc = Counter()
        for k in range(b - WINDOW, b):
            wc.update(words[k])
        su, pr = varieties(types)
        bw = words[b]
        bt = sorted(set(bw))
        fr = [wc[t] for t in types]
        ctrl = {types[j]: fr[perms[step][j]] for j in range(len(types))}

        cut_b = {w: cuts_of(w, "bidi", su, pr, th) for w in bt}

        def cost(t, tot):
            return (abits + table_bits(A, t) + tot * cbits(A + t)) / bs

        def run(tag, counts):
            ff = learn(counts, budget, "freq", "free", su, pr, th, floor)
            lf = learn(counts, 320, "like", "free", su, pr, th, floor)
            sets = {("freq", "free"): ff, ("like", "free"): lf}
            if tag == "t":
                sets[("freq", "bidi")] = learn(counts, 320, "freq", "bidi",
                                               su, pr, th, floor)
            for (fam, sch), ml in sets.items():
                for size in (128, 320, 600):
                    if size > len(ml) and size > 320 and (fam, sch) != ("freq", "free"):
                        continue
                    sub = ml[:size]
                    _, rk2, vs2, mx2 = make_vocab(alpha["symbols"], sub)
                    for rg in ("rank", "greedy", "short"):
                        pm = {w: seg(w, rg, rk2, vs2, mx2) for w in bt}
                        tot, f = score(bw, pm, gold)
                        acc[f"{tag}_{rg}_{fam}_{sch}_{size}"].append(
                            (tot / bs, cost(len(sub), tot), f * 100.0))
            return ff

        ff_t = run("t", dict(wc))
        run("c", ctrl)

        pm = {w: list(w) for w in bt}
        tot, f = score(bw, pm, gold)
        acc["t_rank_chars"].append((tot / bs, cost(0, tot), f * 100.0))

        top = sorted(wc.items(), key=lambda kv: (-kv[1], kv[0]))[:600]
        stored = {w for w, _ in top}
        wb = sum(len(w) * cbits(A) for w in stored)
        pm = {w: ([w] if w in stored else list(w)) for w in bt}
        tot, f = score(bw, pm, gold)
        acc["t_rank_words"].append(
            (tot / bs, (abits + wb + tot * cbits(A + len(stored))) / bs,
             f * 100.0))

        own = Counter(bw)
        so, po = varieties(sorted(own))
        ml = learn(dict(own), 320, "freq", "free", so, po, th, floor)
        _, rk3, vs3, mx3 = make_vocab(alpha["symbols"], ml)
        pm = {w: seg(w, "rank", rk3, vs3, mx3) for w in bt}
        tot, f = score(bw, pm, gold)
        acc["t_rank_oracle"].append((tot / bs, cost(len(ml), tot), f * 100.0))

        _, rk4, vs4, mx4 = make_vocab(alpha["symbols"], ff_t)
        pm = {}
        for w in bt:
            o, prev = [], 0
            for c in sorted(cut_b[w]) + [len(w)]:
                if c > prev:
                    o.extend(seg(w[prev:c], "rank", rk4, vs4, mx4))
                    prev = c
            pm[w] = o
        tot, f = score(bw, pm, gold)
        acc["t_rank_cascade"].append((tot / bs, cost(len(ff_t), tot), f * 100.0))

    def col(k, i):
        return float(np.mean([r[i] for r in acc[k]]))

    res["rank"] = {
        "chars_mean_fertility": col("t_rank_chars", 0),
        "chars_bits_per_word": col("t_rank_chars", 1),
        "words_mean_fertility": col("t_rank_words", 0),
        "freq_free_128_mean_fertility": col("t_rank_freq_free_128", 0),
        "freq_free_128_boundary_f1_pct": col("t_rank_freq_free_128", 2),
        "freq_bidi_320_mean_fertility": col("t_rank_freq_bidi_320", 0),
        "freq_bidi_320_boundary_f1_pct": col("t_rank_freq_bidi_320", 2),
        "freq_free_600_bits_per_word": col("t_rank_freq_free_600", 1),
        "like_free_320_mean_fertility": col("t_rank_like_free_320", 0),
        "like_free_320_boundary_f1_pct": col("t_rank_like_free_320", 2),
        "oracle_mean_fertility": col("t_rank_oracle", 0),
        "cascade_mean_fertility": col("t_rank_cascade", 0),
        "cascade_boundary_f1_pct": col("t_rank_cascade", 2)}
    res["greedy"] = {
        "freq_free_128_mean_fertility": col("t_greedy_freq_free_128", 0),
        "freq_bidi_320_boundary_f1_pct": col("t_greedy_freq_bidi_320", 2)}
    res["short"] = {
        "freq_free_600_mean_fertility": col("t_short_freq_free_600", 0),
        "freq_free_600_bits_per_word": col("t_short_freq_free_600", 1),
        "freq_bidi_320_boundary_f1_pct": col("t_short_freq_bidi_320", 2)}
    res["control"] = {
        "rank_freq_free_128_mean_fertility": col("c_rank_freq_free_128", 0),
        "rank_freq_free_600_mean_fertility": col("c_rank_freq_free_600", 0),
        "rank_freq_free_600_boundary_f1_pct": col("c_rank_freq_free_600", 2),
        "rank_like_free_320_mean_fertility": col("c_rank_like_free_320", 0),
        "short_freq_free_600_mean_fertility": col("c_short_freq_free_600", 0)}

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(res, indent=1, sort_keys=True, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
