"""
Full-scope reference solution.

Reproduces the complete study on the frozen inputs: the corpus and reference
vocabulary report, the drift report, three segmentation regimes, 28 structures
per regime, 26 control arms per regime, and the paired significance panels.

    python solve_full.py <data_dir> <out_path>

Determinism
-----------
Every component that could drift is pinned:

  * merge selection   integer counts throughout. The likelihood family
                      compares count(ab)/(count(a)count(b)) by
                      cross-multiplying integers, so no rounding can reorder
                      two merges, and both families break ties on the pair's
                      surface string rather than on dictionary iteration
                      order.
  * cut constraints   successor and predecessor variety are counts of distinct
                      characters over the window's type inventory. They are
                      unweighted, so they are identical in both arms.
  * control arm       numpy.random.default_rng(11), consumed in a fixed order:
                      one permutation of the window's type list per evaluation
                      block in ascending block order, then a single
                      rng.random(30) supplying the control gate statistic.

The gate draw is consumed in every variant, including regimes whose scheme
never acts on it. Skipping it leaves the treatment arm untouched and changes
every control number, which makes the control arm the fragile part of the
specification and the first thing to check against a mismatch.

This oracle imports the research library. The standalone
``crosscheck/solve_narrow_crosscheck.py`` re-derives 26 of these quantities
from the specification text alone, with a different merge-update strategy, and
agrees with this file to 0.0e+00, which is the evidence that the specification
describes the intended computation rather than merely describing this code.
"""

from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")

RESEARCH = Path(__file__).resolve().parents[2] / "research" / "morph_bpe"
if RESEARCH.exists():
    sys.path.insert(0, str(RESEARCH))
else:
    sys.path.insert(0, "/home/claude/morph_bpe")

from src.data import load_corpus            # noqa: E402
from src.evaluate import Engine             # noqa: E402
from src.report import build_results        # noqa: E402


def main(argv: list[str]) -> int:
    if len(argv) != 3:
        print("usage: python solve_full.py <data_dir> <out_path>",
              file=sys.stderr)
        return 2
    data_dir, out_path = Path(argv[1]), Path(argv[2])

    corpus, lex, alpha = load_corpus(data_dir)
    results = build_results(Engine(corpus, lex, alpha))

    text = json.dumps(results, indent=1, sort_keys=True, allow_nan=False)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(text)
    print(f"wrote {out_path} ({len(text)} bytes)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
