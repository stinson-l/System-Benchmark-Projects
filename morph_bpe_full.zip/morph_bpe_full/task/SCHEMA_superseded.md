# Superseded

The authoritative schema now lives in SPEC.md section 14, alongside the
algorithm specification it depends on. This file is retained only so that
references to SCHEMA.md in earlier correspondence resolve somewhere.

Read SPEC.md.
