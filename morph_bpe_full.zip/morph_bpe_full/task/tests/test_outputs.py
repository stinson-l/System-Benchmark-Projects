"""
Deterministic verifier suite for /app/results.json.

    pytest -q task/tests/test_outputs.py

Every check is programmatic and returns pass/fail with no human judgment. The
suite passes only if every check passes. Checks are ordered cheap-to-expensive
so a structurally broken submission fails in milliseconds.

Layers:
  V1-V3    the file and its shape
  V4-V5    comparison against the reference values
  V6-V9    internal consistency, needing no reference
  V10-V11  closed-form recomputation from the inputs alone
  V12-V15  independent recomputation of individual pipeline components
  V16-V18  the guarantee, stability and anti-hardcoding
"""

from __future__ import annotations

import json
import math
import os
import subprocess
import sys
from collections import Counter
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
SUBMISSION = Path(os.environ.get("SUBMISSION", "/app/results.json"))
if not SUBMISSION.exists():                      # local runs
    SUBMISSION = ROOT / "expected_results.json"
REFERENCE = ROOT / "expected_results.json"
DATA = ROOT / "data"
CROSSCHECK = ROOT / "crosscheck" / "solve_narrow_crosscheck.py"

TARGET = 2.0
N_EVAL = 30
N_WORDS_PER_BLOCK = 800
VARIANTS = ("rank", "greedy", "short")
EXACT_FIELDS = {"n_blocks", "n_tokens", "n_types", "n_eval_blocks",
                "n_window_blocks", "alphabet_size", "alphabet_bits",
                "vocab_sizes", "vocab_bits", "best_config",
                "unsegmentable_audited"}
RTOL = 1e-3


def _reject(x):
    raise AssertionError(f"non-finite token in JSON: {x}")


@pytest.fixture(scope="session")
def raw() -> str:
    assert SUBMISSION.exists(), f"missing {SUBMISSION}"
    return SUBMISSION.read_text(encoding="utf-8")


@pytest.fixture(scope="session")
def sub(raw) -> dict:
    return json.loads(raw, parse_constant=_reject)


@pytest.fixture(scope="session")
def ref() -> dict:
    return json.loads(REFERENCE.read_text(encoding="utf-8"))


@pytest.fixture(scope="session")
def inputs():
    import pandas as pd
    corpus = pd.read_csv(DATA / "corpus.csv", dtype={"word": str})
    lex = pd.read_csv(DATA / "lexicon.csv", dtype={"word": str, "morphs": str})
    alpha = json.loads((DATA / "alphabet.json").read_text())
    return corpus, lex, alpha


@pytest.fixture(scope="session")
def narrow(tmp_path_factory) -> dict:
    """Independent implementation, run fresh against the frozen inputs."""
    out = tmp_path_factory.mktemp("cc") / "narrow.json"
    subprocess.run([sys.executable, str(CROSSCHECK), str(DATA), str(out)],
                   check=True, capture_output=True)
    return json.loads(out.read_text())


def leaves(o, p=""):
    d = {}
    if isinstance(o, dict):
        for k, v in o.items():
            d.update(leaves(v, f"{p}/{k}"))
    elif isinstance(o, list):
        for i, v in enumerate(o):
            d.update(leaves(v, f"{p}[{i}]"))
    else:
        d[p] = o
    return d


def shape(o):
    if isinstance(o, dict):
        return {k: shape(v) for k, v in sorted(o.items())}
    if isinstance(o, list):
        return ["list", len(o)] + [shape(v) for v in o[:1]]
    if isinstance(o, bool):
        return "bool"
    if isinstance(o, str):
        return "str"
    if isinstance(o, (int, float)):
        return "num"
    return type(o).__name__


def close(got, exp) -> bool:
    if exp == 0:
        return abs(got) <= RTOL
    return abs(got - exp) <= RTOL * abs(exp)


def code_bits(v: int) -> int:
    return max(1, (v - 1).bit_length())


# ------------------------------------------------------------------ V1-V3
def test_v1_file_is_strict_json(raw, sub):
    """V1: exists, decodes as UTF-8, parses as strict JSON, no NaN/Infinity."""
    for token in ("NaN", "Infinity", "-Infinity"):
        assert token not in raw, f"forbidden token {token!r} in output"
    assert isinstance(sub, dict)


def test_v2_top_level_keys(sub):
    """V2: exactly three top-level keys, no more, no fewer."""
    assert set(sub) == {"corpus_report", "drift_report", "variants"}
    assert set(sub["variants"]) == set(VARIANTS)


def test_v3_schema_matches_reference(sub, ref):
    """V3: identical nesting, container types, list lengths and leaf types.

    Catches an object emitted as an array (e.g. corpus_stats as 12 floats),
    which no tolerance check would ever reach.
    """
    assert shape(sub) == shape(ref)


# ------------------------------------------------------------------ V4-V5
def test_v4_exact_fields(sub, ref):
    """V4: counts, sizes, names and the audit field compare for equality."""
    S, R = leaves(sub), leaves(ref)
    bad = []
    for k, exp in R.items():
        leaf = k.rsplit("/", 1)[-1].split("[")[0]
        parent = k.rsplit("/", 2)[-2] if "/" in k[1:] else ""
        if leaf in EXACT_FIELDS or parent in EXACT_FIELDS \
                or isinstance(exp, (str, bool)):
            if S.get(k) != exp:
                bad.append((k, exp, S.get(k)))
    assert not bad, f"{len(bad)} exact-equality mismatches, e.g. {bad[:3]}"


def test_v5_all_floats_within_tolerance(sub, ref):
    """V5: every remaining numeric leaf within 1e-3 relative (1e-3 abs at 0)."""
    S, R = leaves(sub), leaves(ref)
    bad = []
    for k, exp in R.items():
        if isinstance(exp, (str, bool)):
            continue
        got = S.get(k)
        assert isinstance(got, (int, float)), f"{k} is not numeric"
        if not close(got, exp):
            bad.append((k, exp, got))
    assert not bad, (f"{len(bad)} of {len(R)} values outside tolerance, "
                     f"e.g. {bad[:3]}")


# ------------------------------------------------------------------ V6-V9
def test_v6_metric_algebra(sub):
    """V6: relations among the seven metrics that hold by definition."""
    for v, panel in sub["variants"].items():
        for arm in ("strategy_metrics", "control_metrics"):
            for name, m in panel[arm].items():
                tag = f"{v}/{arm}/{name}"
                assert m["mean_fertility"] >= 1.0 - 1e-9, tag
                assert m["mean_fertility"] <= m["p95_fertility"] + 1e-9, tag
                assert m["p95_fertility"] <= m["max_fertility"] + 1e-9, tag
                assert 0.0 <= m["pct_within_target"] <= 1.0, tag
                assert 0.0 <= m["boundary_f1_pct"] <= 100.0 + 1e-9, tag
                # mean_fertility / 2.0 is exactly excess_ratio by definition
                assert close(m["excess_ratio"],
                             m["mean_fertility"] / TARGET), tag


def test_v7_quantization_of_observables(sub):
    """V7: rates are counts over fixed denominators and cannot be arbitrary.

    Every block holds 800 words and there are 30 evaluation blocks, so a mean
    fertility is a multiple of 1/24000 and pct_within_target a multiple of
    1/30. A fabricated or interpolated number lands off the lattice.
    """
    step = 1.0 / (N_EVAL * N_WORDS_PER_BLOCK)
    for v, panel in sub["variants"].items():
        for arm in ("strategy_metrics", "control_metrics"):
            for name, m in panel[arm].items():
                tag = f"{v}/{arm}/{name}"
                r = m["mean_fertility"] / step
                assert abs(r - round(r)) < 1e-5, f"{tag} mean off lattice"
                s = m["pct_within_target"] * N_EVAL
                assert abs(s - round(s)) < 1e-6, f"{tag} slo off lattice"


def test_v8_significance_internal_consistency(sub):
    """V8: ranks sum to 3.0, p-values are probabilities, Nemenyi follows ranks."""
    from scipy import stats as st
    for v, panel in sub["variants"].items():
        for fam, metrics in panel["significance"].items():
            for metric, s in metrics.items():
                tag = f"{v}/{fam}/{metric}"
                assert abs(s["control_rank"] + s["treatment_rank"] - 3.0) < 1e-9, tag
                assert 0.0 <= s["t_test_p"] <= 1.0, tag
                assert 0.0 <= s["nemenyi_p"] <= 1.0, tag
                q = abs(s["treatment_rank"] - s["control_rank"]) * math.sqrt(12)
                expect = min(2.0 * st.norm.sf(q / math.sqrt(2.0)), 1.0)
                assert close(s["nemenyi_p"], expect), tag


def test_v9_cross_variant_invariants(sub):
    """V9: what a segmentation regime cannot change must not have changed.

    Merge learning, the cut constraints and the trigger stream are defined
    without reference to the regime, and chars and words do not consult a
    learned vocabulary at all. A solver that rebuilds the vocabulary inside
    the regime loop, or that lets the regime feed back into the trigger,
    breaks these and nothing else.
    """
    base = sub["variants"]["rank"]
    for v in VARIANTS[1:]:
        p = sub["variants"][v]
        for field in ("mean_merges_used", "trigger_rate",
                      "unsegmentable_audited", "n_eval_blocks"):
            assert close(p["diagnostics"][field],
                         base["diagnostics"][field]), f"{v}/{field}"
        for name in ("chars", "words"):
            for k, x in base["strategy_metrics"][name].items():
                assert close(p["strategy_metrics"][name][k], x), f"{v}/{name}/{k}"


# ---------------------------------------------------------------- V10-V11
def test_v10_cost_accounting_closed_form(sub, inputs):
    """V10: the bit accounting is recomputed from alphabet.json alone.

    No corpus statistics enter these, so a mismatch isolates the code-width
    rule and the merge-table sum from everything downstream.
    """
    _, _, alpha = inputs
    A = len(alpha["symbols"])
    cr = sub["corpus_report"]
    assert cr["alphabet_size"] == A
    assert cr["alphabet_bits"] == sum(alpha["symbol_bits"][c]
                                      for c in alpha["symbols"])
    assert cr["vocab_sizes"] == list(alpha["vocab_sizes"])
    for size in alpha["vocab_sizes"]:
        want = sum(2 * code_bits(A + j) for j in range(size))
        assert cr["vocab_bits"][str(size)] == want, size
        stats = cr["corpus_stats"][str(size)]
        assert close(stats["vocab_bits_per_word"], want / N_WORDS_PER_BLOCK)
        assert close(stats["data_bits_per_word_train_era"],
                     stats["fertility_train_era"] * code_bits(A + size))


def test_v11_character_baseline_closed_form(sub, inputs):
    """V11: the chars structure has a closed form and needs no tokenizer.

    Character segmentation predicts every interior offset, so recall is 1 and
    the block F1 is 2*gold/(pred+gold) over that block's words. Fertility is
    the mean word length of the evaluated blocks. Both follow from corpus.csv
    and lexicon.csv directly, which isolates the reading of the gold analyses
    from every learned component.
    """
    corpus, lex, alpha = inputs
    A = len(alpha["symbols"])
    gold = {}
    for w, m in zip(lex["word"], lex["morphs"]):
        acc, cs = 0, set()
        for p in m.split("+")[:-1]:
            acc += len(p)
            if 0 < acc < len(w):
                cs.add(acc)
        gold[w] = len(cs)

    blocks = sorted(corpus["block"].unique().tolist())
    by_block = {b: g["word"].tolist() for b, g in corpus.groupby("block")}
    fert, f1s = [], []
    for b in blocks[6:]:
        ws = by_block[b]
        tot = sum(len(w) for w in ws)
        npred = sum(len(w) - 1 for w in ws)
        ngold = sum(gold[w] for w in ws)
        fert.append(tot / len(ws))
        f1s.append(2.0 * ngold / (npred + ngold))
    exp_fert = sum(fert) / len(fert)
    exp_f1 = 100.0 * sum(f1s) / len(f1s)
    exp_bits = (sum(alpha["symbol_bits"][c] for c in alpha["symbols"])
                + exp_fert * code_bits(A) * N_WORDS_PER_BLOCK) / N_WORDS_PER_BLOCK

    m = sub["variants"]["rank"]["strategy_metrics"]["chars"]
    assert close(m["mean_fertility"], exp_fert), "chars fertility"
    assert close(m["boundary_f1_pct"], exp_f1), "chars boundary F1"
    assert close(m["bits_per_word"], exp_bits), "chars description length"


# ---------------------------------------------------------------- V12-V15
def test_v12_corpus_and_drift(sub, narrow):
    """V12: corpus counts, the reference vocabulary and the drift binning."""
    cr, dr = sub["corpus_report"], sub["drift_report"]
    n = narrow
    assert cr["n_blocks"] == n["corpus"]["n_blocks"]
    assert cr["n_tokens"] == n["corpus"]["n_tokens"]
    assert cr["n_types"] == n["corpus"]["n_types"]
    assert cr["n_eval_blocks"] == n["corpus"]["n_eval_blocks"]
    assert close(cr["mean_word_len"], n["corpus"]["mean_word_len"])
    assert close(cr["corpus_stats"]["320"]["fertility_train_era"],
                 n["reference"]["fertility_train_era_320"])
    assert close(cr["corpus_stats"]["600"]["fertility_final_era"],
                 n["reference"]["fertility_final_era_600"])
    assert close(cr["corpus_stats"]["320"]["renyi_train_era"],
                 n["reference"]["renyi_train_era_320"])
    assert close(dr["epoch_ks_matrix"][0][5], n["drift"]["ks_0_5"])
    assert close(dr["epoch_share_matrix"][5][5], n["drift"]["share_5_5"])
    assert close(dr["decile_share_pct"]["D9"]["E5"], n["drift"]["decile_D9_E5"])
    for row in dr["epoch_share_matrix"]:
        assert abs(sum(row) - 1.0) < 1e-9
    for e, row in enumerate(dr["conditional_epoch_share_matrix"]):
        assert abs(row[e]) < 1e-12, "conditional diagonal must be zero"
        assert abs(sum(row) - 1.0) < 1e-9


def test_v13_merge_families_and_cuts(sub, narrow):
    """V13: the two merge rules and the variety constraint, recomputed.

    ``like`` is the sensitive one: it is the only place a ratio decides an
    ordering, and an implementation that divides in floating point instead of
    cross-multiplying reorders near-ties and lands here.
    """
    sm = sub["variants"]["rank"]["strategy_metrics"]
    n = narrow["rank"]
    assert close(sm["freq_free_128"]["mean_fertility"],
                 n["freq_free_128_mean_fertility"]), "freq family"
    assert close(sm["freq_free_128"]["boundary_f1_pct"],
                 n["freq_free_128_boundary_f1_pct"]), "freq boundary F1"
    assert close(sm["freq_bidi_320"]["mean_fertility"],
                 n["freq_bidi_320_mean_fertility"]), "bidi cuts"
    assert close(sm["freq_bidi_320"]["boundary_f1_pct"],
                 n["freq_bidi_320_boundary_f1_pct"]), "bidi boundary F1"
    assert close(sm["like_free_320"]["mean_fertility"],
                 n["like_free_320_mean_fertility"]), "likelihood family"
    assert close(sm["like_free_320"]["boundary_f1_pct"],
                 n["like_free_320_boundary_f1_pct"]), "likelihood boundary F1"
    assert close(sm["freq_free_600"]["bits_per_word"],
                 n["freq_free_600_bits_per_word"]), "cost at 600 merges"


def test_v14_regimes_and_reference_structures(sub, narrow):
    """V14: the three regimes, plus words, oracle and cascade."""
    V = sub["variants"]
    assert close(V["rank"]["strategy_metrics"]["words"]["mean_fertility"],
                 narrow["rank"]["words_mean_fertility"]), "words baseline"
    assert close(V["rank"]["strategy_metrics"]["oracle"]["mean_fertility"],
                 narrow["rank"]["oracle_mean_fertility"]), "oracle"
    assert close(V["rank"]["strategy_metrics"]["cascade"]["mean_fertility"],
                 narrow["rank"]["cascade_mean_fertility"]), "cascade"
    assert close(V["rank"]["strategy_metrics"]["cascade"]["boundary_f1_pct"],
                 narrow["rank"]["cascade_boundary_f1_pct"]), "cascade F1"
    assert close(V["greedy"]["strategy_metrics"]["freq_free_128"]["mean_fertility"],
                 narrow["greedy"]["freq_free_128_mean_fertility"]), "greedy"
    assert close(V["short"]["strategy_metrics"]["freq_free_600"]["mean_fertility"],
                 narrow["short"]["freq_free_600_mean_fertility"]), "short"
    assert close(V["short"]["strategy_metrics"]["freq_bidi_320"]["boundary_f1_pct"],
                 narrow["short"]["freq_bidi_320_boundary_f1_pct"]), "short F1"


def test_v15_control_arm_rng_order(sub, narrow):
    """V15: the control arm, isolating the pinned generator consumption order.

    A submission that seeds per configuration, draws inside the configuration
    loop, permutes the type list instead of the frequency vector, or skips the
    unused gate draw reproduces every treatment number and fails here.
    """
    c = sub["variants"]["rank"]["control_metrics"]
    n = narrow["control"]
    assert close(c["freq_free_128"]["mean_fertility"],
                 n["rank_freq_free_128_mean_fertility"])
    assert close(c["freq_free_600"]["mean_fertility"],
                 n["rank_freq_free_600_mean_fertility"])
    assert close(c["freq_free_600"]["boundary_f1_pct"],
                 n["rank_freq_free_600_boundary_f1_pct"])
    assert close(c["like_free_320"]["mean_fertility"],
                 n["rank_like_free_320_mean_fertility"])
    assert close(sub["variants"]["short"]["control_metrics"]
                 ["freq_free_600"]["mean_fertility"],
                 n["short_freq_free_600_mean_fertility"])


# ---------------------------------------------------------------- V16-V18
def test_v16_segmentation_guarantee(sub):
    """V16: no structure may fail to reproduce the word it segments."""
    for v, panel in sub["variants"].items():
        assert panel["diagnostics"]["unsegmentable_audited"] == 0, v


@pytest.mark.skipif(not Path("/app/solve.py").exists(),
                    reason="no solver script to re-run")
def test_v17_stability_across_runs(raw):
    """V17: re-running the solver reproduces the submission byte for byte."""
    tmp = Path("/tmp/rerun.json")
    subprocess.run([sys.executable, "/app/solve.py", str(DATA), str(tmp)],
                   check=True, capture_output=True)
    assert tmp.read_text(encoding="utf-8") == raw, "output not reproducible"


@pytest.mark.skipif(not Path("/app/solve.py").exists(),
                    reason="no solver script to re-run")
def test_v18_not_hardcoded(tmp_path):
    """V18: perturbed inputs must change the output.

    Dropping the last block shortens the evaluation; a solver that emits
    stored constants returns n_eval_blocks unchanged and fails.
    """
    import pandas as pd
    d = tmp_path / "data"
    d.mkdir()
    for name in ("lexicon.csv", "alphabet.json"):
        (d / name).write_bytes((DATA / name).read_bytes())
    q = pd.read_csv(DATA / "corpus.csv", dtype={"word": str})
    q[q["block"] < q["block"].max()].to_csv(d / "corpus.csv", index=False)
    out = tmp_path / "perturbed.json"
    subprocess.run([sys.executable, "/app/solve.py", str(d), str(out)],
                   check=True, capture_output=True)
    got = json.loads(out.read_text())
    assert got["corpus_report"]["n_eval_blocks"] == N_EVAL - 1
