# SPEC.md — algorithm specification

Authoritative for every algorithmic choice, every fixed parameter, and the
required output structure. Nothing here is to be tuned, inferred, or
substituted.

## 1. Parameters

    service-level objective (SLO)   2.0      target fertility, tokens per word
    calibration window              6 blocks
    gate multiple                   1.25     of the SLO
    merge budget                    600      (alphabet.json: merge_budget)
    vocabulary sizes                128, 320, 600
                                             (alphabet.json: vocab_sizes)
    minimum pair count              2        (alphabet.json: min_pair_count)
                                             likelihood family only
    variety threshold               8        (alphabet.json: variety_threshold)
    epochs                          6
    drift-report bins               6 sextiles, 10 deciles
    drift-report era                blocks 0..5
    words-baseline vocabulary       600 types
    oracle vocabulary               320 merges
    cascade vocabulary              600 merges, likelihood-free learning
    Renyi order alpha               2.5
    audit steps                     0, 8, 16, 24
    control-arm RNG                 numpy.random.default_rng(11)
    control gate scale              2.0      of the SLO

Every count in this specification is an integer and every comparison that
selects a merge is an integer comparison. No floating-point value is compared
against another to decide a merge, a tie, or a cut.

## 2. Inputs

`corpus.csv` holds `token_id`, `block` and `word`: 28,800 word tokens in 36
blocks of 800, in ascending `block` order. Words are lowercase strings over the
alphabet and contain no separators.

`lexicon.csv` holds `word`, `morphs`, `n_morphs` and `word_len`, one row per
distinct word type in `corpus.csv`. `morphs` is the gold morphological analysis
as surface substrings joined by `+`; the concatenation of the parts is the word
itself. The gold interior boundaries of a word are the cumulative lengths of
its parts, excluding 0 and `len(word)`. Duplicate cumulative lengths, which a
zero-length part would produce, are counted once.

`alphabet.json` holds `symbols` (the 20 characters, in canonical order, index
being the symbol id), `symbol_bits` (an integer code length per character),
`merge_budget`, `vocab_sizes`, `min_pair_count` and `variety_threshold`.

Every character occurring in `corpus.csv` appears in `symbols`, so the
alphabet is closed over the corpus and no word is ever unsegmentable. The
files are read-only and contain no missing values.

## 3. Cost accounting

`alphabet_bits` is the sum of `symbol_bits` over all 20 characters. For a
vocabulary of `A + t` entries the flat code width is

    code_bits(v) = max(1, (v - 1).bit_length())

A merge table of `t` merges stores two live ids per merge and costs

    merge_table_bits(t) = sum over j in 0..t-1 of 2 * code_bits(A + j)

The description length of one evaluation block under a structure that learned
`t` merges and emitted `T` tokens over the block's `n_words` words is

    bits_per_word = (alphabet_bits + merge_table_bits(t) + T * code_bits(A + t))
                    / n_words

`t` is the number of merges the structure actually learned, which is not always
the nominal vocabulary size (section 5). The `chars` and `words` baselines
replace `merge_table_bits` as described in section 9.

## 4. Boundary constraints

For a set of word types, the **successor variety** of a string `p` is the
number of distinct characters that follow `p` among the types having `p` as a
proper prefix; the **predecessor variety** of a string `s` is the number of
distinct characters that precede `s` among the types having `s` as a proper
suffix. Both are computed over the type inventory of the calibration window,
unweighted by frequency, and both are integers.

An interior offset `i` of a word `w`, `1 <= i < len(w)`, is **cut** under a
scheme when

    free    never
    sv      succ(w[:i]) >= 8
    bidi    succ(w[:i]) >= 8  or  pred(w[i:]) >= 8

A merge may not join two symbols across a cut offset. Offsets are measured in
the surface string, so a merge is legal exactly when the boundary between the
two symbols it would join is not a cut.

## 5. Merge learning

Learning is over the calibration window's word types weighted by their window
token counts. Types of length 1 are dropped; they contribute no pair. Each
remaining type starts as its character sequence.

At each step the current pair counts are the frequency-weighted counts of
adjacent symbol pairs whose joining offset is not a cut. Symbol counts are the
frequency-weighted counts of symbol occurrences over the same types.

**freq** — the published rule: choose the pair of greatest count.

**like** — the likelihood rule: among pairs whose count is at least
`min_pair_count`, choose the pair maximizing `count(ab) / (count(a) * count(b))`.
The comparison is by cross-multiplication of integers,
`c1 * d2` against `c2 * d1` with `d = count(a) * count(b)`, never by division.
Pairs whose denominator is zero or non-positive are skipped.

Both families break a tie on the pair itself, taking the lexicographically
smallest `(a, b)` as a pair of strings. Learning stops early when no pair is
eligible, so `like` may return fewer merges than the budget; the shortfall is
real and is charged through `merge_table_bits`. A merged symbol is the
concatenation of its operands. All occurrences of the chosen pair at non-cut
offsets are replaced simultaneously, left to right.

A vocabulary of nominal size `s` is the first `min(s, learned)` merges of a run
to the full budget, so the three vocabulary sizes are nested prefixes of one
learning run and are not learned separately.

## 6. Segmentation regimes

A vocabulary is the alphabet followed by the merged symbols in learned order.
`max_len` is the length of the longest vocabulary entry.

**rank** — repeatedly find the adjacent pair of lowest merge rank present in
the current symbol sequence and join its **leftmost** occurrence, until no
adjacent pair is a learned merge.

**greedy** — left to right, take the longest vocabulary entry starting at the
current position, of length at most `max_len`; a single character is always
taken when nothing longer matches.

**short** — fewest tokens, by backward dynamic programming over positions,
where a span is admissible when it is a vocabulary entry or a single character.
Among segmentations attaining the minimum token count, take the one whose first
token is longest, and resolve the remainder by the same rule. Equivalently,
`cut[i]` is the largest `j` attaining `min_j (1 + best[j])`.

All three are closed over the alphabet, so every word segments.

## 7. Walk-forward evaluation

For each block `i` from 6 to 35 inclusive — 30 evaluation blocks — the
calibration window is the word tokens of blocks `i-6 .. i-1`, and block `i`'s
800 words are segmented. Everything about the structure is rebuilt from that
window; nothing about block `i` may enter its construction, except in `oracle`
(section 9).

The realized fertility of block `i` is the total number of tokens the structure
emits over the block divided by 800.

**Trigger.** A configuration is *triggered* at block `i` when its own realized
fertility under the **rank** regime at block `i-1` exceeded `1.25 * 2.0`. At
the first evaluation block no configuration is triggered. The trigger is
evaluated and recorded for every configuration, in every variant, whether or
not that variant's scheme acts on it, and it is the same stream in all three
variants because the rank regime defines it.

## 8. Families, schemes and configurations

The two families of section 5 are crossed with four schemes:

    free    no cut constraint
    sv      successor-variety cuts
    bidi    successor- and predecessor-variety cuts
    mix     bidi when triggered, free otherwise

and with the three vocabulary sizes, giving 24 sweep configurations named
`family_scheme_size`, e.g. `freq_free_128`. A `mix` configuration selects
between two learning runs that already exist at that block; it does not learn a
third.

The three **variants** are the segmentation regimes `rank`, `greedy` and
`short` of section 6. A variant changes only how a vocabulary is applied. The
merge learning, the cut constraints, the trigger stream and the control
permutation are identical across variants.

## 9. The four further structures

**chars** — the characters of the word. No merges, no vocabulary beyond the
alphabet, so `merge_table_bits` is 0 and `code_bits(A)` applies. Identical in
all three variants.

**words** — the 600 most frequent window types, ordered by count descending
then word ascending, stored whole; a word in that set is one token, any other
word is its characters. The stored table costs `len(w) * code_bits(A)` bits per
stored word in place of `merge_table_bits`, and the code width is
`code_bits(A + 600)`. Identical in all three variants.

**oracle** — `freq`, `free`, 320 merges, learned on **the 800 words of the
block being served**. It is not implementable; it bounds how much of the gap
vocabulary freshness could close.

**cascade** — the `bidi` cuts of the evaluation block's words are applied as a
hard pre-segmentation, and the `freq`/`free` 600-merge vocabulary of the window
is applied within each fragment independently. The pre-segmenter is read off
the window's type inventory and adds nothing to the merge table, so the cost is
that of 600 merges. This is not the `bidi` scheme: there the cuts constrain
learning, here they constrain only application, and the vocabulary was learned
without them.

`oracle` and `cascade` vary across variants; `chars` and `words` do not.

## 10. One-sided guarantee

Every structure here must reproduce the word it segments. Audit it: at
evaluation steps 0, 8, 16 and 24 — counting the first evaluation block as step
0 — count the words of that block whose emitted pieces do not concatenate back
to the word. The sum over every structure, every regime, every arm and every audited step is
reported as `unsegmentable_audited` and is 0 for a correct implementation. The
same total is reported in all three variants.

## 11. Control arm

The control asks what survives if a word's *identity* is decoupled from its
*frequency* while the frequency distribution itself is kept exactly. Using
`numpy.random.default_rng(11)`, consumed in exactly this order:

  * one `rng.permutation(n_types)` per evaluation block, in ascending block
    order, where `n_types` is the number of distinct word types in that
    block's calibration window — 30 draws;
  * then a single `rng.random(30)`, the control gate statistic, scaled by
    `2.0 * 2.0`.

At block `i`, let `types` be the window's distinct words in ascending string
order and `freqs` their window counts in the same order. The control assigns
`types[j]` the count `freqs[perm[j]]`. The type inventory, and therefore every
successor- and predecessor-variety count, is unchanged; only the counts move.

In the control arm the trigger of section 7 is replaced by
`gate_draw[step] > 1.25 * 2.0`, identically for every configuration. The gate
draw is consumed whether or not a configuration's scheme acts on it.

Every one of the 24 sweep configurations plus `cascade` and `words` is rerun
against the permuted counts. `chars` uses no frequency information at all and
`oracle` is already an upper bound, so neither has a control arm.

## 12. Metrics

On a configuration's 30 per-block fertilities `r`, its 30 per-block description
lengths `d` and its 30 per-block boundary agreements `g`:

    mean_fertility      mean(r)
    p95_fertility       95th percentile of r, linear interpolation
    max_fertility       max(r)
    pct_within_target   fraction of blocks with r <= 2.0
    excess_ratio        mean(r) / 2.0
    bits_per_word       mean(d)
    boundary_f1_pct     mean(g) * 100

`g` is micro-averaged within the block: over the block's 800 words, `tp` is the
number of predicted interior offsets that are gold, `n_pred` the number
predicted and `n_gold` the number of gold offsets; then
`g = 2pr / (p + r)` with `p = tp / n_pred` and `r = tp / n_gold`, and `g = 0`
when `tp`, `n_pred` or `n_gold` is 0.

Renyi efficiency of a token unigram count vector, used only in section 14, is

    H_alpha = log(sum p^alpha) / (1 - alpha),   efficiency = H_alpha / log(K)

over the `K` distinct tokens with positive count, at `alpha = 2.5`, and 0 when
`K < 2`.

## 13. Significance

Within a variant, each of the two families contributes 12 configurations. Each
is paired with the identically named control configuration. Four metrics are
tested, in this order:

    mean_fertility      lower is better
    p95_fertility       lower is better
    bits_per_word       lower is better
    boundary_f1_pct     higher is better

Values of a lower-is-better metric are negated before the test, so the
alternative hypothesis is always "treatment exceeds control". Report:

    t_test_p         scipy.stats.ttest_rel(treatment, control,
                     alternative="greater").pvalue over the 12 pairs
    control_rank     mean within-pair rank of the control arm
    treatment_rank   mean within-pair rank of the treatment arm
    nemenyi_p        two-method Nemenyi post-hoc p-value

Within a pair the better value ranks 2, the worse 1, and a tie ranks both 1.5,
so the two mean ranks always sum to 3.0. With k = 2 methods and N = 12 pairs
the studentized range reduces to a normal tail:

    q         = |treatment_rank - control_rank| * sqrt(N)
    nemenyi_p = min(2 * norm.sf(q / sqrt(2)), 1.0)

## 14. Output structure

`/app/results.json` is a single JSON object with exactly three top-level keys.

**corpus_report**

    n_blocks, n_tokens, n_types, n_eval_blocks, n_window_blocks,
    alphabet_size, alphabet_bits                  integers
    vocab_sizes                                   [128, 320, 600]
    vocab_bits            "128","320","600" -> integer, merge_table_bits at
                          the nominal size
    mean_word_len         float, over all 28,800 tokens
    corpus_stats          "128","320","600" -> twelve floats

The twelve are `vocab_bits_per_word`, `data_bits_per_word_train_era`,
`data_bits_per_word_final_era`, `subword_ttr_train_era`,
`mean_token_len_train_era`, `fertility_train_era`, `fertility_final_era`,
`boundary_f1_train_era`, `boundary_f1_final_era`, `renyi_train_era`,
`renyi_final_era`, `merges_used`.

They come from one reference vocabulary: `freq`, `free`, learned on the **train
era**, blocks 0..5, to the full budget and sliced to each size, applied under
the **rank** regime. The train era is blocks 0..5 and the final era blocks
30..35; both eras use that same train-era vocabulary, which is what makes the
pair of eras a staleness measurement. `vocab_bits_per_word` is
`merge_table_bits(merges_used) / 800`; `data_bits_per_word_*` is that era's
fertility times `code_bits(A + merges_used)`; `subword_ttr_train_era` is
distinct emitted tokens over total emitted tokens on the train era;
`mean_token_len_train_era` is the mean character length of an emitted token;
`boundary_f1_*` is section 12's `g`, micro-averaged over the whole era, times
100; `merges_used` is reported as a float.

**drift_report**

Six epochs of 6 consecutive blocks each; the epoch of block `b` is
`min(b // 6, 5)`. All four quantities use one integer statistic per token: the
**train-era frequency rank** of that token's word type. Train-era types are
ordered by count descending then word ascending and numbered from 1; a type
absent from the train era takes rank `n_train_types + 1`.

    epoch_share_matrix              6x6, rows = epochs, each row sums to 1
    conditional_epoch_share_matrix  the same with the diagonal zeroed and rows
                                    renormalized
    epoch_ks_matrix                 6x6, pairwise two-sample KS statistics,
                                    zero on the diagonal
    decile_share_pct                "D0".."D9" -> "E0".."E5" -> percent

`epoch_share_matrix[e][s]` is the fraction of epoch `e`'s tokens falling in
sextile `s`. Bin edges are the interior quantiles of the **train-era** token
statistic at levels `i / n_bins`, linearly interpolated, and a token is
assigned by `searchsorted(edges, value, side="right")`. `decile_share_pct` is
the same construction with ten bins, transposed, in percent. A row of the
conditional matrix that sums to zero becomes uniform at `1 / 5`. KS statistics
are the asymptotic two-sample statistic.

**variants**

Exactly the sub-keys `rank`, `greedy`, `short`. Each contains exactly:

    diagnostics        n_eval_blocks, mean_merges_used, trigger_rate,
                       mean_boundary_f1_pct, best_config, best_mean_fertility,
                       best_bits_per_word, saving_vs_chars_pct,
                       unsegmentable_audited
    strategy_metrics   28 entries: the 24 sweep configurations plus cascade,
                       chars, words, oracle
    control_metrics    26 entries: the 24 sweep configurations plus cascade
                       and words
    significance       freq, like -> the four metrics of section 13 ->
                       control_rank, treatment_rank, t_test_p, nemenyi_p

`mean_merges_used` averages, over the 24 sweep configurations and their 30
blocks, the number of merges actually learned; `trigger_rate` averages the
recorded trigger over the same 24 by 30 grid; `mean_boundary_f1_pct` averages
`boundary_f1_pct` over the 24. All three exclude the four further structures.
Because merge learning and the trigger stream do not depend on the regime,
`mean_merges_used` and `trigger_rate` are identical in all three variants, as
are the `chars` and `words` entries.

`best_config` is the sweep configuration with the smallest `mean_fertility`,
ties broken by the lexicographically smallest name. `best_mean_fertility` and
`best_bits_per_word` are that configuration's values and
`saving_vs_chars_pct` is
`(chars_bits_per_word - best_bits_per_word) / chars_bits_per_word * 100`
in the same variant.

Every entry in `strategy_metrics` and `control_metrics` contains exactly the
seven metric keys of section 12.

## 15. Conventions

Percentiles interpolate linearly. `floor` truncates toward negative infinity.
Standard deviations do not appear. Lexicographic order on strings is Python's
default over the characters. Sorting of word types is ascending string order
throughout, and it is the order the control permutation is applied in.

## 16. What the gold file does and does not license

`lexicon.csv` is used for exactly one thing: the boundary agreement of section
12. No quantity that selects a merge, a cut, a threshold or a configuration may
consult it, and `best_config` is chosen on fertility alone. Fertility and
description length are observable without any annotation, which is why the
three of them are reported side by side: the study is about whether the two
unannotated quantities rank vocabularies the way the annotated one does.

Counts are integers, merge selection is by integer comparison, and the only
randomness is the control permutation under a pinned generator. No reported
quantity depends on floating-point summation order, BLAS threading, or libm
version. Reruns are bitwise identical.
