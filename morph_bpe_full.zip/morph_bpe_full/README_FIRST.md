# README_FIRST.md

A benchmark task package. The deliverable is `task/`; `research/` is the study
it was cut from and must not be shipped with the task.

## Layout

    task/
      PROMPT.txt                        what the solver is given
      SPEC.md                           authoritative: every quantity, every
                                        parameter, the output structure
      SCHEMA_superseded.md              a stub; the schema lives in SPEC.md §14
      data/
        corpus.csv                      28,800 word tokens, 36 blocks of 800
        lexicon.csv                     11,469 types with gold morph analyses
        alphabet.json                   20 symbols, code lengths, parameters
      expected_results.json             the reference object, 1,475 leaves
      solution/solve_full.py            reference solver (imports research/)
      crosscheck/solve_narrow_crosscheck.py
                                        independent re-derivation of 39
                                        quantities from SPEC.md alone
      tests/test_outputs.py             18 checks, V1-V18

    research/
      NOT_THE_SOLUTION.md               framing, findings, disclosed choices
      morph_bpe/
        src/                            data, merges, apply, metrics,
                                        evaluate, report
        build_data.py                   regenerates task/data/
        robustness.py                   re-runs the study on a fresh seed
        robustness/seed_*.json          three seeds, summarized
        notebook.ipynb                  the executed study

## The task in one paragraph

Given a drifting corpus of an agglutinative language with gold morpheme
analyses, fit subword vocabularies on a rolling six-block window and tokenize
the block that follows. Two merge-scoring families (maximum frequency;
likelihood ratio) cross four boundary-constraint schemes and three vocabulary
sizes, giving 24 configurations; each is applied under three segmentation
regimes and paired against a control arm that permutes the window's
type-frequency vector. Report fertility, total description length with the
merge table charged, and morpheme-boundary agreement, plus paired significance
against the control.

## Running it

    python task/solution/solve_full.py task/data /tmp/results.json   # ~80 s
    python -m pytest -q task/tests/test_outputs.py                   # ~46 s

The suite defaults to `/app/results.json` and falls back to
`expected_results.json` for local runs. Set `SUBMISSION` to point it elsewhere.
`V17` and `V18` are skipped unless `/app/solve.py` exists.

## Why it is hard to fake

The verifier has five independent layers and no single one of them is the
check.

* **V1-V5** shape and reference comparison, 1e-3 relative.
* **V6-V9** internal consistency with no reference: metric algebra; a
  quantization lattice (fertility is a count over 30 x 800, so it is a multiple
  of 1/24000 and a fabricated value lands off it); Nemenyi recomputed from the
  reported ranks; and cross-variant invariants, since merge learning and the
  trigger stream are regime-independent by construction and `chars` and `words`
  must be identical in all three.
* **V10-V11** closed forms from the inputs alone. The bit accounting follows
  from `alphabet.json` with no corpus statistics, and the character baseline has
  an exact closed form — character segmentation predicts every interior offset,
  so its block F1 is `2*gold/(pred+gold)` straight out of `lexicon.csv`.
* **V12-V15** an independent implementation, written from the spec text with a
  different merge-update strategy, agreeing on 39 quantities to 0.0e+00 (max
  observed 2.8e-14, float summation order in an F1 mean).
* **V16-V18** the one-sided guarantee, byte-identical reruns, and a perturbed
  input that must move `n_eval_blocks`.

Mutation-tested: a 1% float shift, a control arm set equal to its treatment, a
regime-dependent leak into `chars`, an off-lattice 1e-6 nudge, a two-bit error
in `vocab_bits`, a non-zero audit, and an inconsistent rank each fail, and each
is caught by more than one layer except the 1e-6 nudge, which only V7 sees.

## Known sharp edges

Vocabularies are charged for the merges they actually learned, not for their
nominal size (§5, §14). On the frozen corpus this provision never binds — every
window reaches 600 merges — so a solver that assumes the nominal size passes
here and breaks on the perturbed input of V18. It is specified because it binds
at tighter variety thresholds, where the likelihood family exhausts its eligible
pair set at 305-431 merges.

The control arm is the fragile part. It permutes the *frequency vector* across
the window's types, not the type list, and it consumes the gate draw in all
three regimes including the two whose schemes may never act on it. Getting this
wrong reproduces every treatment number and fails only V15.

## Provenance of the parameters

One parameter was fitted against the gold file: `variety_threshold = 8`, swept
over 3-12 on the first window before any result was computed. It is disclosed in
`research/NOT_THE_SOLUTION.md` §5 along with the two other tuned constants and
the reason each was set where it was.
