"""Assemble the study notebook from source cells, then execute it."""

from __future__ import annotations

import sys
from pathlib import Path

import nbformat as nbf
from nbclient import NotebookClient

HERE = Path(__file__).resolve().parent

CELLS = [
    ("md", """# Morphological alignment of subword vocabularies under lexical drift

A replication and critique of three claims that travel with subword
tokenization: that greedy frequency merging recovers morphology, that
compression metrics rank tokenizers, and that the segmentation rule applied at
inference is a detail.

This notebook reads the frozen study output. It computes nothing that
`task/expected_results.json` does not already contain, except the corpus
figures in section 1, which come straight from `task/data/`.

Framing, disclosed parameter choices and the seed sweep are in
`../NOT_THE_SOLUTION.md`."""),

    ("code", """import json, sys
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path.cwd().resolve()
while not (ROOT / "task").exists() and ROOT != ROOT.parent:
    ROOT = ROOT.parent
DATA = ROOT / "task" / "data"

R = json.loads((ROOT / "task" / "expected_results.json").read_text())
corpus = pd.read_csv(DATA / "corpus.csv", dtype={"word": str})
lex = pd.read_csv(DATA / "lexicon.csv", dtype={"word": str, "morphs": str})
alpha = json.loads((DATA / "alphabet.json").read_text())

CR, DR, V = R["corpus_report"], R["drift_report"], R["variants"]
SWEEP = [k for k in V["rank"]["strategy_metrics"]
         if k not in ("chars", "words", "oracle", "cascade")]
print(f'{CR["n_tokens"]:,} tokens, {CR["n_types"]:,} types, '
      f'{CR["n_blocks"]} blocks, {CR["n_eval_blocks"]} evaluation blocks')
print(f'mean surface length {CR["mean_word_len"]:.2f}, '
      f'mean morphs per type {lex["n_morphs"].mean():.2f}')"""),

    ("md", """## 1. The corpus

Words are built as `(prefix) root (root) suffix*` over frozen inventories and
then rewritten at every morph junction by three boundary rules — vowel hiatus
deletion, degemination, and the transparent case. The rewrites are what stop
the surface string from exposing its own segmentation, so the gold cut offsets
have to be carried through the rewriting rather than recovered from it.

Drift is lexical: the six epochs share the root inventory but rotate and
sharpen the field mixture, and suffix productivity rises across the corpus."""),

    ("code", """train_types = set(corpus[corpus["block"] < 6]["word"])
rows = []
for e in range(6):
    blk = corpus[(corpus["block"] >= e * 6) & (corpus["block"] < e * 6 + 6)]
    rows.append({
        "epoch": e,
        "novel_token_rate": np.mean([w not in train_types for w in blk["word"]]),
        "types": blk["word"].nunique(),
        "mean_len": blk["word"].str.len().mean(),
    })
drift_tbl = pd.DataFrame(rows).set_index("epoch")
display(drift_tbl.round(3))

hapax = sum(1 for v in Counter(corpus["word"]).values() if v == 1)
print(f"hapax types: {hapax:,} of {CR['n_types']:,} "
      f"({100*hapax/CR['n_types']:.1f}%)")
print(f"epoch 0 vs epoch 5 KS on train-era rank: "
      f"{DR['epoch_ks_matrix'][0][5]:.3f}")"""),

    ("code", """fig, ax = plt.subplots(1, 2, figsize=(11, 3.6))
m = np.array(DR["epoch_share_matrix"])
im = ax[0].imshow(m, cmap="viridis", vmin=0, vmax=m.max())
ax[0].set_xlabel("sextile of train-era frequency rank")
ax[0].set_ylabel("epoch")
ax[0].set_title("where each epoch's mass sits")
fig.colorbar(im, ax=ax[0], fraction=0.046)
ax[1].plot(range(6), m[:, -1], "o-", label="rarest sextile")
ax[1].plot(range(6), m[:, 0], "s-", label="most frequent sextile")
ax[1].set_xlabel("epoch"); ax[1].set_ylabel("share of tokens")
ax[1].set_title("mass migrates to the tail"); ax[1].legend()
plt.tight_layout(); plt.show()"""),

    ("md", """## 2. Charging the codebook

Fertility is one term of a two-term objective. The other is the merge table:
600 merges cost 10,206 bits, or 12.76 bits per word amortized over an
800-word block. A comparison that reports fertility alone is reporting the
term that always prefers more merges."""),

    ("code", """rows = []
for name in sorted(SWEEP):
    m = V["rank"]["strategy_metrics"][name]
    fam, sch, size = name.split("_")
    rows.append({"config": name, "family": fam, "scheme": sch,
                 "size": int(size), "fertility": m["mean_fertility"],
                 "bits_per_word": m["bits_per_word"],
                 "boundary_f1": m["boundary_f1_pct"],
                 "within_slo": m["pct_within_target"]})
sweep = pd.DataFrame(rows).set_index("config")

fert_opt = sweep["fertility"].idxmin()
len_opt = sweep["bits_per_word"].idxmin()
f1_opt = sweep["boundary_f1"].idxmax()
print(f"fertility optimum        {fert_opt:16s} "
      f"{sweep.loc[fert_opt,'fertility']:.3f} tok/word, "
      f"{sweep.loc[fert_opt,'bits_per_word']:.2f} bits/word")
print(f"description-length optimum {len_opt:14s} "
      f"{sweep.loc[len_opt,'fertility']:.3f} tok/word, "
      f"{sweep.loc[len_opt,'bits_per_word']:.2f} bits/word")
print(f"boundary-F1 optimum      {f1_opt:16s} "
      f"{sweep.loc[f1_opt,'boundary_f1']:.1f}% F1")
pen = (sweep.loc[fert_opt, "bits_per_word"] - sweep.loc[len_opt, "bits_per_word"])
print(f"\\ncost of following the fertility ranking: "
      f"{100*pen/sweep.loc[len_opt,'bits_per_word']:.1f}% more bits per word")"""),

    ("code", """fig, ax = plt.subplots(figsize=(7, 4.6))
for fam, mk in (("freq", "o"), ("like", "^")):
    s = sweep[sweep["family"] == fam]
    ax.scatter(s["fertility"], s["bits_per_word"], marker=mk, s=48,
               label=fam, alpha=0.85)
for name in (fert_opt, len_opt, f1_opt):
    ax.annotate(name, (sweep.loc[name, "fertility"],
                       sweep.loc[name, "bits_per_word"]),
                fontsize=8, xytext=(5, 4), textcoords="offset points")
ch = V["rank"]["strategy_metrics"]["chars"]
ax.axhline(ch["bits_per_word"], ls="--", lw=1, color="grey")
ax.text(sweep["fertility"].max(), ch["bits_per_word"] + 0.4,
        "character baseline", ha="right", fontsize=8, color="grey")
ax.set_xlabel("mean fertility (tokens per word)")
ax.set_ylabel("bits per word, merge table charged")
ax.set_title("the two objectives disagree")
ax.legend(); plt.tight_layout(); plt.show()"""),

    ("md", """## 3. The control arm

The control permutes the window's type-frequency vector across the window's
types. Every type still appears, the Zipf curve is preserved exactly, and the
successor- and predecessor-variety counts — being unweighted over the type set
— are bit-for-bit unchanged. What is destroyed is the association between
which word a type is and how often it occurs.

If merges still land on morpheme boundaries under that permutation, they were
never using frequency."""),

    ("code", """rows = []
for regime in ("rank", "greedy", "short"):
    for fam in ("freq", "like"):
        s = V[regime]["significance"][fam]["boundary_f1_pct"]
        rows.append({"regime": regime, "family": fam,
                     "t_test_p": s["t_test_p"],
                     "treatment_rank": s["treatment_rank"],
                     "nemenyi_p": s["nemenyi_p"]})
sig = pd.DataFrame(rows)
display(sig.round(4))

print("boundary F1, treatment vs frequency-permuted control (rank regime):")
for name in ("freq_free_320", "freq_free_600", "freq_bidi_320",
             "like_free_320", "like_free_600"):
    t = V["rank"]["strategy_metrics"][name]["boundary_f1_pct"]
    c = V["rank"]["control_metrics"][name]["boundary_f1_pct"]
    print(f"  {name:16s} {t:5.1f}  vs  {c:5.1f}   "
          f"{'control wins' if c > t else ''}")"""),

    ("md", """The `freq` family does not separate from its control on boundary
agreement in any regime, and on several configurations the permuted control
scores higher. The `like` family separates everywhere. The likelihood objective
genuinely depends on which word is frequent; greedy maximum-frequency merging,
on this corpus, does not — its alignment comes from the type inventory it is
fitted to, which the control preserves.

This is a null result for the claim that BPE's frequency signal recovers
morphology, and it is the study's central finding."""),

    ("md", """## 4. Application, staleness, and where the structure has to go in

Three regimes, one vocabulary each. The spread is small for fertility and
larger for boundary agreement, which matters for anyone comparing tokenizers
on morphological criteria without reporting an inference rule."""),

    ("code", """rows = []
for name in ("freq_free_600", "freq_bidi_320", "like_bidi_600",
             "cascade", "oracle", "chars", "words"):
    r = {"structure": name}
    for regime in ("rank", "greedy", "short"):
        m = V[regime]["strategy_metrics"][name]
        r[f"{regime}_fert"] = m["mean_fertility"]
        r[f"{regime}_f1"] = m["boundary_f1_pct"]
    rows.append(r)
display(pd.DataFrame(rows).set_index("structure").round(3))

o = V["rank"]["strategy_metrics"]["oracle"]
s320 = V["rank"]["strategy_metrics"]["freq_free_320"]
print(f'\\nstaleness: oracle {o["mean_fertility"]:.3f} vs stale 320 '
      f'{s320["mean_fertility"]:.3f} '
      f'({100*(s320["mean_fertility"]-o["mean_fertility"])/s320["mean_fertility"]:.1f}% better), '
      f'at {o["bits_per_word"]:.2f} vs {s320["bits_per_word"]:.2f} bits/word')

cas = V["rank"]["strategy_metrics"]["cascade"]
bidi = V["rank"]["strategy_metrics"]["freq_bidi_320"]
print(f'constraint at inference (cascade) {cas["mean_fertility"]:.3f} tok/word, '
      f'{cas["boundary_f1_pct"]:.1f}% F1')
print(f'constraint at learning  (bidi)    {bidi["mean_fertility"]:.3f} tok/word, '
      f'{bidi["boundary_f1_pct"]:.1f}% F1')"""),

    ("md", """## 5. Do the findings survive reseeding?

Three independent draws of the morphological grammar, each re-run end to end.
The point is not to average them — it is to check that the sign of each
finding is stable."""),

    ("code", """rb = sorted((ROOT / "research" / "morph_bpe" / "robustness").glob("seed_*.json"))
rows = []
for p in rb:
    d = json.loads(p.read_text())
    r = d["rank"]
    rows.append({"seed": d["seed"], "fertility_opt": r["fertility_optimal"],
                 "length_opt": r["length_optimal"],
                 "bits_penalty_%": r["bits_penalty_pct"],
                 "f1_opt": r["f1_optimal"],
                 "freq_control_p": r["freq_f1_control_p"],
                 "like_control_p": r["like_f1_control_p"],
                 "regime_spread_%": d["regime_spread_pct"]})
display(pd.DataFrame(rows).set_index("seed").round(4))"""),

    ("md", """All four signs hold across seeds: the two optima always differ, the
penalty for following fertility is 32-38%, the boundary-F1 optimum is always a
variety-constrained configuration, the `freq` family never separates from its
control (p = 0.47, 0.32, 0.85) and the `like` family always does
(p < 5e-4). The regime spread stays under 1%.

### Limitations

Purely concatenative morphology with three rewrite rules is Turkish or Finnish
on a good day, not Arabic and not Georgian. These are findings about
agglutinative morphology under lexical drift at a 4,800-token fitting window;
templatic and fusional systems would need a different generator. The corpus
size is also what makes the codebook charge bite as hard as it does — the
direction of finding 1 is a scale-dependent claim, and the scale is stated."""),
]


def build() -> nbf.NotebookNode:
    nb = nbf.v4.new_notebook()
    nb.cells = [nbf.v4.new_markdown_cell(s) if k == "md"
                else nbf.v4.new_code_cell(s) for k, s in CELLS]
    nb.metadata = {"kernelspec": {"display_name": "Python 3",
                                  "language": "python", "name": "python3"},
                   "language_info": {"name": "python"}}
    return nb


if __name__ == "__main__":
    out = HERE / "notebook.ipynb"
    nb = build()
    NotebookClient(nb, timeout=600, kernel_name="python3",
                   resources={"metadata": {"path": str(HERE)}}).execute()
    nbf.write(nb, out)
    print(f"wrote {out}")
    sys.exit(0)
