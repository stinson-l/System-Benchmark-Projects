"""
Robustness sweep.

The reported study runs on one frozen corpus. Every claim it makes is a claim
about that corpus unless it survives regeneration, so this re-runs the whole
pipeline on a fresh draw of the morphological grammar and records only the
statements the write-up actually makes.

    python robustness.py <seed> [out_dir]

The point is not to average the seeds together. It is to check that the sign
of each finding is stable -- that the fertility-optimal and description-length-
optimal vocabularies really do differ, that boundary agreement really does peak
away from both, and that the frequency-permutation control really does fail to
separate from the frequency family. A finding that flips under reseeding is a
property of one draw and is reported as such.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from src.data import ALPHABET, generate_corpus, load_corpus  # noqa: E402
from src.evaluate import Engine                              # noqa: E402
from src.report import build_results                         # noqa: E402


def build(seed: int, tmp: Path):
    import math
    from collections import Counter
    corpus, lex = generate_corpus(36, 800, seed=seed)
    tmp.mkdir(parents=True, exist_ok=True)
    corpus.to_csv(tmp / "corpus.csv", index=False)
    lex.to_csv(tmp / "lexicon.csv", index=False)
    chars = Counter("".join(corpus[corpus["block"] < 6]["word"].tolist()))
    tot = sum(chars.values())
    bits = {c: int(min(8, max(3, math.ceil(-math.log2(chars.get(c, 1) / tot)))))
            for c in ALPHABET}
    (tmp / "alphabet.json").write_text(json.dumps({
        "symbols": ALPHABET, "symbol_bits": bits, "merge_budget": 600,
        "vocab_sizes": [128, 320, 600], "min_pair_count": 2,
        "variety_threshold": 8}, indent=1, sort_keys=True))
    return tmp


def summarize(res: dict) -> dict:
    out = {}
    for regime, panel in res["variants"].items():
        sm = panel["strategy_metrics"]
        sweep = {k: v for k, v in sm.items()
                 if k not in ("chars", "words", "oracle", "cascade")}
        by_fert = min(sweep, key=lambda k: (sweep[k]["mean_fertility"], k))
        by_bits = min(sweep, key=lambda k: (sweep[k]["bits_per_word"], k))
        by_f1 = max(sweep, key=lambda k: (sweep[k]["boundary_f1_pct"], k))
        out[regime] = {
            "fertility_optimal": by_fert,
            "fertility_optimal_bits": sweep[by_fert]["bits_per_word"],
            "length_optimal": by_bits,
            "length_optimal_bits": sweep[by_bits]["bits_per_word"],
            "optima_differ": by_fert != by_bits,
            "bits_penalty_pct": (sweep[by_fert]["bits_per_word"]
                                 - sweep[by_bits]["bits_per_word"])
            / sweep[by_bits]["bits_per_word"] * 100.0,
            "f1_optimal": by_f1,
            "f1_optimal_f1": sweep[by_f1]["boundary_f1_pct"],
            "f1_at_fertility_optimal": sweep[by_fert]["boundary_f1_pct"],
            "freq_f1_control_p": panel["significance"]["freq"]
                                      ["boundary_f1_pct"]["t_test_p"],
            "like_f1_control_p": panel["significance"]["like"]
                                      ["boundary_f1_pct"]["t_test_p"],
            "chars_bits": sm["chars"]["bits_per_word"],
            "oracle_fertility": sm["oracle"]["mean_fertility"],
            "stale_320_fertility": sm["freq_free_320"]["mean_fertility"],
        }
    r = out["rank"]
    g = out["greedy"]
    s = out["short"]
    out["regime_spread_pct"] = (max(x["fertility_optimal_bits"]
                                    for x in (r, g, s))
                                - min(x["fertility_optimal_bits"]
                                      for x in (r, g, s))) / \
        r["fertility_optimal_bits"] * 100.0
    return out


def main(argv):
    seed = int(argv[1])
    out_dir = Path(argv[2] if len(argv) > 2 else "robustness")
    out_dir.mkdir(parents=True, exist_ok=True)
    data = build(seed, out_dir / f"data_{seed}")
    res = build_results(Engine(*load_corpus(data)))
    summary = summarize(res)
    summary["seed"] = seed
    (out_dir / f"seed_{seed}.json").write_text(
        json.dumps(summary, indent=1, sort_keys=True))
    print(json.dumps(summary["rank"], indent=1, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
