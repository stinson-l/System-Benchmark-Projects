"""
Walk-forward evaluation.

A vocabulary is fitted to a six-block window and used to tokenize the block
that follows it, never a block it saw. Thirty such steps make the staleness of
a subword vocabulary measurable rather than assumed.

The control arm is the load-bearing piece. It permutes the window's
type-frequency vector across the window's types: the Zipf curve, the type
inventory and the successor-variety constraints are all preserved exactly, and
only the association between a word's identity and its frequency is destroyed.
A vocabulary that still recovers morpheme boundaries under that permutation
was never recovering morphology; it was recovering the shape of the frequency
distribution. The generator is consumed in a fixed order so that the arm is
reproducible without pinning anything about the treatment.
"""

from __future__ import annotations

from collections import Counter, defaultdict

import numpy as np

from .apply import boundaries, cascade_segment, segment
from .data import gold_boundaries
from .merges import (blocked_offsets, train_merges, variety_maps,
                     vocab_from_merges)
from .metrics import (TARGET_FERTILITY, code_bits, f1, merge_table_bits,
                      summarize)

WINDOW = 6
N_EPOCHS = 6
FAMILIES = ("freq", "like")
SCHEMES = ("free", "sv", "bidi", "mix")
BASE_SCHEMES = ("free", "sv", "bidi")
REGIMES = ("rank", "greedy", "short")
GATE_MULT = 1.25
CONTROL_SEED = 11
CONTROL_SCALE = 2.0
AUDIT_STEPS = (0, 8, 16, 24)
WORDS_VOCAB = 600
ORACLE_SIZE = 320


def config_names(sizes):
    return [f"{f}_{s}_{v}" for f in FAMILIES for s in SCHEMES for v in sizes]


class Engine:
    def __init__(self, corpus, lex, alpha):
        self.alphabet = list(alpha["symbols"])
        self.alphabet_bits = int(sum(alpha["symbol_bits"][c]
                                     for c in self.alphabet))
        self.sizes = [int(v) for v in alpha["vocab_sizes"]]
        self.budget = int(alpha["merge_budget"])
        self.min_pair_count = int(alpha["min_pair_count"])
        self.threshold = int(alpha["variety_threshold"])
        self.A = len(self.alphabet)

        self.blocks = sorted(corpus["block"].unique().tolist())
        self.n_blocks = len(self.blocks)
        self.words = {b: g["word"].tolist()
                      for b, g in corpus.groupby("block", sort=True)}
        self.block_size = len(self.words[self.blocks[0]])
        self.n_tokens = int(len(corpus))
        self.gold = gold_boundaries(lex)
        self.n_types = int(lex.shape[0])

        self.eval_blocks = self.blocks[WINDOW:]
        self.n_eval = len(self.eval_blocks)

        self._merge_bits = [0]
        for t in range(self.budget + WORDS_VOCAB + 1):
            self._merge_bits.append(self._merge_bits[-1]
                                    + 2 * code_bits(self.A + t))

        self.results = {}          # (arm, regime, name) -> per-block lists
        self.trigger = {}          # (arm, name) -> per-block bool
        self.merges_used = {}      # (arm, regime, name) -> per-block ints
        self.unsegmentable = 0
        self._names = config_names(self.sizes)

    # ------------------------------------------------------------- helpers

    def vocab_bits(self, n_merges: int) -> int:
        return self._merge_bits[n_merges]

    def _cost(self, n_merges: int, n_tokens: int) -> float:
        v = self.A + n_merges
        return (self.alphabet_bits + self.vocab_bits(n_merges)
                + n_tokens * code_bits(v)) / self.block_size

    def _score_block(self, block, pieces_of):
        """Fertility, description length and boundary agreement for a block."""
        tot = tp = npred = ngold = 0
        bad = 0
        ws = self.words[block]
        for w in ws:
            pcs = pieces_of[w]
            tot += len(pcs)
            if "".join(pcs) != w:
                bad += 1
            g = self.gold[w]
            b = boundaries(pcs)
            tp += len(b & g)
            npred += len(b)
            ngold += len(g)
        return tot, f1(tp, npred, ngold), bad

    def _segment_all(self, types, regime, rank, vset, max_len):
        return {w: segment(w, regime, rank, vset, max_len) for w in types}

    # --------------------------------------------------------------- main

    def run(self):
        rng = np.random.default_rng(CONTROL_SEED)

        window_types = []
        for b in self.eval_blocks:
            ws = []
            for k in range(b - WINDOW, b):
                ws.extend(self.words[k])
            window_types.append(sorted(set(ws)))

        perms = [rng.permutation(len(t)) for t in window_types]
        gate = rng.random(self.n_eval) * (CONTROL_SCALE * TARGET_FERTILITY)

        trig = {(a, n): False for a in ("treatment", "control")
                for n in self._names}
        store = defaultdict(list)
        merges_seen = defaultdict(list)
        trig_log = defaultdict(list)

        for step, b in enumerate(self.eval_blocks):
            types = window_types[step]
            wcount = Counter()
            for k in range(b - WINDOW, b):
                wcount.update(self.words[k])
            succ, pred = variety_maps(types)
            block_types = sorted(set(self.words[b]))
            cuts = {w: blocked_offsets(w, "bidi", succ, pred, self.threshold)
                    for w in block_types}
            audit = step in AUDIT_STEPS

            freqs = [wcount[t] for t in types]
            perm = perms[step]
            ctrl_count = {types[j]: freqs[perm[j]] for j in range(len(types))}

            for arm, counts in (("treatment", dict(wcount)),
                                ("control", ctrl_count)):
                learned = {}
                for fam in FAMILIES:
                    for sch in BASE_SCHEMES:
                        learned[(fam, sch)] = train_merges(
                            counts, self.budget, fam, sch, succ, pred,
                            self.threshold, self.min_pair_count)

                seg_cache = {}

                def pieces(fam, sch, size, regime):
                    key = (fam, sch, size, regime)
                    if key not in seg_cache:
                        ml = learned[(fam, sch)][:size]
                        vocab, rank, vset = vocab_from_merges(self.alphabet, ml)
                        mx = max(len(v) for v in vocab)
                        seg_cache[key] = (
                            self._segment_all(block_types, regime, rank,
                                              vset, mx), len(ml))
                    return seg_cache[key]

                new_trig = {}
                for fam in FAMILIES:
                    for sch in SCHEMES:
                        for size in self.sizes:
                            name = f"{fam}_{sch}_{size}"
                            eff = sch
                            if sch == "mix":
                                eff = "bidi" if trig[(arm, name)] else "free"
                            fert_rank = 0.0
                            for regime in REGIMES:
                                pmap, m_used = pieces(fam, eff, size, regime)
                                tot, bf1, bad = self._score_block(b, pmap)
                                if audit:
                                    self.unsegmentable += bad
                                store[(arm, regime, name)].append(
                                    (tot / self.block_size,
                                     self._cost(m_used, tot), bf1))
                                if regime == "rank":
                                    merges_seen[(arm, name)].append(m_used)
                                    fert_rank = tot / self.block_size
                            trig_log[(arm, name)].append(trig[(arm, name)])
                            if arm == "treatment":
                                new_trig[name] = bool(
                                    fert_rank > GATE_MULT * TARGET_FERTILITY)
                            else:
                                new_trig[name] = bool(
                                    gate[step] > GATE_MULT * TARGET_FERTILITY)

                self._extras(arm, b, block_types, counts, learned, cuts,
                             store, merges_seen, audit)

                for name, v in new_trig.items():
                    trig[(arm, name)] = v

        self.store = store
        self.merges_seen = merges_seen
        self.trig_log = trig_log
        return self

    # ------------------------------------------------------------- extras

    def _extras(self, arm, b, block_types, counts, learned, cuts, store,
                merges_seen, audit):
        A = self.alphabet
        # chars ------------------------------------------------------------
        if arm == "treatment":
            pmap = {w: list(w) for w in block_types}
            tot, bf1, bad = self._score_block(b, pmap)
            if audit:
                self.unsegmentable += bad
            for regime in REGIMES:
                store[(arm, regime, "chars")].append(
                    (tot / self.block_size, self._cost(0, tot), bf1))
                merges_seen[(arm, "chars")].append(0)

        # words ------------------------------------------------------------
        top = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))[:WORDS_VOCAB]
        stored = {w for w, _ in top}
        wbits = sum(len(w) * code_bits(self.A) for w in stored)
        vw = self.A + len(stored)
        pmap = {w: ([w] if w in stored else list(w)) for w in block_types}
        tot, bf1, bad = self._score_block(b, pmap)
        if audit:
            self.unsegmentable += bad
        cost = (self.alphabet_bits + wbits + tot * code_bits(vw)) / self.block_size
        for regime in REGIMES:
            store[(arm, regime, "words")].append(
                (tot / self.block_size, cost, bf1))
        merges_seen[(arm, "words")].append(len(stored))

        # oracle -----------------------------------------------------------
        if arm == "treatment":
            own = Counter(self.words[b])
            s2, p2 = variety_maps(sorted(own))
            ml = train_merges(dict(own), ORACLE_SIZE, "freq", "free", s2, p2,
                              self.threshold, self.min_pair_count)
            vocab, rank, vset = vocab_from_merges(A, ml)
            mx = max(len(v) for v in vocab)
            for regime in REGIMES:
                pmap = self._segment_all(block_types, regime, rank, vset, mx)
                tot, bf1, bad = self._score_block(b, pmap)
                if audit:
                    self.unsegmentable += bad
                store[(arm, regime, "oracle")].append(
                    (tot / self.block_size, self._cost(len(ml), tot), bf1))
            merges_seen[(arm, "oracle")].append(len(ml))

        # cascade ----------------------------------------------------------
        hi = learned[("freq", "free")][:self.budget]
        vh, rh, sh = vocab_from_merges(A, hi)
        mh_ = max(len(v) for v in vh)
        n_m = len(hi)
        for regime in REGIMES:
            pmap = {w: cascade_segment(w, cuts[w], regime, rh, sh, mh_)
                    for w in block_types}
            tot, bf1, bad = self._score_block(b, pmap)
            if audit:
                self.unsegmentable += bad
            store[(arm, regime, "cascade")].append(
                (tot / self.block_size, self._cost(n_m, tot), bf1))
        merges_seen[(arm, "cascade")].append(n_m)

    # -------------------------------------------------------------- output

    def metrics(self, arm, regime, name) -> dict:
        rows = self.store[(arm, regime, name)]
        return summarize([r[0] for r in rows], [r[1] for r in rows],
                         [r[2] for r in rows])
