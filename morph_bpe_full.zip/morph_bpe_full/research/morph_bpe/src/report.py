"""
Assembly of the reported object.

Nothing here decides anything; it reads the engine's per-block record and
lays it out. The three top-level keys are kept separable on purpose: the
corpus report needs no walk-forward, the drift report needs no vocabulary
sweep, and either can be checked against the inputs without running the other.
"""

from __future__ import annotations

from collections import Counter

import numpy as np

from .apply import boundaries, seg_rank
from .evaluate import (BASE_SCHEMES, FAMILIES, REGIMES, SCHEMES, WINDOW,
                       config_names)
from .merges import train_merges, variety_maps, vocab_from_merges
from .metrics import (METRIC_KEYS, TARGET_FERTILITY, auc_ranks, code_bits, f1,
                      ks_two_sample, merge_table_bits, paired_panel,
                      renyi_efficiency)

N_BINS_EPOCH = 6
N_BINS_DECILE = 10
SIG_METRICS = (("mean_fertility", False), ("p95_fertility", False),
               ("bits_per_word", False), ("boundary_f1_pct", True))
EXTRAS = ("cascade", "chars", "words", "oracle")
CONTROL_EXTRAS = ("cascade", "words")


def _era_stats(eng, blocks, rank, vset, mx):
    tot = tp = npred = ngold = 0
    lens = []
    counts = Counter()
    for b in blocks:
        for w in eng.words[b]:
            pcs = seg_rank(w, rank)
            tot += len(pcs)
            counts.update(pcs)
            lens.extend(len(p) for p in pcs)
            g = eng.gold[w]
            bd = boundaries(pcs)
            tp += len(bd & g)
            npred += len(bd)
            ngold += len(g)
    n_words = sum(len(eng.words[b]) for b in blocks)
    return {
        "tokens": tot,
        "fertility": tot / n_words,
        "f1": f1(tp, npred, ngold),
        "ttr": len(counts) / tot,
        "mean_token_len": float(np.mean(lens)),
        "renyi": renyi_efficiency(np.array(list(counts.values()))),
    }


def corpus_report(eng) -> dict:
    train = eng.blocks[:WINDOW]
    final = eng.blocks[-WINDOW:]
    counts = Counter()
    for b in train:
        counts.update(eng.words[b])
    succ, pred = variety_maps(sorted(counts))
    full = train_merges(dict(counts), eng.budget, "freq", "free", succ, pred,
                        eng.threshold, eng.min_pair_count)

    stats, bits = {}, {}
    for size in eng.sizes:
        ml = full[:size]
        vocab, rank, vset = vocab_from_merges(eng.alphabet, ml)
        mx = max(len(v) for v in vocab)
        tr = _era_stats(eng, train, rank, vset, mx)
        fi = _era_stats(eng, final, rank, vset, mx)
        cb = code_bits(eng.A + len(ml))
        vb = merge_table_bits(eng.A, len(ml))
        bits[str(size)] = int(merge_table_bits(eng.A, size))
        stats[str(size)] = {
            "vocab_bits_per_word": vb / eng.block_size,
            "data_bits_per_word_train_era": tr["fertility"] * cb,
            "data_bits_per_word_final_era": fi["fertility"] * cb,
            "subword_ttr_train_era": tr["ttr"],
            "mean_token_len_train_era": tr["mean_token_len"],
            "fertility_train_era": tr["fertility"],
            "fertility_final_era": fi["fertility"],
            "boundary_f1_train_era": tr["f1"] * 100.0,
            "boundary_f1_final_era": fi["f1"] * 100.0,
            "renyi_train_era": tr["renyi"],
            "renyi_final_era": fi["renyi"],
            "merges_used": float(len(ml)),
        }

    all_words = [w for b in eng.blocks for w in eng.words[b]]
    return {
        "n_blocks": int(eng.n_blocks),
        "n_tokens": int(eng.n_tokens),
        "n_types": int(eng.n_types),
        "n_eval_blocks": int(eng.n_eval),
        "n_window_blocks": int(WINDOW),
        "alphabet_size": int(eng.A),
        "alphabet_bits": int(eng.alphabet_bits),
        "vocab_sizes": [int(v) for v in eng.sizes],
        "vocab_bits": bits,
        "mean_word_len": float(np.mean([len(w) for w in all_words])),
        "corpus_stats": stats,
    }


# ---------------------------------------------------------------- drift

def _rank_statistic(eng):
    train = eng.blocks[:WINDOW]
    counts = Counter()
    for b in train:
        counts.update(eng.words[b])
    order = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))
    rank = {w: i + 1 for i, (w, _) in enumerate(order)}
    novel = len(order) + 1
    per_block = {b: np.array([rank.get(w, novel) for w in eng.words[b]],
                             dtype=float) for b in eng.blocks}
    return per_block, train


def _bin_edges(sample, n_bins):
    return np.percentile(sample, [100.0 * i / n_bins for i in range(1, n_bins)])


def drift_report(eng) -> dict:
    per_block, train = _rank_statistic(eng)
    epoch_of = {b: min(b // WINDOW, 5) for b in eng.blocks}
    epochs = [np.concatenate([per_block[b] for b in eng.blocks
                              if epoch_of[b] == e]) for e in range(6)]
    train_sample = np.concatenate([per_block[b] for b in train])

    def share(n_bins):
        edges = _bin_edges(train_sample, n_bins)
        out = []
        for e in range(6):
            idx = np.searchsorted(edges, epochs[e], side="right")
            row = np.bincount(idx, minlength=n_bins)[:n_bins].astype(float)
            out.append((row / row.sum()).tolist())
        return out

    sm = share(N_BINS_EPOCH)
    cond = []
    for e, row in enumerate(sm):
        r = list(row)
        r[e] = 0.0
        s = sum(r)
        cond.append([1.0 / 5.0] * 6 if s == 0 else [x / s for x in r])

    ks = [[0.0 if a == b else ks_two_sample(epochs[a], epochs[b])
           for b in range(6)] for a in range(6)]

    dec = share(N_BINS_DECILE)
    decile = {f"D{d}": {f"E{e}": dec[e][d] * 100.0 for e in range(6)}
              for d in range(N_BINS_DECILE)}

    return {
        "epoch_share_matrix": sm,
        "conditional_epoch_share_matrix": cond,
        "epoch_ks_matrix": ks,
        "decile_share_pct": decile,
    }


# ------------------------------------------------------------- variants

def variant_panel(eng, regime) -> dict:
    names = config_names(eng.sizes)
    strat = {n: eng.metrics("treatment", regime, n) for n in names}
    for x in EXTRAS:
        strat[x] = eng.metrics("treatment", regime, x)
    ctrl = {n: eng.metrics("control", regime, n) for n in names}
    for x in CONTROL_EXTRAS:
        ctrl[x] = eng.metrics("control", regime, x)

    best = min(names, key=lambda n: (strat[n]["mean_fertility"], n))
    chars_bits = strat["chars"]["bits_per_word"]
    trig = float(np.mean([np.mean(eng.trig_log[("treatment", n)])
                          for n in names]))
    merges = float(np.mean([np.mean(eng.merges_seen[("treatment", n)])
                            for n in names]))

    sig = {}
    for fam in FAMILIES:
        fam_names = [n for n in names if n.startswith(fam + "_")]
        sig[fam] = {}
        for metric, higher in SIG_METRICS:
            sig[fam][metric] = paired_panel(
                [strat[n][metric] for n in fam_names],
                [ctrl[n][metric] for n in fam_names], higher)

    return {
        "diagnostics": {
            "n_eval_blocks": int(eng.n_eval),
            "mean_merges_used": merges,
            "trigger_rate": trig,
            "mean_boundary_f1_pct": float(np.mean(
                [strat[n]["boundary_f1_pct"] for n in names])),
            "best_config": best,
            "best_mean_fertility": strat[best]["mean_fertility"],
            "best_bits_per_word": strat[best]["bits_per_word"],
            "saving_vs_chars_pct": (chars_bits - strat[best]["bits_per_word"])
            / chars_bits * 100.0,
            "unsegmentable_audited": int(eng.unsegmentable),
        },
        "strategy_metrics": {k: {m: v[m] for m in METRIC_KEYS}
                             for k, v in sorted(strat.items())},
        "control_metrics": {k: {m: v[m] for m in METRIC_KEYS}
                            for k, v in sorted(ctrl.items())},
        "significance": sig,
    }


def build_results(eng) -> dict:
    eng.run()
    return {
        "corpus_report": corpus_report(eng),
        "drift_report": drift_report(eng),
        "variants": {r: variant_panel(eng, r) for r in REGIMES},
    }
