"""
Corpus construction: a concatenative morphology with allomorphy and lexical
drift, plus the loaders used by the study.

The generator exists so that gold morpheme boundaries are known by
construction rather than annotated. Words are built as

    (prefix) root (root) suffix*

from frozen inventories, then three boundary rewrite rules apply, so surface
forms do not expose their own segmentation: the gold boundary offsets are
carried through the rewrites rather than recovered from them.

Drift is lexical, not stylistic. Six epochs share one root inventory but
weight its six semantic fields differently, and suffix productivity rises
across the corpus. A vocabulary fitted to an early window is therefore stale
by construction on a late block, which is the whole reason the walk-forward
design in ``evaluate`` has anything to measure.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

ALPHABET = list("abdefgiklmnoprstuvyz")  # 20 symbols, frozen
VOWELS = set("aeiou")
CONSONANTS = [c for c in ALPHABET if c not in VOWELS]

N_FIELDS = 6
N_ROOTS = 420
N_PREFIX = 12
N_SUFFIX = 20


def _syllable(rng: np.random.Generator) -> str:
    c = CONSONANTS[rng.integers(len(CONSONANTS))]
    v = sorted(VOWELS)[rng.integers(len(VOWELS))]
    if rng.random() < 0.30:
        c2 = CONSONANTS[rng.integers(len(CONSONANTS))]
        return c + v + c2
    return c + v


def build_inventories(seed: int = 20260817) -> dict:
    """Roots, prefixes and suffixes with Zipfian within-field weights."""
    rng = np.random.default_rng(seed)

    roots, seen = [], set()
    while len(roots) < N_ROOTS:
        n_syl = 1 + int(rng.random() < 0.62) + int(rng.random() < 0.06)
        w = "".join(_syllable(rng) for _ in range(n_syl))
        if 3 <= len(w) <= 7 and w not in seen:
            seen.add(w)
            roots.append(w)

    field = np.arange(N_ROOTS) % N_FIELDS
    rng.shuffle(field)

    prefixes, seen = [], set()
    while len(prefixes) < N_PREFIX:
        w = _syllable(rng)
        if w not in seen:
            seen.add(w)
            prefixes.append(w)

    suffixes, seen = [], set()
    while len(suffixes) < N_SUFFIX:
        n = 1 + int(rng.random() < 0.45)
        w = "".join(_syllable(rng) for _ in range(n))[: 1 + int(rng.integers(1, 5))]
        if 1 <= len(w) <= 5 and w not in seen:
            seen.add(w)
            suffixes.append(w)

    def zipf(n, s):
        w = 1.0 / np.power(np.arange(1, n + 1), s)
        return w / w.sum()

    root_w = np.zeros(N_ROOTS)
    for f in range(N_FIELDS):
        idx = np.where(field == f)[0]
        order = rng.permutation(len(idx))
        root_w[idx[order]] = zipf(len(idx), 1.45)

    return {
        "roots": roots,
        "field": field,
        "root_w": root_w,
        "prefixes": prefixes,
        "prefix_w": zipf(N_PREFIX, 0.85),
        "suffixes": suffixes,
        "suffix_w": zipf(N_SUFFIX, 0.95),
    }


def _join(parts: list[str]) -> tuple[str, list[str]]:
    """Concatenate morphs under three boundary rules, tracking gold spans.

    R1  vowel + vowel across a boundary deletes the left vowel
    R2  a doubled consonant across a boundary degeminates
    R3  otherwise the boundary is transparent

    The returned spans are the surface substrings of each morph, so their
    concatenation is the surface word and their cumulative lengths are the
    gold interior boundaries.
    """
    surf = parts[0]
    spans = [parts[0]]
    for p in parts[1:]:
        if not surf or not p:
            spans.append(p)
            surf += p
            continue
        left, right = surf[-1], p[0]
        if left in VOWELS and right in VOWELS:
            surf = surf[:-1]
            spans[-1] = spans[-1][:-1]
        elif left == right and left not in VOWELS:
            p = p[1:]
        spans.append(p)
        surf += p
    spans = [s for s in spans if s != ""]
    return surf, spans


def _epoch_field_weights(epoch: int) -> np.ndarray:
    """Field mixture rotates and sharpens across the six epochs."""
    base = np.roll(np.array([0.34, 0.24, 0.16, 0.12, 0.09, 0.05]), epoch)
    tilt = 1.0 + 0.05 * epoch
    w = np.power(base, tilt)
    return w / w.sum()


def generate_corpus(n_blocks: int = 36, block_size: int = 800,
                    seed: int = 20260817) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return (corpus, lexicon).

    corpus   token_id, block, word
    lexicon  word, morphs (``+``-joined surface spans), n_morphs, word_len
    """
    inv = build_inventories(seed)
    rng = np.random.default_rng(seed + 1)

    roots = inv["roots"]
    field = inv["field"]
    prefixes, suffixes = inv["prefixes"], inv["suffixes"]

    rows, gold = [], {}
    tid = 0
    for b in range(n_blocks):
        epoch = min(b // 6, N_FIELDS - 1)
        fw = _epoch_field_weights(epoch)
        w = inv["root_w"] * fw[field]
        w = w / w.sum()
        n_suf_p = 0.42 + 0.035 * epoch          # suffix productivity rises

        for _ in range(block_size):
            parts = []
            if rng.random() < 0.18:
                parts.append(prefixes[rng.choice(N_PREFIX, p=inv["prefix_w"])])
            parts.append(roots[rng.choice(N_ROOTS, p=w)])
            if rng.random() < 0.05:
                parts.append(roots[rng.choice(N_ROOTS, p=w)])
            k = 0
            while k < 3 and rng.random() < n_suf_p:
                parts.append(suffixes[rng.choice(N_SUFFIX, p=inv["suffix_w"])])
                k += 1
            surf, spans = _join(parts)
            rows.append((f"T{tid:06d}", b, surf))
            gold.setdefault(surf, spans)
            tid += 1

    corpus = pd.DataFrame(rows, columns=["token_id", "block", "word"])
    lex = pd.DataFrame(
        [(w, "+".join(s), len(s), len(w)) for w, s in sorted(gold.items())],
        columns=["word", "morphs", "n_morphs", "word_len"],
    )
    return corpus, lex


# ----------------------------------------------------------------- loaders

def load_corpus(data_dir: Path):
    data_dir = Path(data_dir)
    corpus = pd.read_csv(data_dir / "corpus.csv", dtype={"word": str})
    lex = pd.read_csv(data_dir / "lexicon.csv", dtype={"word": str, "morphs": str})
    with open(data_dir / "alphabet.json") as fh:
        alpha = json.load(fh)
    return corpus, lex, alpha


def gold_boundaries(lex: pd.DataFrame) -> dict[str, frozenset]:
    """word -> frozenset of interior surface offsets that are gold boundaries."""
    out = {}
    for w, m in zip(lex["word"].tolist(), lex["morphs"].tolist()):
        cuts, acc = [], 0
        parts = m.split("+")
        for p in parts[:-1]:
            acc += len(p)
            cuts.append(acc)
        out[w] = frozenset(c for c in cuts if 0 < c < len(w))
    return out
