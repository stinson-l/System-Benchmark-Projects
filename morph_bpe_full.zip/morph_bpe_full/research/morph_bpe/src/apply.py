"""
Segmentation regimes.

One vocabulary admits several segmentations of the same word, and the choice
among them is not a detail: it moves fertility, boundary agreement and the
token inventory that downstream statistics are computed over. Three regimes
are separated here so the vocabulary and its application can be varied
independently.

    rank    replay the learned merges in learned order (canonical BPE)
    greedy  longest match, left to right (WordPiece-style inference)
    short   fewest tokens, by dynamic programming, longest-first among ties

``short`` is the segmentation the compression argument actually wants and is
almost never the one a tokenizer ships with. All three are closed over the
alphabet, so no word is ever unsegmentable; the audit in ``evaluate`` checks
that this holds rather than assuming it.
"""

from __future__ import annotations


def seg_rank(word: str, rank: dict) -> list[str]:
    """Canonical byte-pair application: repeatedly merge the lowest rank."""
    if len(word) < 2:
        return [word] if word else []
    syms = list(word)
    while True:
        best, at = None, -1
        for j in range(len(syms) - 1):
            r = rank.get((syms[j], syms[j + 1]))
            if r is not None and (best is None or r < best):
                best, at = r, j
        if best is None:
            break
        syms[at:at + 2] = [syms[at] + syms[at + 1]]
    return syms


def seg_greedy(word: str, vocab: set, max_len: int) -> list[str]:
    """Longest match, left to right; single characters always match."""
    out, i, n = [], 0, len(word)
    while i < n:
        hi = min(n, i + max_len)
        j = hi
        while j > i + 1 and word[i:j] not in vocab:
            j -= 1
        out.append(word[i:j])
        i = j
    return out


def seg_short(word: str, vocab: set, max_len: int) -> list[str]:
    """Fewest tokens; among optima take the longest first token, recursively.

    Backward dynamic programming. ``best[i]`` is the minimum token count for
    ``word[i:]`` and ``cut[i]`` the largest split point attaining it, so the
    reconstruction prefers the longest available token at every position.
    """
    n = len(word)
    INF = n + 2
    best = [INF] * (n + 1)
    cut = [0] * (n + 1)
    best[n] = 0
    for i in range(n - 1, -1, -1):
        hi = min(n, i + max_len)
        for j in range(hi, i, -1):
            if j - i == 1 or word[i:j] in vocab:
                cand = 1 + best[j]
                if cand < best[i]:
                    best[i], cut[i] = cand, j
    out, i = [], 0
    while i < n:
        j = cut[i]
        out.append(word[i:j])
        i = j
    return out


def segment(word: str, regime: str, rank: dict, vocab: set, max_len: int):
    if regime == "rank":
        return seg_rank(word, rank)
    if regime == "greedy":
        return seg_greedy(word, vocab, max_len)
    if regime == "short":
        return seg_short(word, vocab, max_len)
    raise ValueError(regime)                      # pragma: no cover


def boundaries(pieces: list[str]) -> frozenset:
    """Interior surface offsets implied by a segmentation."""
    out, acc = [], 0
    for p in pieces[:-1]:
        acc += len(p)
        out.append(acc)
    return frozenset(out)


def cascade_segment(word: str, cuts: frozenset, regime: str, rank: dict,
                    vocab: set, max_len: int):
    """Harris pre-segmentation, then an unconstrained vocabulary within.

    The pre-segmenter is a set of offsets read off the window's type
    inventory, so it adds nothing to the serialized vocabulary and its cost is
    charged at the vocabulary it wraps. Cutting first and merging second is
    not the same structure as constraining the merges themselves: the
    vocabulary here was learned with no knowledge of the cuts.
    """
    out, prev = [], 0
    for c in sorted(cuts) + [len(word)]:
        if c <= prev:
            continue
        out.extend(segment(word[prev:c], regime, rank, vocab, max_len))
        prev = c
    return out
