"""
Measurement.

Three quantities are reported per block and everything else is derived from
them:

  fertility        tokens per word, observable without any annotation
  boundary F1      agreement with the gold morpheme cuts, micro-averaged
  bits per word    total description length, vocabulary included

The third is where this study departs from the usual tokenizer comparison.
Fertility alone is monotone in vocabulary size and therefore always prefers
the largest vocabulary on offer; charging the merge table against the same
budget is what makes the comparison a comparison.
"""

from __future__ import annotations

import math

import numpy as np
from scipy import stats as st

TARGET_FERTILITY = 2.0
METRIC_KEYS = ("mean_fertility", "p95_fertility", "max_fertility",
               "pct_within_target", "excess_ratio", "bits_per_word",
               "boundary_f1_pct")


def code_bits(vocab_size: int) -> int:
    """Flat-code width over a vocabulary, in bits. Integer by construction."""
    return max(1, (vocab_size - 1).bit_length())


def merge_table_bits(alphabet_size: int, n_merges: int) -> int:
    """Serialized cost of a merge table: two live ids per merge."""
    total = 0
    for t in range(n_merges):
        total += 2 * code_bits(alphabet_size + t)
    return total


def f1(tp: int, n_pred: int, n_gold: int) -> float:
    if n_pred == 0 or n_gold == 0 or tp == 0:
        return 0.0
    p = tp / n_pred
    r = tp / n_gold
    return 2.0 * p * r / (p + r)


def summarize(fert: list[float], bits: list[float], bf1: list[float]) -> dict:
    f = np.asarray(fert, dtype=float)
    return {
        "mean_fertility": float(f.mean()),
        "p95_fertility": float(np.percentile(f, 95)),
        "max_fertility": float(f.max()),
        "pct_within_target": float((f <= TARGET_FERTILITY).mean()),
        "excess_ratio": float(f.mean() / TARGET_FERTILITY),
        "bits_per_word": float(np.mean(bits)),
        "boundary_f1_pct": float(np.mean(bf1) * 100.0),
    }


def renyi_efficiency(counts: np.ndarray, alpha: float = 2.5) -> float:
    """Renyi efficiency of a token unigram distribution (Zouhar et al., 2023).

    Zero when fewer than two distinct token types are present.
    """
    c = np.asarray(counts, dtype=float)
    c = c[c > 0]
    if c.size < 2:
        return 0.0
    p = c / c.sum()
    h = math.log(float(np.power(p, alpha).sum())) / (1.0 - alpha)
    return float(h / math.log(c.size))


def ks_two_sample(a: np.ndarray, b: np.ndarray) -> float:
    if a.size == 0 or b.size == 0:
        return 0.0
    return float(st.ks_2samp(a, b, method="asymp").statistic)


def auc_ranks(pos: np.ndarray, neg: np.ndarray) -> float:
    """Tie-aware Mann-Whitney statistic from average ranks over the pool."""
    if pos.size == 0 or neg.size == 0:
        return 0.0
    pooled = np.concatenate([pos, neg])
    r = st.rankdata(pooled)
    rp = r[: pos.size].sum()
    return float((rp - pos.size * (pos.size + 1) / 2.0) / (pos.size * neg.size))


def paired_panel(treat: list[float], ctrl: list[float], higher: bool) -> dict:
    """Paired t-test plus two-method Nemenyi over the same pairs."""
    t = np.asarray(treat, dtype=float)
    c = np.asarray(ctrl, dtype=float)
    if not higher:
        t, c = -t, -c
    p = float(st.ttest_rel(t, c, alternative="greater").pvalue)

    tr = cr = 0.0
    for x, y in zip(t, c):
        if x > y:
            tr += 2.0
            cr += 1.0
        elif x < y:
            tr += 1.0
            cr += 2.0
        else:
            tr += 1.5
            cr += 1.5
    n = len(t)
    tr /= n
    cr /= n
    q = abs(tr - cr) * math.sqrt(n)
    nem = min(2.0 * float(st.norm.sf(q / math.sqrt(2.0))), 1.0)
    return {"control_rank": cr, "treatment_rank": tr,
            "t_test_p": p, "nemenyi_p": nem}
