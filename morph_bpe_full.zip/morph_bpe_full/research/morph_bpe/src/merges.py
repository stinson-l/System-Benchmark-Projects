"""
Vocabulary induction.

Two scoring families over the same incremental machinery:

  freq   argmax pair count                     (Sennrich et al., 2016)
  like   argmax count(ab) / (count(a)count(b)) (Schuster & Nakajima, 2012)

``like`` is a ratio of integers and is resolved by cross-multiplication, never
by floating-point division, so the merge sequence cannot depend on rounding.
Both families break ties on the pair's surface string, which is the single
choice that most implementations leave to dictionary iteration order and which
therefore has to be pinned.

Four constraint schemes decide which within-word positions a merge may cross.
``sv`` and ``bidi`` use Harris (1955) successor variety over the window's type
inventory: an integer count of distinct continuations, not a probability, and
computed from types rather than tokens, so it is unaffected by the frequency
permutation the control arm applies.
"""

from __future__ import annotations

from collections import defaultdict


# ------------------------------------------------------------- constraints

def variety_maps(types: list[str]) -> tuple[dict, dict]:
    """Successor and predecessor variety over a type inventory.

    Returns (succ, pred) mapping a prefix / suffix string to the number of
    distinct characters that may follow / precede it among the types.
    """
    succ, pred = defaultdict(set), defaultdict(set)
    for w in types:
        n = len(w)
        for i in range(1, n):
            succ[w[:i]].add(w[i])
            pred[w[i:]].add(w[i - 1])
    return ({k: len(v) for k, v in succ.items()},
            {k: len(v) for k, v in pred.items()})


def blocked_offsets(word: str, scheme: str, succ: dict, pred: dict,
                    threshold: int) -> frozenset:
    """Interior offsets of ``word`` a merge may not cross."""
    if scheme == "free":
        return frozenset()
    out = []
    n = len(word)
    for i in range(1, n):
        if succ.get(word[:i], 0) >= threshold:
            out.append(i)
        elif scheme == "bidi" and pred.get(word[i:], 0) >= threshold:
            out.append(i)
    return frozenset(out)


# ------------------------------------------------------------- the trainer

class _Word:
    __slots__ = ("syms", "offs", "count")

    def __init__(self, word: str, count: int):
        self.syms = list(word)
        self.offs = list(range(len(word) + 1))
        self.count = count


def train_merges(type_counts: dict[str, int], budget: int, family: str,
                 scheme: str, succ: dict, pred: dict, threshold: int,
                 min_pair_count: int) -> list[tuple[str, str]]:
    """Learn up to ``budget`` merges. Returns the ordered merge list.

    ``type_counts`` maps a word type to its window token count. Learning is
    over types weighted by count, which is what every BPE implementation does
    and what makes the control arm's frequency permutation meaningful.
    """
    words = []
    blocks = []
    for w in sorted(type_counts):
        if len(w) < 2:
            continue
        words.append(_Word(w, type_counts[w]))
        blocks.append(blocked_offsets(w, scheme, succ, pred, threshold))

    pair_count: dict[tuple[str, str], int] = defaultdict(int)
    pair_where: dict[tuple[str, str], set] = defaultdict(set)
    sym_count: dict[str, int] = defaultdict(int)

    def scan(wi: int, sign: int) -> None:
        W, blk = words[wi], blocks[wi]
        s, o, c = W.syms, W.offs, W.count
        for j in range(len(s)):
            sym_count[s[j]] += sign * c
        for j in range(len(s) - 1):
            if o[j + 1] in blk:
                continue
            p = (s[j], s[j + 1])
            pair_count[p] += sign * c
            if sign > 0:
                pair_where[p].add(wi)

    for wi in range(len(words)):
        scan(wi, +1)

    merges: list[tuple[str, str]] = []
    for _ in range(budget):
        best = None
        if family == "freq":
            bc = 0
            for p, c in pair_count.items():
                if c > bc or (c == bc and best is not None and p < best):
                    bc, best = c, p
        elif family == "like":
            bn = bd = 0
            for p, c in pair_count.items():
                if c < min_pair_count:
                    continue
                d = sym_count[p[0]] * sym_count[p[1]]
                if d <= 0:
                    continue
                # c/d > bn/bd  <=>  c*bd > bn*d, all integers
                if best is None:
                    bn, bd, best = c, d, p
                    continue
                lhs, rhs = c * bd, bn * d
                if lhs > rhs or (lhs == rhs and p < best):
                    bn, bd, best = c, d, p
        else:                                     # pragma: no cover
            raise ValueError(family)

        if best is None or pair_count.get(best, 0) <= 0:
            break
        a, b = best
        new = a + b
        touched = sorted(pair_where[best])
        for wi in touched:
            W, blk = words[wi], blocks[wi]
            s, o = W.syms, W.offs
            hit = False
            for j in range(len(s) - 1):
                if s[j] == a and s[j + 1] == b and o[j + 1] not in blk:
                    hit = True
                    break
            if not hit:
                continue
            scan(wi, -1)
            ns, no = [], [o[0]]
            j = 0
            while j < len(s):
                if (j + 1 < len(s) and s[j] == a and s[j + 1] == b
                        and o[j + 1] not in blk):
                    ns.append(new)
                    no.append(o[j + 2])
                    j += 2
                else:
                    ns.append(s[j])
                    no.append(o[j + 1])
                    j += 1
            W.syms, W.offs = ns, no
            scan(wi, +1)
        merges.append(best)
        pair_count.pop(best, None)
        pair_where.pop(best, None)
        if len(pair_count) > 4 * len(words) + 512:
            for p in [p for p, c in pair_count.items() if c <= 0]:
                pair_count.pop(p, None)
                pair_where.pop(p, None)

    return merges


def vocab_from_merges(alphabet: list[str], merges: list[tuple[str, str]]):
    """(ordered vocabulary list, rank dict, vocabulary set) for a merge prefix."""
    vocab = list(alphabet)
    rank = {}
    for i, (a, b) in enumerate(merges):
        rank[(a, b)] = i
        vocab.append(a + b)
    return vocab, rank, set(vocab)
