"""Freeze the task inputs. Run once; the outputs are the task's fixed data."""

from __future__ import annotations

import json
import math
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from src.data import ALPHABET, generate_corpus  # noqa: E402

OUT = Path(sys.argv[1] if len(sys.argv) > 1 else "data")
OUT.mkdir(parents=True, exist_ok=True)

corpus, lex = generate_corpus(36, 800)
corpus.to_csv(OUT / "corpus.csv", index=False)
lex.to_csv(OUT / "lexicon.csv", index=False)

train = corpus[corpus["block"] < 6]["word"].tolist()
chars = Counter("".join(train))
tot = sum(chars.values())
symbol_bits = {}
for c in ALPHABET:
    p = chars.get(c, 1) / tot
    symbol_bits[c] = int(min(8, max(3, math.ceil(-math.log2(p)))))

alpha = {
    "symbols": ALPHABET,
    "symbol_bits": symbol_bits,
    "merge_budget": 600,
    "vocab_sizes": [128, 320, 600],
    "min_pair_count": 2,
    "variety_threshold": 8,
}
(OUT / "alphabet.json").write_text(json.dumps(alpha, indent=1, sort_keys=True))

print("corpus", corpus.shape, "lexicon", lex.shape)
print("alphabet", len(ALPHABET), "bits", sum(symbol_bits.values()))
