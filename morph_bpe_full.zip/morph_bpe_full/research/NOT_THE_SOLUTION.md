# NOT_THE_SOLUTION.md

This directory is the study the task was cut from. It is **not** a solution to
`task/PROMPT.txt` and should not be handed to anyone attempting it: it contains
the corpus generator, the findings, and the reasoning that fixed each parameter.
`task/SPEC.md` was written to be sufficient without any of it, and
`task/crosscheck/solve_narrow_crosscheck.py` is the evidence that it is.

---

## 1. The three claims

Subword tokenization is the least examined stage of the modern NLP pipeline. It
is fitted once, on whatever corpus is to hand, and then frozen for the life of
the model. Three claims travel with it, all of them load-bearing and none of
them routinely tested:

**C1 — merges recover morphology.** The folk version of Sennrich et al. (2016):
because morphemes are frequent recurring substrings, the greedy
maximum-frequency merge sequence should discover them. Bostrom and Durrett
(2020) contested this for English and Japanese against a unigram-LM tokenizer,
but the frequency mechanism itself has rarely been isolated.

**C2 — compression is the objective.** Fertility, bytes per token and Rényi
efficiency (Zouhar et al., 2023) are used as tokenizer-quality proxies on the
argument that a tokenizer that compresses better leaves the model less work.
Schmidt et al. (2024) found the correlation with downstream performance weak.
The accounting question underneath is older and simpler: a compression metric
that charges the data but not the codebook is not a compression metric.

**C3 — application is a detail.** The same vocabulary yields different
segmentations under merge-rank replay, longest-match, and minimum-token
dynamic programming. Shipped tokenizers vary in which they use, and the choice
is usually not reported.

This study tests all three on one corpus under one budget, with a control arm
that isolates the mechanism C1 depends on.

## 2. Why a generated corpus

Gold morpheme boundaries are the scarce resource. Annotated segmentations exist
(MorphoChallenge and successors) but they are small, English-and-Finnish-heavy,
and inconsistent about clitics and compounds — and none of them come with a
temporal axis, which C1 and the staleness question both need.

So the corpus is generated from a concatenative grammar and the boundaries are
known by construction rather than annotated:

* 420 roots over six semantic fields, Zipfian within field (s = 1.45)
* 12 prefixes, 20 suffixes, suffix stacking up to depth 3, 5% compounding
* three boundary rewrite rules — vowel hiatus deletion, degemination, and the
  transparent case — applied at every morph junction

The rewrites matter more than they look. Without them the surface string
exposes its own segmentation and boundary F1 becomes a trivial string-matching
exercise; with them the gold cut offsets have to be carried through the
rewriting, and a boundary can sit inside a character that belongs to two
morphs. Mean surface length is 7.70 characters over 3.17 morphs, and 82.3% of
types are hapax.

Drift is lexical. The six epochs share the root inventory but rotate and sharpen
the field mixture, and suffix productivity rises across the corpus. The result
is that a vocabulary fitted to blocks 0–5 sees a token-level novelty rate of
0.42 by epoch 1 and 0.55 by epoch 5, and the epoch-0-to-epoch-5 KS statistic on
train-era frequency rank is 0.548. The staleness the walk-forward design
measures is real and not an artifact of sampling noise.

**The honest limitation.** Purely concatenative morphology with three rewrite
rules is Turkish or Finnish on a good day, not Arabic and not Georgian. The
findings below are about agglutinative morphology under drift. Templatic and
fusional systems would need a different generator and might well behave
differently; nothing here should be read as a claim about them.

## 3. What the control arm is for

C1 says frequency finds morphemes. The obvious test — do BPE cuts land on gold
boundaries — cannot separate two explanations, because morphemes are frequent
*and* the type inventory of a morphologically productive language is itself
structured by morphology. Any tokenizer trained on that inventory inherits some
alignment for free.

So the control permutes the window's **type-frequency vector** across the
window's types. Every type still appears; the Zipf curve is preserved exactly;
successor and predecessor variety, being unweighted counts over the type set,
are bit-for-bit unchanged. What is destroyed is the association between which
word a type is and how often it occurs. If merges still land on morpheme
boundaries under that permutation, they were never using frequency.

This is the piece the specification pins hardest, and deliberately: one
permutation per evaluation block in ascending order, then a single
`rng.random(30)` for the gate, consumed whether or not a scheme acts on it. A
solver that seeds per configuration, or that skips the unused gate draw,
reproduces every treatment number and fails only on the control arm.

## 4. Findings

All numbers below are the `rank` regime on the frozen corpus unless noted.
Every one of them was re-derived on three independent corpus draws
(`robustness/seed_*.json`); the seeds agree on all four signs.

**F1 — charging the codebook inverts the ranking.** Fertility selects
`freq_free_600` (1.923 tokens per word). Total description length selects
`freq_sv_128` (24.30 bits per word), where `freq_free_600` costs 32.11 — a 32%
penalty for following the fertility ranking. The mechanism is not subtle: 600
merges cost 10,206 bits of merge table, 12.76 bits per word amortized over a
block, and the fertility gain of going from 128 to 600 merges does not pay for
it at this corpus size. Across the three seeds the penalty is 32.1%, 37.9% and
34.7%, and the length-optimal vocabulary is always the smallest of the three.

This is not an argument that large vocabularies are wrong. It is an argument
that fertility, reported alone, is not a compression result — it is one term of
a two-term objective, and it is the term that always prefers more merges.

**F2 — boundary agreement peaks away from both optima.** The best morphological
alignment is `freq_bidi_320` at 82.7% F1, against 70.6% at the fertility optimum
and 73.6% at the length optimum. On the third seed the winner is
`like_bidi_600` at 82.0%, but it is a `bidi` configuration in all three cases.
Whatever unsupervised boundary information exists here is supplied by the
Harris variety constraint, not by the merge objective.

**F3 — frequency contributes nothing to alignment, for the frequency family.**
Paired against the permuted control over 12 configurations, the `freq` family's
boundary F1 does not separate: p = 0.468 (`rank`), 0.294 (`greedy`), 0.286
(`short`), with mean ranks 1.58/1.42 to 1.67/1.33. On several individual
configurations the control is *better* — `freq_free_600` scores 70.6% treated
and 73.5% permuted. Across seeds: p = 0.468, 0.317, 0.850. Never significant,
never close.

The same test on the `like` family is significant everywhere (p = 4.2e-4,
8.2e-5, 2.8e-4), and its fertility collapses under permutation (4.10 to 5.16).
The likelihood objective genuinely depends on which word is frequent. Greedy
maximum-frequency merging, on this corpus, does not — its alignment comes from
the type inventory it is fitted to, which the control preserves.

This is the study's central result and it is a null one for C1, stated as
precisely as a null can be: the frequency signal that BPE optimizes is not what
produces its morpheme-boundary agreement.

**F4 — application is nearly free, and that is itself the finding.** Fertility
at the optimum moves 1.923 / 1.907 / 1.895 across `rank` / `greedy` / `short` —
a spread of 1.5%, and 0.75–0.89% in description length across the three seeds.
Minimum-token segmentation, which is what the compression argument actually
asks for, buys under two percent over replaying the merges. C3 survives for
fertility. It survives less well for boundary agreement, where the spread
reaches 3 points on constrained configurations (`freq_bidi_320`: 82.7 / 84.2 /
84.5), so a paper comparing tokenizers on morphological criteria and not
reporting its inference rule is under-specifying its experiment.

**F5 — staleness costs about a tenth of the fertility gap.** The oracle, refit
on the block it serves at 320 merges, reaches 1.937 against 2.160 for the same
size fitted on the six-block window — 10.3% better, and 10.2% on both other
seeds. Refitting is worth roughly one third of what tripling the vocabulary is
worth, at none of the codebook cost: the oracle costs 23.75 bits per word
against `freq_free_600`'s 32.11.

**F6 — constraining learning beats constraining inference.** `cascade` applies
the same `bidi` cuts as a hard pre-segmentation to a vocabulary learned without
them: 3.431 fertility, 61.2% F1. The `bidi` *scheme*, which lets the constraint
shape the merge sequence itself, reaches 2.357 and 82.7% at the same nominal
size. Injecting linguistic structure at inference time, after the vocabulary
has been fitted around its absence, recovers very little of it.

**F7 — the minimum-count floor is a live constraint, but not at this
threshold.** The specification charges a vocabulary for the merges it actually
learned rather than for its nominal size, because the likelihood family can
exhaust its eligible pair set before the budget. On the frozen corpus at
`variety_threshold = 8` this provision never binds: all 30 windows reach 600
merges in every family and scheme, and `mean_merges_used` is 349.33, exactly the
nominal mean of 128, 320 and 600.

It binds at tighter thresholds. At `variety_threshold = 3` the `bidi` cuts
fragment the type inventory enough that `like` runs out of pairs meeting the
floor at 305 to 431 merges depending on the window, and a nominal 600-entry
vocabulary is unattainable. The finding worth keeping is the conditional one:
nominal vocabulary size is a request, not a guarantee, and whether it is
honoured depends on an interaction between the merge objective's eligibility
rule and the pre-tokenization constraint that no comparison reporting only the
requested size would surface. The provision stays in the spec because it is
required for correctness in general and because the anti-hardcoding check
perturbs the inputs.

## 5. What was fixed, and why

`variety_threshold = 8` was calibrated once against gold, before any result was
computed, by sweeping thresholds 3–12 on the first window and taking the
boundary-F1 maximum for the `bidi` rule (0.668 at 8, against 0.406 at 3 and
0.628 at 12). This is the one place the gold file touches a parameter. It is
disclosed rather than hidden because the alternative — leaving the threshold at
a round number where the constraint fires at nearly every position — would have
made half the sweep uninformative and the `bidi` findings unfalsifiable.

`min_pair_count = 2` is the loosest floor that keeps the likelihood family from
merging hapax substrings, and it is the reason the eligibility rule of F7 never
binds at the calibrated threshold. A larger floor would have made the shortfall
routine and the `like` family's vocabulary sizes incomparable with the `freq`
family's; a smaller one does not exist.

`TARGET = 2.0` tokens per word was chosen so that `pct_within_target`
discriminates within the sweep rather than saturating. At 3.0 every `freq`
configuration passes every block and the field carries no information.

## 6. What the task keeps and what it drops

The task package asks for the full object: corpus report, drift report, three
regimes, 28 structures and 26 control arms each, and the paired significance
panels. What it drops is everything in this file — the generator, the claims,
the seed sweep, and the reasoning above. A solver reading `SPEC.md` computes the
numbers without knowing that F3 is the point, which is the property that makes
the task a test of implementation rather than of agreement.

The one-sided guarantee of §10 in the spec is the analogue of a
false-negative audit: the alphabet is closed over the corpus, so every word
must reproduce itself under every structure, and `unsegmentable_audited` is 0
for any correct implementation. It exists so that a solver that silently drops
unmatched spans — the most natural way to write a fast longest-match loop —
fails loudly instead of reporting an impressively low fertility.

## 7. References

Sennrich, Haddow & Birch (2016), *Neural Machine Translation of Rare Words with
Subword Units*. Schuster & Nakajima (2012), *Japanese and Korean Voice Search*.
Harris (1955), *From Phoneme to Morpheme*. Bostrom & Durrett (2020), *Byte Pair
Encoding is Suboptimal for Language Model Pretraining*. Zouhar et al. (2023),
*Tokenization and the Noiseless Channel*. Schmidt et al. (2024), *Tokenization
Is More Than Compression*. Gallé (2019), *Investigating the Effectiveness of
BPE: The Power of Shorter Sequences*.
